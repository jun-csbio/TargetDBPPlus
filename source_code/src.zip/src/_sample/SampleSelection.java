package _sample;

import java.util.Random;
import java.util.Vector;

import edu.njust.csbio.tools.JunHMatrix;
import edu.njust.csbio.tools.JunHVector;

public class SampleSelection {

	// general under negative sampling (only save near positive samples negative
	// samples)
	// make negative sample
	// self switch to binary problem
	// the last dimension is label
	public static double[][] generalPositiveSampleSelect(double[][] partten,
			double[] label, int positive_class) {
		Vector<double[]> select_partten_label = new Vector<double[]>();

		// show the pos is selected
		byte[] tag = new byte[label.length];
		for (int i = 0; i < label.length; i++) {
			tag[i] = '0';
		}

		for (int i = 0; i < label.length; i++) {
			if (1.0 == label[i]) {
				// select per positive sample
				select_partten_label.add(JunHVector.vectorCat(partten[i], 1));
				tag[i] = '1';
			}
		}

		return JunHMatrix.exchangeVDArrToD2Arr(select_partten_label);
	}

	// general under negative sampling (only save near positive samples negative
	// samples)
	// make negative sample
	// self switch to binary problem
	// the last dimension is label
	public static double[][] generalNegativeSampleSelect(double[][] partten,
			double[] label, int positive_class, int negative_ratio) {
		Vector<double[]> select_partten_label = new Vector<double[]>();

		// show the pos is selected
		byte[] tag = new byte[label.length];
		for (int i = 0; i < label.length; i++) {
			tag[i] = '0';
		}

		int alseNeedNegativeNum = 0;

		for (int i = 0; i < label.length; i++) {
			if (1.0 == label[i]) {
				// selected negative samples before positive samples
				int before_select_num = negative_ratio / 2;
				for (int j = i - 1; j >= 0; j--) {
					if (1.0 != label[j] && '1' != tag[j]) {
						select_partten_label.add(JunHVector.vectorCat(
								partten[j], -1));
						tag[j] = '1';
						before_select_num--;
					}
					if (before_select_num <= 0) {
						break;
					}
				}
				alseNeedNegativeNum += before_select_num;

				// selected negative samples before positive samples
				int after_select_num = negative_ratio - negative_ratio / 2;
				for (int j = i + 1; j < label.length; j++) {
					if (1.0 != label[j] && '1' != tag[j]) {
						select_partten_label.add(JunHVector.vectorCat(
								partten[j], -1));
						tag[j] = '1';
						after_select_num--;
					}
					if (after_select_num <= 0) {
						break;
					}
				}
				alseNeedNegativeNum += after_select_num;
			}
		}

		for (int j = 0; j < alseNeedNegativeNum; j++) {
			for (int i = 0; i < label.length; i++) {
				if (1.0 != label[i] && '1' != tag[i]) {
					select_partten_label.add(JunHVector.vectorCat(partten[i],
							-1));
					tag[j] = '1';
					break;
				}
			}
		}

		return JunHMatrix.exchangeVDArrToD2Arr(select_partten_label);
	}
	
	// general under negative sampling (only save near positive samples negative samples)
	// make negative sample 
	// self switch to binary problem 
	// the last dimension is label
	public static double[][] generalUnderSampleSelect(double[][] partten, double[] label, int positive_class, int negative_ratio){
		Vector<double[]> select_partten_label = new Vector<double[]>();
		
		// show the pos is selected
		byte[] tag = new byte[label.length];
		for (int i = 0; i < label.length; i++){
			tag[i] = '0';
		}
		
		int alseNeedNegativeNum = 0;
		
		for (int i = 0; i < label.length; i++){
			if (1.0 == label[i]){
				// selected negative samples before positive samples
				int before_select_num = negative_ratio / 2;
				for (int j = i-1; j >= 0; j--){
					if (1.0 != label[j] && '1' != tag[j]){
						select_partten_label.add(JunHVector.vectorCat(partten[j], -1));
						tag[j] = '1';
						before_select_num--;
					}
					if (before_select_num <= 0){
						break;
					}
				}
				alseNeedNegativeNum += before_select_num;

				// select per positive sample
				select_partten_label.add(JunHVector.vectorCat(partten[i], 1));
				tag[i] = '1';
				
				// selected negative samples before positive samples
				int after_select_num = negative_ratio-negative_ratio / 2;
				for (int j = i+1; j < label.length; j++){
					if (1.0 != label[j] && '1' != tag[j]){
						select_partten_label.add(JunHVector.vectorCat(partten[j], -1));
						tag[j] = '1';
						after_select_num--;
					}
					if (after_select_num <= 0){
						break;
					}
				}
				alseNeedNegativeNum += after_select_num;
			}
		}
		
		for (int j = 0; j < alseNeedNegativeNum; j++){
			for (int i = 0; i < label.length; i++){
				if (1.0 != label[i] && '1' != tag[i]){
					select_partten_label.add(JunHVector.vectorCat(partten[i], -1));
					tag[j] = '1';
					break;
				}
			}
		}
		
		return JunHMatrix.exchangeVDArrToD2Arr(select_partten_label);
	}
	
	// rand under negative sampling
	// make negative sample 
	// self switch to binary problem 
	// the last dimension is label
	public static double[][] randUnderSampleSelect(double[][] partten, double[] label, int positive_class, int negative_ratio){
		double[][] positive_partten_label = getAllXClassSample(partten, label, positive_class);
		double[][] negative_partten_label = getAllNotXClassSample(partten, label, positive_class);
		
		int positive_sample_num = positive_partten_label.length;
		int negative_sample_num = negative_partten_label.length > negative_ratio*positive_sample_num 
				? negative_ratio*positive_sample_num : negative_partten_label.length;
		
		int rand_switch_time = 500;
		Random rand = new Random(921219);
		for (int i = 0; i < rand_switch_time; i++){
			int a = Math.abs(rand.nextInt()%negative_partten_label.length);
			int b = Math.abs(rand.nextInt()%negative_partten_label.length);
			double[] tmp = negative_partten_label[a];
			negative_partten_label[a] = negative_partten_label[b];
			negative_partten_label[b] = tmp;
 		}
		
		Vector<double[]> select_partten_label = new Vector<double[]>();
		for (int i = 0; i < negative_sample_num; i++){
			select_partten_label.add(negative_partten_label[i]);
		}
		for (int i = 0; i < positive_sample_num; i++){
			select_partten_label.add(positive_partten_label[i]);
		}
		
		return JunHMatrix.exchangeVDArrToD2Arr(select_partten_label);
	}
	
	// select all of class is X samples (the last Dimension is label)
	private static double[][] getAllXClassSample(double[][] partten, double[] label, double X_class){
		int len = label.length;
		if (partten.length != label.length){
			System.err.println("Partten not match!");
		}
		
		Vector<double[]> tAns = new Vector<double[]>();
		for (int i = 0; i < len; i++){
			if (X_class == label[i]){
				tAns.add(JunHVector.vectorCat(partten[i], X_class)); //swich to binay problem
			}
		}
		
		int size = tAns.size();
		double[][] ans = new double[size][tAns.get(0).length];
		for (int i = 0; i < size; i++){
			ans[i] = tAns.get(i);
		}
		return ans;
	}
	
	// select all of class is X samples (the last Dimension is label)
	private static double[][] getAllNotXClassSample(double[][] partten, double[] label, double X_class){
		int len = label.length;
		if (partten.length != label.length){
			System.err.println("Partten not match!");
		}
		
		Vector<double[]> tAns = new Vector<double[]>();
		for (int i = 0; i < len; i++){
			if (X_class != label[i]){
				tAns.add(JunHVector.vectorCat(partten[i], -1*X_class)); //swich to binay problem
			}
		}
		
		int size = tAns.size();
		double[][] ans = new double[size][tAns.get(0).length];
		for (int i = 0; i < size; i++){
			ans[i] = tAns.get(i);
		}
		return ans;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
