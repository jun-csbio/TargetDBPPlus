package _sample;
import java.util.Date;
import java.util.Random;
import java.util.Vector;

import _util._Matrix;


public class _Sampling {
	
	// Random under sampling
	public static Vector<double[]> RUS(Vector<double[]> osams, int negaDivPosi){
		if (negaDivPosi <= 0)
			return osams;
		
		Vector<double[]> oposis = new Vector<double[]>();
		Vector<double[]> onegas = new Vector<double[]>();
		for (int i = 0; i < osams.size(); i++){
			double[] sam = osams.get(i);
			if (1.0 == sam[sam.length-1]){
				oposis.add(sam);
			}else{
				onegas.add(sam);
			}
		}
		
		Vector<double[]> ans = new Vector<double[]>();
		ans.addAll(oposis);
		
		Vector<double[]> select_negas = new Vector<double[]>();
        int posi_num = oposis.size();
        int nega_num = onegas.size();
        int select_nega_num = posi_num * negaDivPosi;
        if (select_nega_num < nega_num) {
        	Random r = new Random(new Date().getTime());
            for (int i = 0; i < select_nega_num; i++){
            	int pos = Math.abs(r.nextInt() % onegas.size());
            	select_negas.add(onegas.get(pos));
            	onegas.remove(pos);
            }
            
            ans.addAll(select_negas);
        } else {
        	ans.addAll(onegas);
        }
        
        return ans;
    } 
	
	// Random under sampling
	public static Vector<double[]> RUS(Vector<double[]> osams, int posi_sam_num, int nega_sam_num) {

		Vector<double[]> oposis = new Vector<double[]>();
		Vector<double[]> onegas = new Vector<double[]>();
		for (int i = 0; i < osams.size(); i++) {
			double[] sam = osams.get(i);
			if (1.0 == sam[sam.length - 1]) {
				oposis.add(sam);
			} else {
				onegas.add(sam);
			}
		}

		Vector<double[]> ans = new Vector<double[]>();
		int posi_num = oposis.size();
		
		if (posi_sam_num < posi_num) {
			Random r = new Random(new Date().getTime());
			for (int i = 0; i < posi_sam_num; i++) {
				int pos = Math.abs(r.nextInt() % oposis.size());
				ans.add(oposis.get(pos));
				oposis.remove(pos);
			}

		} else {
			ans.addAll(oposis);
		}
		
		int nega_num = onegas.size();
		if (nega_sam_num < nega_num) {
			Random r = new Random(new Date().getTime());
			for (int i = 0; i < nega_sam_num; i++) {
				int pos = Math.abs(r.nextInt() % onegas.size());
				ans.add(onegas.get(pos));
				onegas.remove(pos);
			}

		} else {
			ans.addAll(onegas);
		}

		return ans;
	} 
	
	// Random under sampling
	public static double[][] RUS(double[][] osams, int negaDivPosi) {
		if (negaDivPosi <= 0)
			return osams;

		Vector<double[]> oposis = new Vector<double[]>();
		Vector<double[]> onegas = new Vector<double[]>();
		for (int i = 0; i < osams.length; i++) {
			double[] sam = osams[i];
			if (1.0 == sam[sam.length - 1]) {
				oposis.add(sam);
			} else {
				onegas.add(sam);
			}
		}

		Vector<double[]> ans = new Vector<double[]>();
		ans.addAll(oposis);

		Vector<double[]> select_negas = new Vector<double[]>();
		int posi_num = oposis.size();
		int nega_num = onegas.size();
		int select_nega_num = posi_num * negaDivPosi;
		if (select_nega_num < nega_num) {
			Random r = new Random(new Date().getTime());
			for (int i = 0; i < select_nega_num; i++) {
				int pos = Math.abs(r.nextInt() % onegas.size());
				select_negas.add(onegas.get(pos));
				onegas.remove(pos);
			}

			ans.addAll(select_negas);
		} else {
			ans.addAll(onegas);
		}

		return _Matrix.exchangeVDArrToD2Arr(ans);
	} 
	
	// Random over sampling
	public static Vector<double[]> ROS(Vector<double[]> osams, int negaDivPosi){
		Vector<double[]> ans = new Vector<double[]>();
		
		Vector<double[]> oposis = new Vector<double[]>();
		Vector<double[]> onegas = new Vector<double[]>();
		for (int i = 0; i < osams.size(); i++){
			double[] sam = osams.get(i);
			if (1.0 == sam[sam.length-1]){
				oposis.add(sam);
			}else{
				onegas.add(sam);
			}
		}
		
		ans.addAll(oposis);
		ans.addAll(onegas);
		
		int nega_num = onegas.size();
		int sel_posi_num = (nega_num/negaDivPosi - oposis.size());
		Random r = new Random(new Date().getTime());
		for (int i = 0; i < sel_posi_num; i++){
			int pos = Math.abs(r.nextInt() % oposis.size());
			ans.add(oposis.get(pos));
		}
		
		return ans;
	}

}
