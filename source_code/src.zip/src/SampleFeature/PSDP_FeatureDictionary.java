package SampleFeature;

import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;

public class PSDP_FeatureDictionary {
	// iNitro-Tyr: Prediction of Nitrotyrosine Sites in Proteins with General Pseudo Amino Acid Composition��
	
	private String seq_fasta;
	private int win_size;
	
	public PSDP_FeatureDictionary(String seq_fasta, int win_size){
		this.seq_fasta = seq_fasta;
		this.win_size = win_size;
	}
	
	public double[][] constructDipetideDictWithoutLab(){
		HashMap<String, Integer> indexHM = constructDipetideIndexHM();
		
		double[][] dict = new double[win_size-1][AminoAcidDict.length()*AminoAcidDict.length()];
		HashMap<String, String> seqHM = FileUtil.parseFASTAProteinSeqs(seq_fasta);
		Object[] ids = seqHM.keySet().toArray();
		int total_num = 0;
		for (int i = 0; i < ids.length; i++){
			String seq = seqHM.get(ids[i]);
			for (int j = 0; j < seq.length()-win_size+1; j++){
				String win_content = seq.substring(j, j+win_size);
				for (int k = 0; k < win_size-1; k++){
					String dipetide = win_content.substring(k, k+2);
					int index = indexHM.get(dipetide.toUpperCase());
					dict[k][index]++;
				}
				total_num++;
			}
		}
		
		for (int i = 0; i < win_size-1; i++){
			for (int j = 0; j < AminoAcidDict.length()*AminoAcidDict.length(); j++){
				dict[i][j] /= total_num;
			}
		}
		
		return dict;
	}

	public HashMap<String, double[][]> constructDipetideDictWithLab(String lab_fasta){
		HashMap<String, Integer> indexHM = constructDipetideIndexHM();
		
		double[][] posi_dict = new double[win_size-1][AminoAcidDict.length()*AminoAcidDict.length()];
		double[][] nega_dict = new double[win_size-1][AminoAcidDict.length()*AminoAcidDict.length()];
		HashMap<String, String> seqHM = FileUtil.parseFASTAProteinSeqs(seq_fasta);
		HashMap<String, String> labHM = FileUtil.parseFASTAProteinSeqs(lab_fasta);
		Object[] ids = seqHM.keySet().toArray();
		int posi_total_num = 0;
		int nega_total_num = 0;
		for (int i = 0; i < ids.length; i++){
			String seq = seqHM.get(ids[i]);
			String lab = labHM.get(ids[i]);
			for (int j = 0; j < seq.length()-win_size+1; j++){
				char lab_j = lab.charAt(j + (win_size-1)/2);
				
				String win_content = seq.substring(j, j+win_size);
				for (int k = 0; k < win_size-1; k++){
					String dipetide = win_content.substring(k, k+2);
					int index = indexHM.get(dipetide.toUpperCase());
					if ('1' == lab_j){
						posi_dict[k][index]++;
					}else{
						nega_dict[k][index]++;
					}
				}
				if ('1' == lab_j){
					posi_total_num++;
				}else{
					nega_total_num++;
				}
			}
		}
		
		for (int i = 0; i < win_size-1; i++){
			for (int j = 0; j < AminoAcidDict.length()*AminoAcidDict.length(); j++){
				posi_dict[i][j] /= posi_total_num;
				nega_dict[i][j] /= nega_total_num;
			}
		}
		
		HashMap<String, double[][]> ans = new HashMap<String, double[][]>();
		ans.put("POSI", posi_dict);
		ans.put("NEGA", nega_dict);
		
		return ans;
	}
	
	public static HashMap<String, Integer> constructDipetideIndexHM(){
		HashMap<String, Integer> index = new HashMap<String, Integer>();
		int tmp = 0;
		for (int i = 0; i < AminoAcidDict.length(); i++){
			char aa_i = AminoAcidDict.charAt(i);
			for (int j = 0; j < AminoAcidDict.length(); j++){
				char aa_j = AminoAcidDict.charAt(j);
				index.put(""+aa_i+aa_j, tmp++);
			}
		}
		
		return index;
	}
	
	public static void main(String[] args) {
		PSDP_FeatureDictionary hh = new PSDP_FeatureDictionary("F:/Academic/TargetDNANew/TargetDNA/3.5A-DNASeqInPDB20151010-CutOff30-Before20131010.fasta", 
				17);
		HashMap<String, double[][]> dicts = hh.constructDipetideDictWithLab("F:/Academic/TargetDNANew/TargetDNA/3.5A-DNALabInPDB20151010-CutOff30-Before20131010.fasta");
		
		for (int i = 0; i < dicts.get("NEGA").length; i++){
			for (int j = 0; j < 10; j++){
				System.out.print(dicts.get("NEGA")[i][j]+" ");
			}
			System.out.println();
		}
	}

	public static final String AminoAcidDict = "ACDEFGHIKLMNPQRSTVWY";
}
