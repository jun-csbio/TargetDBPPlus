package SampleFeature;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

import edu.njust.csbio.tools.FileUtil;

// ÿ�������ʵ������������Ƿ���һ��������
public class ProteinLevelBalanceLibsvmSample {
	private static String fasta_path = "./3.5A-DNASeqInPDB20151010-CutOff30.fasta";
	private static String libsvm_folders = "./Swiss-ProtBasedFeatures/3.5A-DNAInPDB20151010-CutOff30-Samples";
	private static String singal_protein_sample_suffix = "_serialPSSM11.libsvm";
	private static int nega_div_posi = 2; //0 represents all negative samples is selected
	private static String save_path = "./Swiss-ProtBasedFeatures/3.5A-DNAInPDB20151010-CutOff30-Before20131010-Samples-P1N2-serialPSSM11.libsvm";

	public static void main(String[] args) throws Exception {
//		if (5 != args.length) {
//			System.out
//					.println("eg: \n"
//							+ "java -Xmn256m -Xms512m -Xmx10240m ProteinLevelBalanceLibsvmSample "
//							+ "fasta_path libsvm_folders singal_protein_sample_suffix nega_div_posi save_path");
//			System.exit(-1);
//		}
//		
//		fasta_path = args[0];
//		libsvm_folders = args[1];
//		singal_protein_sample_suffix = args[2];
//		nega_div_posi = Integer.parseInt(args[3]);
//		save_path = args[4];

		HashMap<String, String> proteins = FileUtil
				.parseFASTAProteinSeqs(fasta_path);
		Object[] ids = proteins.keySet().toArray();

		FileWriter balance_fw = new FileWriter(save_path);
		for (int i = 0; i < ids.length; i++) {
			System.out.println(ids[i] + " is processing ... ");
			
			if (nega_div_posi <= 0){ //�����в���
				BufferedReader br = new BufferedReader(new FileReader(
						libsvm_folders + "/" + ids[i] + singal_protein_sample_suffix));
				String line = br.readLine();
				while (null != line) {
					balance_fw.write(line+"\n");
					line = br.readLine();
				}
				br.close();
			}else{
				StringBuffer posi_samples = new StringBuffer();
				StringBuffer nega_samples = new StringBuffer();
				BufferedReader br = new BufferedReader(new FileReader(
						libsvm_folders + "/" + ids[i] + singal_protein_sample_suffix));
				String line = br.readLine();
				while (null != line) {
					if (line.startsWith("1	1:")) {
						posi_samples.append(line + "\n");
					} else {
						nega_samples.append(line + "\n");
					}
					
					line = br.readLine();
				}
				br.close();
				
				int posi_num = posi_samples.toString().split("\n").length;
				String[] nega_samples_arr = nega_samples.toString().split("\n");
				int nega_num = posi_num * nega_div_posi;
				if (nega_samples_arr.length > nega_num) {
					// ����ԭ�е�˳��
					int times = nega_samples_arr.length / 2;
					Random rand = new Random(new Date().getTime());
					for (int j = 0; j < times; j++) {
						int a = Math.abs(rand.nextInt() % nega_samples_arr.length);
						int b = Math.abs(rand.nextInt() % nega_samples_arr.length);
						String tmp = nega_samples_arr[a];
						nega_samples_arr[a] = nega_samples_arr[b];
						nega_samples_arr[b] = tmp;
					}
					
					balance_fw.write(posi_samples.toString());
					for (int j = 0; j < nega_num; j++) {
						balance_fw.write(nega_samples_arr[j] + "\n");
					}
				} else {
					balance_fw.write(posi_samples.toString()
							+ nega_samples.toString());
				}
			}
		}
		balance_fw.close();

		System.out.println("ProteinLevelBalanceLibsvmSample END");
	}

}
