package SampleFeature;

public class FeatureMatrixProcessor {
	// The idea is from "Identifying DNA-binding proteins by combining support vector machine and PSSM distance transformation"
	// written by JunH at 20151110
	
	private double[][] feaMatrix;
	
	public FeatureMatrixProcessor(double[][] feaMatrix){
		this.feaMatrix = feaMatrix;
	}
	
	public double[] serialCombine(){
		// �������������ȵķ�ʽ����������
		int row = feaMatrix.length;
		int col = feaMatrix[0].length;
		
		double[] vec = new double[row*col];
		for (int i = 0; i < row; i++){
			for (int j = 0; j < col; j++){
				vec[i*col+j] = feaMatrix[i][j];
			}
		}
		
		return vec;
	}
	
	/**
	 * @param LG : ��PsePSSM�е�Gһ��
	 * @return : len = col*col*LG
	 * @author PSSM distance transformation of "Identifying DNA-binding proteins by combining support vector machine and PSSM distance transformation"
	 * */
	public double[] matrixDistanceTransform(int LG){
		int row = feaMatrix.length;
		int col = feaMatrix[0].length;
		if (LG >= row) System.out.println("Warning: " + LG +" >= " + row);
		double[] rec = new double[col*col*LG];
		
		for (int aa1 = 0; aa1 < col; aa1++){
			for (int aa2 = 0; aa2 < col; aa2++){
				for (int lg = 1; lg <= LG; lg++){
					double lg_value = 0.0;
					for (int i = 0; i < row - lg; i++){
						lg_value += feaMatrix[i][aa1] * feaMatrix[i+lg][aa2];
					}
					lg_value /= (row-lg);
					
					rec[aa1*col*LG+aa2*LG+(lg-1)] = lg_value;
				}
			}
		}
		
		return rec;
	}
	
//	public static void main(String[] args) {
//		double[][] matrix = {{1, 2}, {3, 4}, {5, 6}};
//		FeatureMatrixProcessor feaMtxPro = new FeatureMatrixProcessor(matrix);
//		double[] serial_rec = feaMtxPro.serialCombine();
//		double[] mdt_rec = feaMtxPro.matrixDistanceTransform(2);
//		
//		for (int i = 0; i < mdt_rec.length; i++){
//			System.out.print(mdt_rec[i] + " ");
//		}
//		
//		System.out.println();
//	}

}
