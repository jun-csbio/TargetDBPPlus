package FASTADataProcessor;

import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;

public class OutputProteinsInAFastaOutBFasta {
	private static String AFasta = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNASeqInPDB20151010-Before20141010-CutOff50.fasta";
	private static String BFasta = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNALabInPDB20151010-CutOff30.fasta";
		
	public static void main(String[] args) {
		HashMap<String, String> aProteins = FileUtil.parseFASTAProteinSeqs(AFasta);
		HashMap<String, String> bProteins = FileUtil.parseFASTAProteinSeqs(BFasta);
		Object[] aids = aProteins.keySet().toArray();
		int absent_num = 0;
		for (int i = 0; i < aids.length; i++){
			if (null == bProteins.get(aids[i])){
				System.out.println(">"+aids[i]+"\n"+aProteins.get(aids[i]));
				absent_num++;
			}
		}
		
		System.out.println("Absent number is " + absent_num);
	}
}
