package FASTADataProcessor;

import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;

public class CountPosiNegaSampNumFromFasta {
	private static String lab_fasta = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNALabInPDB20151010-CutOff30-After20141010.fasta";
	
	public static void main(String[] args) {
		HashMap<String, String> proteins = FileUtil.parseFASTAProteinSeqs(lab_fasta);
		Object[] ids = proteins.keySet().toArray();
		int posi_count = 0;
		int nega_count = 0;
		for (int i = 0; i < ids.length; i++){
			String lab = proteins.get(ids[i]);
			for (int j = 0; j < lab.length(); j++){
				if (lab.charAt(j) == '1'){
					posi_count++;
				}else{
					nega_count++;
				}
			}
		}
		
		System.out.println("Posi Sam Num : " + posi_count + "\nNega Sam Num : "+nega_count);
	}

}
