package FASTADataProcessor;

import java.io.FileWriter;
import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;

public class FastaIDsReader {
	private static String fasta = "F:/Academic/TargetDNANew/TargetDNA/5FoldCVTest/fold_1/train_seq.fasta";
	private static String save_ids = "F:/Academic/TargetDNANew/TargetDNA/5FoldCVTest/fold_1/train.ids";
	
	public static void main(String[] args)throws Exception {
		HashMap<String, String> proteins = FileUtil.parseFASTAProteinSeqs(fasta);
		Object[] ids = proteins.keySet().toArray();
		FileWriter fw = new FileWriter(save_ids);
		for (int i = 0; i < ids.length; i++){
			String id = ((String)ids[i]).trim();
			fw.write(id+"\n");
		}
		fw.close();
		
		System.out.println("END");
	}
}
