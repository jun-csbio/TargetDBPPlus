package FASTADataProcessor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;

public class GetTheIdentityBetweenTwoFASTA {
	private static String fasta_file1 = "F:/Academic/TargetDNANew/TargetDNA/DBP374-seq.fasta";
	private static String fasta_file2 = "F:/Academic/TargetDNANew/TargetDNA/DBP374-seq.fasta";
	private static String condition_save_path = "F:/Academic/TargetDNANew/TargetDNA/DBP374-seq-sameIdentity.txt";
	
	public static void main(String[] args)throws Exception {
		String max_identity_pair = "";
		double max_identity = Double.MIN_VALUE;
		
		HashMap<String, String> first_set = FileUtil.parseFASTAProteinSeqs(fasta_file1);
		HashMap<String, String> second_set = FileUtil.parseFASTAProteinSeqs(fasta_file2);
		Object[] first_ids = first_set.keySet().toArray();
		Object[] second_ids = second_set.keySet().toArray();
		for (int i = 0; i < first_ids.length; i++){
			for (int j = 0; j < second_ids.length; j++){
				String seq1 = first_set.get(first_ids[i]);
				String seq2 = second_set.get(second_ids[j]);
				
				if (seq1.equals(seq2)){
					continue;
				}
				
				double identity = calculateIdentityBetweenTwoProteins(seq1, seq2);
				
				if (identity > 25){
					FileUtil.writeToFileLineByLine(first_ids[i]+" - "+second_ids[j] +" : " + identity + " identity", condition_save_path);
					System.out.println(first_ids[i]+" "+second_ids[j] +" : " + identity + " identity");
				}
				
				if (identity > max_identity){
					max_identity = identity;
					max_identity_pair = first_ids[i]+" "+second_ids[j];
				}
			}
		}
		
		System.out.println("\n\n"+max_identity_pair+" : " + max_identity + " identity");
	}
	
	private static double calculateIdentityBetweenTwoProteins(String seq1, String seq2)throws Exception {
		double ans = 0;
		
		FileWriter fw1 = new FileWriter("./tmp1");
		fw1.write(">tmp1\n"+seq1);
		fw1.close();
		FileWriter fw2 = new FileWriter("./tmp2");
		fw2.write(">tmp2\n"+seq2);
		fw2.close();
		
		try {
			String cmd = "D:/blast-2.2.26/bin/bl2seq -i ./tmp1 -j ./tmp2 -p blastp -o ./tmp.out";
			
			Process process = Runtime.getRuntime().exec(cmd);
			
			StreamGobbler errorGobbler = new StreamGobbler(process.getErrorStream(), "Error");
			StreamGobbler outputGobbler = new StreamGobbler(process.getInputStream(), "Output");
			errorGobbler.start();
			outputGobbler.start();
			
			int exitVal = process.waitFor();
//			System.out.print("exitVal = " + exitVal);
			process.destroy();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		BufferedReader br = new BufferedReader(new FileReader("./tmp.out"));
		String line = br.readLine();
		boolean isBreak = false;
		while (null != line){
			if (line.contains("Identities")){
				isBreak = true;
				break;
			}
			line = br.readLine();
		}
		br.close();
		
		if (isBreak){
			String[] lc = line.split(",");
			int hit_num = Integer.parseInt(lc[0].substring(lc[0].indexOf('/')+1, lc[0].indexOf('(')).trim());
			double now_identity = Double.parseDouble(lc[0].substring(lc[0].indexOf('(')+1, lc[0].indexOf('%')).trim());
			
			ans = now_identity * (2*hit_num)/(seq1.length()+seq2.length());
		}
		
		return ans;
	}

}


class StreamGobbler extends Thread {
	InputStream is;
	String type;

	StreamGobbler(InputStream is, String type) {
		this.is = is;
		this.type = type;
				
	}

	public void run() {
		try {
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			String line = null;
			while ((line = br.readLine()) != null) {
				if (type.equals("Error")){
					System.out.print(line + "\n");
				}else {
					System.out.print(line + "\n");
				}
			}
		} catch (IOException ioe) {
			//ioe.printStackTrace();
		}
	}
}