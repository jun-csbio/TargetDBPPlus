package FASTADataProcessor;

import java.util.HashMap;

import _util._File;

public class TransformDownloadSeqInfoToNormalFasta {
	private static String downloaded_seqinfo_fa;
	private static String saving_normal_fa;
	
	public static void main(String[] args) {
		if (2 != args.length){
			System.out.println("downloaded_seqinfo_fa (String) : Path of the fasta information downloaded from PDB server");
			System.out.println("saving_normal_fa      (String) : Path of the normal fasta information after transforming");
			System.exit(-1);
		}
		
		downloaded_seqinfo_fa = args[0];
		saving_normal_fa = args[1];
		
		HashMap<String, String> saving_hm = new HashMap<String, String>();
		
		HashMap<String, String> all_proteins_hm = _File.loadFasta(downloaded_seqinfo_fa, false);
		Object[] ids = all_proteins_hm.keySet().toArray();
		for (int i = 0; i < ids.length; i++){
			String protinfo = (String)ids[i];
			String protseq = all_proteins_hm.get(protinfo).replaceAll("\n", "").replaceAll("\r", "").replaceAll(" ", "").replaceAll("\t", "").toUpperCase();
			
			String prot_id = protinfo.substring(0, 4);
			char chain = protinfo.charAt(5);
			
			String protname = (prot_id+chain).toUpperCase();
		
			saving_hm.put(protname, protseq);
		}
		
		_File.writeToFASTAFile(saving_hm, saving_normal_fa);
		
		System.out.println("Have a good day!");
	}


}
