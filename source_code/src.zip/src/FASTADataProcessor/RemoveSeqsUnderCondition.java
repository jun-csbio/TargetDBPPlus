package FASTADataProcessor;

import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;

public class RemoveSeqsUnderCondition {
// ������Ҫ�Ǹ���ض�����ɾ��һЩ�����Ҫ�������
	private static String fasta_path = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNALabInPDB20151010-CutOff30.fasta";
	private static String save_path = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNALabInPDB20151010-CutOff30-newdelete.fasta";
	
	public static void main(String[] args) {
//		selectLenRegion(20, Integer.MAX_VALUE);
		removeLabAllOne("F:/Academic/TargetDNANew/TargetDNA/3.5A-DNALabInPDB20151010-CutOff30.fasta");
		
//		removePosiLabJustLitte("F:/Academic/TargetDNANew/TargetDNA/3.5A-DNALabInPDB20151010.fasta", 5);
	}

	// ѡȡ�̶�������������
	private static void selectLenRegion(int shortest, int longest){
		HashMap<String, String> proteins = new HashMap<String, String>();
		
		HashMap<String, String> exProteins = FileUtil.parseFASTAProteinSeqs(fasta_path);
		Object[] ids = exProteins.keySet().toArray();
		for (int i = 0; i < ids.length; i++){
			String content = exProteins.get(ids[i]);
			int len = content.length();
			if (len >= shortest && len <= longest){
				proteins.put((String)ids[i], content);
			}else{
				System.out.println("the "+ids[i] +" is removed !");
			}
		}
		
		FileUtil.writeToFASTAFile(proteins, save_path);
	}
	
	/**
	 * @author ȥ��labȫ��1������
	 * */
	private static void removeLabAllOne(String lab_fasta){
		HashMap<String, String> proteins = new HashMap<String, String>();
		int selectNum = 0;
		
		HashMap<String, String> exLabs = FileUtil.parseFASTAProteinSeqs(lab_fasta);
		HashMap<String, String> exProteins = FileUtil.parseFASTAProteinSeqs(fasta_path);
		Object[] ids = exProteins.keySet().toArray();
		for (int i = 0; i < ids.length; i++){
			String lab = exLabs.get(ids[i]);
			String content = exProteins.get(ids[i]);
			if (lab.contains("0") || lab.contains("2")){
				proteins.put((String)ids[i], content);
			}else{
				System.out.println("the "+ids[i]+" is removed !");
			}
		}
		
		FileUtil.writeToFASTAFile(proteins, save_path);
	}
	
	/**
	 * @author ȥ��labȫ��1������
	 * */
	private static void removePosiLabJustLitte(String lab_fasta, int minimum_posi_num_per_protein){
		HashMap<String, String> proteins = new HashMap<String, String>();
		
		HashMap<String, String> exLabs = FileUtil.parseFASTAProteinSeqs(lab_fasta);
		HashMap<String, String> exProteins = FileUtil.parseFASTAProteinSeqs(fasta_path);
		Object[] ids = exProteins.keySet().toArray();
		for (int i = 0; i < ids.length; i++){
			String lab = exLabs.get(ids[i]);
			int posi_sam_num = 0;
			for (int j = 0; j < lab.length(); j++){
				if ('1' == lab.charAt(j)){
					posi_sam_num++;
				}
			}
			
			String content = exProteins.get(ids[i]);
			if (minimum_posi_num_per_protein < posi_sam_num){
				proteins.put((String)ids[i], content);
			}else{
				System.out.println("the "+ids[i] +" is removed !");
			}
		}
		
		FileUtil.writeToFASTAFile(proteins, save_path);
	}
	
}
