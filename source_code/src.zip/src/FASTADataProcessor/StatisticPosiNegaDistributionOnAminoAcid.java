package FASTADataProcessor;

import java.text.DecimalFormat;
import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;

public class StatisticPosiNegaDistributionOnAminoAcid {
	private static String seq_fasta = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNASeqInPDB20151010-CutOff30-Before20141010.fasta";
	private static String lab_fasta = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNALabInPDB20151010-CutOff30-Before20141010.fasta";
	
	public static void main(String[] args) {
		double[] count_all = new double[AMINOACIDS.length()];
		double[] count_pos = new double[AMINOACIDS.length()];
		double[] count_neg = new double[AMINOACIDS.length()];
		for (int i = 0; i < AMINOACIDS.length(); i++){
			count_all[i] = 0;
			count_pos[i] = 0;
			count_neg[i] = 0;
		}
		
		HashMap<String, String> seqHM = FileUtil.parseFASTAProteinSeqs(seq_fasta);
		HashMap<String, String> labHM = FileUtil.parseFASTAProteinSeqs(lab_fasta);
		Object[] ids = seqHM.keySet().toArray();
		for (int i = 0; i < ids.length; i++){
			String seq = seqHM.get(ids[i]);
			String lab = labHM.get(ids[i]);
			
			for (int j = 0; j < seq.length(); j++){
				char aa = seq.charAt(j);
				char ll = lab.charAt(j);
				
				int index = AMINOACIDS.indexOf(aa);
				count_all[index]++;
				if ('1' == ll){
					count_pos[index]++;
				}else{
					count_neg[index]++;
				}
			}
		}
		
		for (int i = 0; i < AMINOACIDS.length(); i++){
			count_pos[i] /= count_all[i];
			count_neg[i] /= count_all[i];
		}

		DecimalFormat df = new DecimalFormat();
		df.applyPattern("#0.000");
		System.out.println("Amino Acid\tPosi Lab\tNega Lab");
		for (int i = 0; i < AMINOACIDS.length(); i++){
			System.out.println(AMINOACIDS.charAt(i)+"\t"+df.format(count_pos[i])+"\t"+df.format(count_neg[i]));
		}
	}

//	private static final String AMINOACIDS = "ACDEFGHIKLMNPQRSTVWY";
	private static final String AMINOACIDS = "IVLFCMAGTSWYPHNDQEKR";
}
