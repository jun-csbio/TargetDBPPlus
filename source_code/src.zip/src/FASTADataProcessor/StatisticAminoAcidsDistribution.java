package FASTADataProcessor;

import java.text.DecimalFormat;
import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;

public class StatisticAminoAcidsDistribution {
	private static String seq_fasta = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNASeqInPDB20151010-CutOff30-Before20141010.fasta";
	private static String lab_fasta = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNALabInPDB20151010-CutOff30-Before20141010.fasta";
	
	public static void main(String[] args) {
		int num_all = 0;
		int num_pos = 0;
		int num_neg = 0;
		double[] count_all = new double[AMINOACIDS.length()];
		double[] count_pos = new double[AMINOACIDS.length()];
		double[] count_neg = new double[AMINOACIDS.length()];
		for (int i = 0; i < AMINOACIDS.length(); i++){
			count_all[i] = 0;
			count_pos[i] = 0;
			count_neg[i] = 0;
		}
		
		HashMap<String, String> seqHM = FileUtil.parseFASTAProteinSeqs(seq_fasta);
		HashMap<String, String> labHM = FileUtil.parseFASTAProteinSeqs(lab_fasta);
		Object[] ids = seqHM.keySet().toArray();
		for (int i = 0; i < ids.length; i++){
			String seq = seqHM.get(ids[i]);
			String lab = labHM.get(ids[i]);
			
			for (int j = 0; j < seq.length(); j++){
				char aa = seq.charAt(j);
				char ll = lab.charAt(j);
				
				int index = AMINOACIDS.indexOf(aa);
				count_all[index]++;
				num_all++;
				if ('1' == ll){
					count_pos[index]++;
					num_pos++;
				}else{
					count_neg[index]++;
					num_neg++;
				}
			}
		}
		
		for (int i = 0; i < AMINOACIDS.length(); i++){
			count_all[i] /= num_all;
			count_pos[i] /= num_pos;
			count_neg[i] /= num_neg;
		}

		DecimalFormat df = new DecimalFormat();
		df.applyPattern("#0.000");
		System.out.println("Amino Acid\tWithout Lab\tPosi Lab\tNega Lab");
		for (int i = 0; i < AMINOACIDS.length(); i++){
			System.out.println(AMINOACIDS.charAt(i)+"\t"+df.format(count_all[i])+"\t"+df.format(count_pos[i])+"\t"+df.format(count_neg[i]));
		}
	}

//	private static final String AMINOACIDS = "ACDEFGHIKLMNPQRSTVWY";
	private static final String AMINOACIDS = "IVLFCMAGTSWYPHNDQEKR";
}
