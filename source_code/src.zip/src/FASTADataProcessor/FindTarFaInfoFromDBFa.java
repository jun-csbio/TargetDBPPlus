package FASTADataProcessor;

import java.util.HashMap;

import _util._File;
import edu.njust.csbio.tools.FileUtil;

public class FindTarFaInfoFromDBFa {
	private static String tar_fasta = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNASeqInPDB20151010-CutOff30.fasta";
	private static String db_fasta = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNASeqInPDB20151010.fasta";
	private static String save_fasta = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNASeqInPDB20151010-CutOff30.fasta";
	
	public static void main(String[] args){
		if (3 != args.length){
			System.out.println("tar_fasta  (String) : Path of the target fasta");
			System.out.println("db_fasta   (String) : Path of the database fasta");
			System.out.println("save_fasta (String) : Path of the saving fasta");
			
			System.exit(-1);
		}
		
		tar_fasta  = args[0];
		db_fasta   = args[1];
		save_fasta = args[2];
		
		HashMap<String, String> proteins = new HashMap<String, String>();
		
		HashMap<String, String> tar_hm = _File.loadFasta(tar_fasta, true);
		HashMap<String, String> db_hm  = _File.loadFasta(db_fasta, true);
		
		Object[] tar_ids = tar_hm.keySet().toArray();
		for (int i = 0; i < tar_ids.length; i++){
			
			String content = db_hm.get(tar_ids[i]);
			if (null == content){
				System.out.println(tar_ids[i] + " " + tar_fasta + " is not contained on " + db_fasta);
			}
			
			proteins.put((String)tar_ids[i], content);
		}
		
		FileUtil.writeToFASTAFile(proteins, save_fasta);
		
		System.out.println("END");
	}
	
}
