package FASTADataProcessor;

import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;

public class CountCareAAsPosiNegaNumFromFasta {
	private static String seq_fasta = "F:/Academic/TargetDNANew/TargetDNA/10FoldCVTest/fold_2/train_seq.fasta";
	private static String lab_fasta = "F:/Academic/TargetDNANew/TargetDNA/10FoldCVTest/fold_2/train_label.fasta";
	private static String careAAs = "IVLFCMAWY"; // "GTSPHNDQEKR"; // 
	
	public static void main(String[] args) {
		HashMap<String, String> seqs = FileUtil.parseFASTAProteinSeqs(seq_fasta);
		HashMap<String, String> labs = FileUtil.parseFASTAProteinSeqs(lab_fasta);
		Object[] ids = seqs.keySet().toArray();
		int posi_count = 0;
		int nega_count = 0;
		for (int i = 0; i < ids.length; i++){
			String seq = seqs.get(ids[i]);
			String lab = labs.get(ids[i]);
			for (int j = 0; j < lab.length(); j++){
				if (!careAAs.contains(""+seq.charAt(j))){
					continue;
				}
				
				if (lab.charAt(j) == '1'){
					posi_count++;
				}else{
					nega_count++;
				}
			}
		}
		
		System.out.println("Posi Sam Num : " + posi_count + "\nNega Sam Num : "+nega_count);
	}

}
