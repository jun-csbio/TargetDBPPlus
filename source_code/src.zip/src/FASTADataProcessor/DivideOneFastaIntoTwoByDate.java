package FASTADataProcessor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;

public class DivideOneFastaIntoTwoByDate {
	private static String fasta_file = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNASeqInPDB20151010-CutOff30.fasta";
	private static String first_part = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNASeqInPDB20151010-CutOff30-Before20141010.fasta";
	private static String second_part = "F:/Academic/TargetDNANew/TargetDNA/3.5A-DNASeqInPDB20151010-CutOff30-After20141010.fasta";
	private static double time_deadline = 20141010;
	
	private static String pdb_folder = "F:/Academic/PDBDB";
	
	public static void main(String[] args)throws Exception {
		if (5 != args.length){
			System.out.println("fasta_file (String)    : Path of the original fasta file");
			System.out.println("first_part (String)    : Path of the first fasta file, which is annotated in PDB before time_deadline");
			System.out.println("second_part (String)   : Path of the first fasta file, which is annotated in PDB after time_deadline");
			System.out.println("time_deadline (double) : Time cut (e.g., 20160524)");
			System.out.println("pdb_folder (String)    : Path of the PDB folder");
			System.exit(-1);
		}
		
		fasta_file = args[0];
		first_part = args[1];
		second_part = args[2];
		time_deadline = Double.parseDouble(args[3]);
		pdb_folder = args[4];
		
		HashMap<String, String> first_HM = new HashMap<String, String>();
		HashMap<String, String> second_HM = new HashMap<String, String>();
		
		HashMap<String, String> proteins = FileUtil.parseFASTAProteinSeqs(fasta_file);
		Object[] ids = proteins.keySet().toArray(); 
		for (int i = 0; i < ids.length; i++){
			System.out.println(ids[i] + " is processing ... ");
			
			String pdb_file = pdb_folder + "/" + ((String)ids[i]).substring(0, 4).toLowerCase()+ ".pdb";
			BufferedReader br = new  BufferedReader(new FileReader(pdb_file));
			String time = (br.readLine()).substring(50, 59); //eg: 10-AUG-98
			br.close();
			
			// ʱ��ת��
			double year = Double.parseDouble(time.substring(7, 9)); 
			if (year > 15){ //����ݻ����4λ��
				year += 1900;
			}else{
				year += 2000;
			}
			String month = time.substring(3, 6);
			double mon = 0;
			if (month.equals("JAN")){
				mon = 1;
			}else if (month.equals("FEB")){
				mon = 2;
			}else if (month.equals("MAR")){
				mon = 3;
			}else if (month.equals("APR")){
				mon = 4;
			}else if (month.equals("MAY")){
				mon = 5;
			}else if (month.equals("JUN")){
				mon = 6;
			}else if (month.equals("JUL")){
				mon = 7;
			}else if (month.equals("AUG")){
				mon = 8;
			}else if (month.equals("SEP")){
				mon = 9;
			}else if (month.equals("OCT")){
				mon = 10;
			}else if (month.equals("NOV")){
				mon = 11;
			}else if (month.equals("DEC")){
				mon = 12;
			}
			double day = Double.parseDouble(time.substring(0, 2)); 
			double find_time = year*10000+mon*100+day;
			
			if (find_time < time_deadline){
				// train (first) part
				first_HM.put((String)ids[i], proteins.get(ids[i]));
			}else{
				// test (second) part
				second_HM.put((String)ids[i], proteins.get(ids[i]));
			}
		}
		
		FileUtil.writeToFASTAFile(first_HM, first_part);
		FileUtil.writeToFASTAFile(second_HM, second_part);
	}

}
