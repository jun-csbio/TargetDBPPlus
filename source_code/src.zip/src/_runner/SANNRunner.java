package _runner;

import java.util.*;

import _util.ConfigUtil;
import _util.StreamGobbler;
import _util._File;
import _util._Log;

import java.io.*;

public class SANNRunner {
	// Input 
	private String protname; // protein code
	private String protseq; // protein sequence
	private String sannResPath;
	
	public static void main(String[] args)throws Exception{
		if (2 != args.length){
			System.out.println("e.g., \n"
					+ "seqFa (String) (Path)\n"
					+ "savefolder (String) (Path)");
			System.exit(-1);
		}
		String seqFa = args[0];
		String savefolder = args[1];
		if (!new File(savefolder).exists())
			new File(savefolder).mkdirs();
		
		HashMap<String, String> seqHm = _File.loadFasta(seqFa);
		Object[] ids = seqHm.keySet().toArray();
		for (int i = 0; i < ids.length; i++){
			System.out.println(ids[i]+" is processing ...");
			String protname = (String)ids[i];
			String protseq = seqHm.get(ids[i]);
			
			new SANNRunner(protname, protseq, savefolder+"/"+protname+".a3");
		}
		
		System.out.println("Have A Good Day!");
	}
	
	public SANNRunner(String protname, String protseq, String sannResPath)throws Exception {
		this.protname = protname;
		this.protseq = protseq;
		this.sannResPath = sannResPath;
		
		if (!new File(sannResPath).isFile())
			computeSANN();
	}
	
	public String getSannResPath(){
		if (!new File(sannResPath).isFile())
			return null;
		
		return sannResPath;
	}
	
	private void computeSANN() throws Exception{
		String SANN_RUNNER_PATH = ConfigUtil.getConfig("SANN_RUNNER_PATH");
		if (null == SANN_RUNNER_PATH){
			System.out.println("The Config File does not contain SANN_RUNNER_PATH");
			_Log.dayRunLog("The Config File does not contain SANN_RUNNER_PATH", new Date());
			System.exit(-1);
		}
		
		long randID = new Date().getTime();
		
		_File.writeToFile(">"+protname+"\n"+protseq, "./"+protname+randID+".fa", false);
		try {
			String cmd = SANN_RUNNER_PATH + " " + "./"+protname+randID;
			Process process = Runtime.getRuntime().exec(cmd);
			StreamGobbler errorGobbler = new StreamGobbler(process.getErrorStream(), "Error");
			StreamGobbler outputGobbler = new StreamGobbler(process.getInputStream(), "Output");
			errorGobbler.start();
			outputGobbler.start();
			
			process.waitFor();
			process.destroy();
		} catch (Exception e) {
			deleteTempFiles(randID);
			throw e;
		}
		
		_File.copy("./"+protname+randID+".a3", sannResPath);
		deleteTempFiles(randID);
	}
	
	public double[][] getPSAProbs(){
		if (!new File(sannResPath).isFile())
			return null;
		
		return parseSANNa3Res(sannResPath);
	}
	
	private double[][] parseSANNa3Res(String a3_res_file_path){
		Vector<double[]> tAns = new Vector<double[]>();
		try{
			BufferedReader br = new BufferedReader(new FileReader(a3_res_file_path));
			br.readLine();	//remove head "# SANN VFORMAT (SANN V1.0 by K. Joo)"
			br.readLine();  //remove second line
			String line = br.readLine();
			while (null != line){
				String[] lc = line.trim().split(" +|\t");
				if (9 != lc.length){
					System.out.println(line);
					br.close();
					throw new Exception(a3_res_file_path + " may be not SANN a3 Result file");
				}
				double[] tmp = new double[3];
				try{
					tmp[0] = Double.parseDouble(lc[3]);
					if (lc[3].equalsIgnoreCase("NaN")){
						tmp[0] = 0.0;
					}
				}catch(Exception e){
					tmp[0] = 0.0;
				}
				try{
					tmp[1] = Double.parseDouble(lc[4]);
					if (lc[4].equalsIgnoreCase("NaN")){
						tmp[1] = 0.0;
					}
				}catch(Exception e){
					tmp[1] = 0.0;
				}
				try{
					tmp[2] = Double.parseDouble(lc[5]);
					if (lc[5].equalsIgnoreCase("NaN")){
						tmp[2] = 0.0;
					}
				}catch(Exception e){
					tmp[2] = 0.0;
				}
				tAns.add(tmp);
				line = br.readLine();
			}
			br.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		int size = tAns.size();
		double[][] ans = new double[size][tAns.get(0).length];
		for (int i = 0; i < size; i++){
			ans[i] = tAns.get(i);
		}
		return ans;
	} 
	
	private void deleteTempFiles(long randID){
		if (new File("./"+protname+randID+".fa").isFile())
			new File("./"+protname+randID+".fa").delete();
		
		if (new File("./"+protname+randID+".d").isFile())
			new File("./"+protname+randID+".d").delete();
		
		if (new File("./"+protname+randID+".a3").isFile())
			new File("./"+protname+randID+".a3").delete();
		
		if (new File("./"+protname+randID+".a21").isFile())
			new File("./"+protname+randID+".a21").delete();
		
		if (new File("./"+protname+randID+".a22").isFile())
			new File("./"+protname+randID+".a22").delete();
		
		if (new File("./"+protname+randID+".a23").isFile())
			new File("./"+protname+randID+".a23").delete();
		
		if (new File("./"+protname+randID+".a24").isFile())
			new File("./"+protname+randID+".a24").delete();
		
		if (new File("./"+protname+randID+".bla").isFile())
			new File("./"+protname+randID+".bla").delete();
		
		if (new File("./"+protname+randID+".chk").isFile())
			new File("./"+protname+randID+".chk").delete();
		
		if (new File("./"+protname+randID+".ck2").isFile())
			new File("./"+protname+randID+".ck2").delete();
		
		if (new File("./"+protname+randID+".prf").isFile())
			new File("./"+protname+randID+".prf").delete();
		
		if (new File("./"+protname+randID+".prsa").isFile())
			new File("./"+protname+randID+".prsa").delete();
		
		if (new File("./"+protname+randID+".rsa").isFile())
			new File("./"+protname+randID+".rsa").delete();
		
		if (new File("./"+protname+randID+".zs").isFile())
			new File("./"+protname+randID+".zs").delete();
	}
}
