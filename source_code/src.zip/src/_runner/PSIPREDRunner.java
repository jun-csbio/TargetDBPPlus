package _runner;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Date;
import java.util.Vector;

import _util.ConfigUtil;
import _util.StreamGobbler;
import _util._File;
import _util._Log;

public class PSIPREDRunner {
	// input
	private String protname;
	private String protseq;
	private Blastpgp blastpgp;
	private String tempfolder;
	
	private String saveSSpath;

	// output
	private double[][] ssProb; // C H E
	private String ssState;
	
	public static void main(String[] args) {
		if (3 != args.length){
			System.out.println("e.g.:\n" +
					"protname\n" +
					"protseq\n" +
					"tempfolder");
			System.exit(-1);
		}
		
		PSIPREDRunner psipred = new PSIPREDRunner(args[0], args[1], null, args[2]);
		System.out.println(psipred.getSSstate());
		System.out.println("HAVE A GOOD DAY");
	}

	public PSIPREDRunner(String protname, String protseq, Blastpgp blastpgp, String tempfolder) {
		this.protname = protname;
		this.protseq = protseq;
		this.blastpgp = blastpgp;
		this.tempfolder = tempfolder;
		
		if (!new File(this.tempfolder).exists())
			new File(this.tempfolder).mkdirs();
		
		if (!new File(tempfolder+"/"+protname+".ss").isFile()){
			run();
		}else{
			loadPsipredPSSstate(tempfolder+"/"+protname+".ss");
		}
	}
	
	/**
	 * @return the saveSSPath
	 */
	public String getSaveSSPath() {
		if (null == saveSSpath){
			if (!new File(tempfolder+"/"+protname+".ss").isFile()){
				run();
			}
			
			loadPsipredPSSstate(tempfolder+"/"+protname+".ss");
		}
		
		return saveSSpath;
	}
	
	public double[][] getSSProb(){
		if (null == ssProb){
			if (!new File(tempfolder+"/"+protname+".ss").isFile()){
				run();
			}
			
			loadPsipredPSSstate(tempfolder+"/"+protname+".ss");
		}
		return ssProb;
	}
	
	public String getSSstate(){
		if (null == ssState){
			if (!new File(tempfolder+"/"+protname+".ss").isFile()){
				run();
			}
			
			loadPsipredPSSstate(tempfolder+"/"+protname+".ss");
		}
		return ssState;
	}
	
	private void loadPsipredPSSstate(String psipred_res_file_path){
		Vector<double[]> _ssProb = new Vector<double[]>();
		StringBuffer _ssState = new StringBuffer();
		try{
			BufferedReader br = new BufferedReader(new FileReader(psipred_res_file_path));
			br.readLine();	//remove head "# PSIPRED VFORMAT (PSIPRED V3.2)"
			br.readLine();  //remove second line
			String line = br.readLine();
			while (null != line){
				String[] lc = line.trim().split(" +");
				if (6 != lc.length){
					throw new Exception(psipred_res_file_path + " may be not PSIPRED SS Result file");
				}
				_ssState.append(lc[2]);
				
				double[] tmp = new double[3];
				tmp[0] = Double.parseDouble(lc[3]);
				tmp[1] = Double.parseDouble(lc[4]);
				tmp[2] = Double.parseDouble(lc[5]);
				_ssProb.add(tmp);
				line = br.readLine();
			}
			br.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		int size = _ssProb.size();
		ssProb = new double[size][_ssProb.get(0).length];
		for (int i = 0; i < size; i++){
			ssProb[i] = _ssProb.get(i);
		}
		ssState = _ssState.toString();
		
		this.saveSSpath = tempfolder+"/"+protname+".ss";
	}
	
	public static double[][] loadPsipredPSSstate(String psipred_res_file_path, boolean tag){
		Vector<double[]> _ssProb = new Vector<double[]>();
		StringBuffer _ssState = new StringBuffer();
		try{
			BufferedReader br = new BufferedReader(new FileReader(psipred_res_file_path));
			br.readLine();	//remove head "# PSIPRED VFORMAT (PSIPRED V3.2)"
			br.readLine();  //remove second line
			String line = br.readLine();
			while (null != line){
				String[] lc = line.trim().split(" +");
				if (6 != lc.length){
					throw new Exception(psipred_res_file_path + " may be not PSIPRED SS Result file");
				}
				_ssState.append(lc[2]);
				
				double[] tmp = new double[3];
				tmp[0] = Double.parseDouble(lc[3]);
				tmp[1] = Double.parseDouble(lc[4]);
				tmp[2] = Double.parseDouble(lc[5]);
				_ssProb.add(tmp);
				line = br.readLine();
			}
			br.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		int size = _ssProb.size();
		double[][] ssProb = new double[size][_ssProb.get(0).length];
		for (int i = 0; i < size; i++){
			ssProb[i] = _ssProb.get(i);
		}
		
		return ssProb;
	}
	
	private void run(){
		String psipred_folder_dir = ConfigUtil.getConfig("PSIPRED321_FOLDER_DIR");
		String blastpgp_bin_path = ConfigUtil.getConfig("BLAST_BIN_DIR");
		
		if (null == psipred_folder_dir){
			System.out.println("Please check the config file items : PSIPRED321_FOLDER_DIR");
			_Log.dayRunLog("Please check the config file items : PSIPRED321_FOLDER_DIR", new Date());
			System.exit(-1);
		}
		
		if (null == blastpgp_bin_path){
			System.out.println("Please check the config file items : BLAST_BIN_DIR");
			_Log.dayRunLog("Please check the config file items : BLAST_BIN_DIR", new Date());
			System.exit(-1);
		}
		
		if (null == blastpgp){
			String save_orig_pssm = this.tempfolder + "/" + protname + ".opssm";
			String save_psitmp_chk = this.tempfolder + "/" + protname + ".psitmp.chk";
			String save_blast_out = this.tempfolder + "/" + protname + ".blast.out";
			blastpgp = new Blastpgp(protname, protseq, 
					1000, 3, 0.001, save_orig_pssm, save_psitmp_chk, save_blast_out);
		}
		
		String protFaPath = this.tempfolder + "/" + protname + ".fa";
		_File.writeToFile(">"+protname+"\n"+protseq, protFaPath, false);
		String psipred_execdir = psipred_folder_dir+"/bin";
		String psipred_datadir = psipred_folder_dir+"/data";
		String blastMakematpath = blastpgp_bin_path+"/makemat";
		saveSSpath = tempfolder+"/"+protname+".ss";
		
		/**
		 * # wirte by Jun Hu at Umich, 22 Nov. 2016
		set protname = $1 				#proterin name which is start with "P_", e.g., P_1xefA
		set protFaPath $2       		#protein sequence fasta path
		set psitmpchk = $3      		#blastpgp construct file by "-C"
		set blastout = $4				#blastpgp running output
		set execdir = $5				#psipred321/bin absolute path
		set datadir = $6				#psipred321/data absolute path
		set blastMakematpath = $7		#blast-2.2.26/makemat absolute path
		set saveSSpath = $8				#save the predicted secondary structure absolute path (with suffix ".ss")
		 */
		
		String cmd = psipred_folder_dir+"/psipredrunner" +
				" "+protname+
				" "+protFaPath+
				" "+blastpgp.getPsitmp_chkPath()+
				" "+blastpgp.getBlast_outPath()+
				" "+psipred_execdir+
				" "+psipred_datadir+
				" "+blastMakematpath+
				" "+saveSSpath;
		
		System.out.println(cmd);
		_Log.dayRunLog(cmd, new Date());
		
		try{
			Process process;
			process = Runtime.getRuntime().exec(cmd);
			StreamGobbler errorGobbler = new StreamGobbler(process.getErrorStream(), "Error");
			errorGobbler.start();
			StreamGobbler outputGobbler = new StreamGobbler(process.getInputStream(), "Output");
			outputGobbler.start();
			
			process.waitFor();
			process.destroy();
			
		}catch(Exception e){
			e.printStackTrace();
			_Log.dayRunLog("Cannot correctly run \""+cmd+"\"", new Date());
			_Log.dayRunLog(e.getMessage(), new Date());
		}
		
		new File(protFaPath).delete();
	}

}
