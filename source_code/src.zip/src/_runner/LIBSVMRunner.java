package _runner;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.Vector;

import _libsvm.svm_predict;
import _libsvm.svm_train;
import _util._File;

public class LIBSVMRunner {
	public static void train(String train_param, String train_sample_libsvm_format_file_path,
			String save_model_file_path){
		try{
			System.out.print("    Begin run svm-train, Waiting...\n");
			String param = train_param.trim() + " " + train_sample_libsvm_format_file_path + " "
					+ save_model_file_path;
			svm_train t = new svm_train();
			System.out.println(param);
			t.run(param.split(" "));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void predict(String true_label, String test_param, String test_sample_libsvm_format_file_path, 
			String libsvm_model_file_path, String save_predict_res_file_path){
		try{
			System.out.print("    Begin run svm-test, Waiting...\n");
			
			String param = test_param.trim() +" "+test_sample_libsvm_format_file_path+" "+libsvm_model_file_path+
					" " + save_predict_res_file_path+".tmp";
			
			svm_predict sp = new svm_predict();
			System.out.println(param);
			sp.run(param.split(" "));
			
			saveSVMRESToJunHFormat(save_predict_res_file_path+".tmp", true_label, save_predict_res_file_path);
			
			//delete temp file
			File delF = new File(save_predict_res_file_path+".tmp");
			if (delF.isFile()){
				delF.delete();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void predictUseSVR(String true_label, String test_param, String test_sample_libsvm_format_file_path, 
			String libsvm_model_file_path, String save_predict_res_file_path){
		try{
			System.out.print("    Begin run svm-test, Waiting...\n");
			
			String param = test_param.trim() +" "+test_sample_libsvm_format_file_path+" "+libsvm_model_file_path+
					" " + save_predict_res_file_path+".tmp";
			
			svm_predict sp = new svm_predict();
			System.out.println(param);
			sp.run(param.split(" "));
			
			saveSVMSVRRESToJunHFormat(save_predict_res_file_path+".tmp", true_label, save_predict_res_file_path);
			
			//delete temp file
			File delF = new File(save_predict_res_file_path+".tmp");
			if (delF.isFile()){
				delF.delete();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private static void saveSVMRESToJunHFormat(String svmResFilePath, String matchLabel, 
			String junHFormatSvFilePath){
		try{
			File f = new File(junHFormatSvFilePath);
			if (f.isFile()) {
//				throw new Exception("this is not Cross Validation");
			} else {
				f.createNewFile();
			}
			
			BufferedReader br = new BufferedReader(new FileReader(svmResFilePath));
			String line = br.readLine();
			String[] lc = line.split(" +");
			if (3 > lc.length) {
				br.close();
				throw new Exception(svmResFilePath + " is not libsvm file");
			}
			
			FileWriter fw = new FileWriter(f);
			
			// this is two classifier problem
			int pos = 0;
			line = br.readLine();
			while (null != line) {
				String[] tlc = line.split(" +");
				if ("-1".equals(lc[1])) { //the second col is be predict the second class probabily
					fw.write(matchLabel.substring(pos,pos+1)+" "+tlc[2]+" "+tlc[1]+"\n");
				} else {
					fw.write(matchLabel.substring(pos,pos+1)+" "+tlc[1]+" "+tlc[2]+"\n");
				}
				pos++;
				line = br.readLine();
			}
			
			fw.close();
			br.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private static void saveSVMSVRRESToJunHFormat(String svmResFilePath, String matchLabel, 
			String junHFormatSvFilePath){
		try{
			File f = new File(junHFormatSvFilePath);
			if (f.isFile()) {
				throw new Exception("this is not Cross Validation");
			} else {
				f.createNewFile();
			}
			
			BufferedReader br = new BufferedReader(new FileReader(svmResFilePath));
			String line = br.readLine();
			FileWriter fw = new FileWriter(f);
			int pos = 0;
			while (null != line) {
				fw.write(matchLabel.substring(pos,pos+1)+" "+line+"\n");
				pos++;
				line = br.readLine();
			}
			
			fw.close();
			br.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private static String _getLabel4Samples(double[][] junh_res){
		StringBuffer ans = new StringBuffer();

		int row = junh_res.length;
		for (int i = 0; i < row; i++){
			if (1.0 == junh_res[i][0]){
				ans.append("1");
			}else {
				ans.append("0");
			}
		}
		
		return ans.toString();
	}
	
	public static Vector<double[]> libsvm_predict(String true_label, String test_param, String test_sample_libsvm_format_file_path, 
			String libsvm_model_file_path, String save_predict_res_file_path){
		Vector<double[]> ans = new Vector<double[]>();
		try{
			System.out.print("    Begin run svm-test, Waiting...\n");
			
			String param = test_param.trim() +" "+test_sample_libsvm_format_file_path+" "+libsvm_model_file_path+
					" " + save_predict_res_file_path+".tmp";
			
			svm_predict sp = new svm_predict();
			System.out.println(param);
			sp.run(param.split(" "));
			
			ans = libsvmResToJunHFormat(save_predict_res_file_path+".tmp", true_label);
			
			DecimalFormat df = new DecimalFormat();
			df.applyPattern("#0.000000");
			FileWriter resFw = new FileWriter(save_predict_res_file_path);
			for (int i = 0; i < ans.size(); i++){
				double[] ith = ans.get(i);
				for (int j = 0; j < ith.length; j++){
					resFw.write(df.format(ith[j])+"\t");
				}
				resFw.write("\n");
			}
			resFw.close();

			//delete temp file
			File delF = new File(save_predict_res_file_path+".tmp");
			if (delF.isFile()){
				delF.delete();
			}
		}catch(Exception e){
			e.printStackTrace();
		}

		return ans;
	}

	public static String[] readSam(String libsvm_sam_path)throws Exception{
		StringBuffer sb = new StringBuffer();
		BufferedReader br = new BufferedReader(new FileReader(libsvm_sam_path));
		String line = br.readLine();
		while (null != line){
			if (line.startsWith("-1")){
				line = line.replaceFirst("-1", "2");
			}
			
			sb.append(line+"#");
			line = br.readLine();
		}
		br.close();

		return sb.toString().split("#");
	}

	public static Vector<double[]> libsvmResToJunHFormat(String svmResFilePath, String matchLabel){
		Vector<double[]> ans = new Vector<double[]>();

		try{
			BufferedReader br = new BufferedReader(new FileReader(svmResFilePath));
			String line = br.readLine();
			String[] lc = line.split(" +");
			
			// this is multi classifier problem, and the label sort is like {1,2,3,4,...,N-1,N}
			int pos = 0;
			line = br.readLine();
			while (null != line) {
				String[] tlc = line.split(" +");
				double[] tmp = new double[tlc.length];
				tmp[0] = Double.parseDouble(matchLabel.substring(pos, pos + 1));
				for (int i = 1; i < tlc.length; i++){
					tmp[Integer.parseInt(lc[i])] = Double.parseDouble(tlc[i]);
				}
				ans.add(tmp);
				
				pos++;
				line = br.readLine();
			}
			
			br.close();
		}catch(Exception e){
			e.printStackTrace();
		}

		return ans;
	}
	
}
