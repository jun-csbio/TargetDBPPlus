package DataProcessors;

import java.io.File;
import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;

public class NFoldSeqLabelDataCreater {
	private String seqSetFilePath = null;
	private String labelSetFilePath = null;
	private String NFolderParentPath = null;
	private int n_Fold = 5;
	
	private final String perFolderPrefix = "fold_";
	private final String perTrainSeqFastaFileName = "train_seq.fasta";
	private final String perTestSeqFastaFileName = "test_seq.fasta";
	private final String perTrainLabelFastaFileName = "train_label.fasta";
	private final String perTestLabelFastaFileName = "test_label.fasta";
	
	public NFoldSeqLabelDataCreater(String seqSetFilePath,
			String labelSetFilePath,
			String NFolderParentPath,
			int n_Fold) throws Exception{
		this.seqSetFilePath = seqSetFilePath;
		this.labelSetFilePath = labelSetFilePath;
		this.NFolderParentPath = NFolderParentPath;
		this.n_Fold = n_Fold;
		
		prepare();
	}
	
	public void prepare() throws Exception{
		// create num_Fold directories
		for (int i = 1; i <= n_Fold; i++) {
			File fold_Dir = new File(NFolderParentPath + System.getProperty("file.separator") + perFolderPrefix	+ i);
			if (!fold_Dir.exists()){
				fold_Dir.mkdirs();
			}
		}
		
		HashMap<String, String> seqHm = FileUtil.parseFASTAProteinSeqs(this.seqSetFilePath);
		HashMap<String, String> labelHm = FileUtil.parseFASTAProteinSeqs(this.labelSetFilePath);
		Object[] proteinIDArr = seqHm.keySet().toArray();
				
		int proteinTotalNum = proteinIDArr.length;
		int perTestProteinNum = (int) Math.ceil((double) (proteinTotalNum) / (double) (n_Fold));
		
		for (int n = 0; n < n_Fold; n++){
			String trainSeqFilePath = NFolderParentPath + System.getProperty("file.separator") + 
				perFolderPrefix + (n+1) + System.getProperty("file.separator") + perTrainSeqFastaFileName;
			String testSeqFilePath = NFolderParentPath + System.getProperty("file.separator") + 
				perFolderPrefix + (n+1) + System.getProperty("file.separator") + perTestSeqFastaFileName;
			String trainLabelFilePath = NFolderParentPath + System.getProperty("file.separator") + 
				perFolderPrefix + (n+1) + System.getProperty("file.separator") + perTrainLabelFastaFileName;
			String testLabelFilePath = NFolderParentPath + System.getProperty("file.separator") + 
				perFolderPrefix + (n+1) + System.getProperty("file.separator") + perTestLabelFastaFileName;
			
			for (int i = 0; i < proteinIDArr.length; i++){
				String lineToSeqFile =  ">"+proteinIDArr[i]+"\n"+seqHm.get(proteinIDArr[i]);
				if (null == labelHm.get(proteinIDArr[i])){
					throw new Exception("seq does not match label");
				}
				String lineToLabelFile =  ">"+proteinIDArr[i]+"\n"+labelHm.get(proteinIDArr[i]);
				
				if (n*perTestProteinNum <= i && i < (n+1)*perTestProteinNum){
					FileUtil.writeToFileLineByLine(lineToSeqFile, testSeqFilePath);
					FileUtil.writeToFileLineByLine(lineToLabelFile, testLabelFilePath);
				}else{
					FileUtil.writeToFileLineByLine(lineToSeqFile, trainSeqFilePath);
					FileUtil.writeToFileLineByLine(lineToLabelFile, trainLabelFilePath);
				}
			}
		}
	}
	
	public static void main(String[] args) throws Exception {
		new NFoldSeqLabelDataCreater("./3.5A-DNASeqInPDB20151010-CutOff30-Before20141010.fasta",
				"3.5A-DNALabInPDB20151010-CutOff30-Before20141010.fasta",
				"./2FoldCVTest",
				2);
		
//		new NFoldSeqLabelDataCreater("./metaDBsite_PDNA316_seq.fasta",
//				"./metaDBsite_PDNA316_lab.fasta",
//				"./MetaDBSite10FoldCV",
//				10);
		
		System.out.println("END");
	}

}
