package DataProcessors;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;

public class ExchangeDataFormat {

	public static void processTrain1500_500(String original_path, String save_fasta)throws Exception{
		HashMap<String, String> ans = new HashMap<String, String>();
		BufferedReader br = new BufferedReader(new FileReader(original_path));
		String line = br.readLine();
		while (null != line){
			String[] lc = line.split("	");
			String id = lc[0].toUpperCase();
			String label = lc[1];
			String seq = lc[2].toUpperCase().replaceAll("\n", "")
					.replaceAll("X", "").replaceAll("Z", "").replaceAll("U", "").replaceAll("/+", "");
			for (int j = 0; j < seq.length(); j++){
				if (!"ACDEFGHIKLMNPQRSTVWY".contains(""+seq.charAt(j))){
					System.out.println(id + " : " + j + "-th AA is " + seq.charAt(j));
					break;
				}
			}
			
			if ("crystallizable".equals(label)){
				ans.put(id+" 1", seq);
			}else if ("noncrystallizable".equals(label)){
				ans.put(id+" 0", seq);
			}else {
				System.out.println("Impossible!");
			}
			
			line = br.readLine();
			
		}
		br.close();
		
		System.out.println("the number of proteins is : " + ans.size());
		FileUtil.writeToFASTAFile(ans, save_fasta);
	}
	
	public static void processDataset(String crys_fasta, String non_crys_fasta, String save_fasta){
		HashMap<String, String> ans = new HashMap<String, String>();
		HashMap<String, String> crysHm = FileUtil.parseFASTAProteinSeqs(crys_fasta);
		HashMap<String, String> noncrysHm = FileUtil.parseFASTAProteinSeqs(non_crys_fasta);
		
		Object[] crysKeys = crysHm.keySet().toArray();
		for (int i = 0; i < crysKeys.length; i++){
			String key = (String)crysKeys[i];
			String seq = crysHm.get(crysKeys[i]).trim().toUpperCase().replaceAll("\n", "")
					.replaceAll("X", "").replaceAll("Z", "").replaceAll("U", "").replaceAll("/+", "");
			for (int j = 0; j < seq.length(); j++){
				if (!"ACDEFGHIKLMNPQRSTVWY".contains(""+seq.charAt(j))){
					System.out.println(key + " : " + j + "-th AA is " + seq.charAt(j));
					break;
				}
			}
			
			key = key.split("	| ")[0].replaceAll(":", "").replaceAll("-", "_");
			ans.put(key+" 1", seq);
		}
		
		Object[] noncrysKeys = noncrysHm.keySet().toArray();
		for (int i = 0; i < noncrysKeys.length; i++){
			String key = (String)noncrysKeys[i];
			String seq = noncrysHm.get(noncrysKeys[i]).trim().toUpperCase().replaceAll("\n", "")
					.replaceAll("X", "").replaceAll("Z", "").replaceAll("U", "").replaceAll("/+", "");
			for (int j = 0; j < seq.length(); j++){
				if (!"ACDEFGHIKLMNPQRSTVWY".contains(""+seq.charAt(j))){
					System.out.println(key + " : " + j + "-th AA is " + seq.charAt(j));
					break;
				}
			}
			
			key = key.split("	| ")[0].replaceAll(":", "").replaceAll("-", "_");
			ans.put(key+" 0", seq);
		}
		
		FileUtil.writeToFASTAFile(ans, save_fasta);
	}
	
	public static void main(String[] args) throws Exception{
		// dataset 1
		processDataset("/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset1/DIF728.fasta",
				"/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset1/WS728.fasta",
				"/home/junh/PaperFolder/FSProteinCrys/dataset/Dataset1/FEAT.junh.fasta");
		processDataset("/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset1/TPOS72.fasta",
				"/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset1/TNEG72.fasta",
				"/home/junh/PaperFolder/FSProteinCrys/dataset/Dataset1/TEST144_TEST.junh.fasta");
		processDataset("/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset1/TPOS43.fasta",
				"/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset1/TNEG43.fasta",
				"/home/junh/PaperFolder/FSProteinCrys/dataset/Dataset1/TEST_RL.junh.fasta");
		processDataset("/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset1/TEST_NEW_TPOS.fasta",
				"/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset1/TEST_NEW_TNEG.fasta",
				"/home/junh/PaperFolder/FSProteinCrys/dataset/Dataset1/TEST_NEW.junh.fasta");
		
		// dataset 1-1
		processTrain1500_500("/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset1/TRAINING1500.txt", 
				"/home/junh/PaperFolder/FSProteinCrys/dataset/Dataset1/TRAINING1500.fasta");
		processTrain1500_500("/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset1/TEST500.txt", 
				"/home/junh/PaperFolder/FSProteinCrys/dataset/Dataset1/TEST500.fasta");
		
		//dataset 2
		processDataset("/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset2/xtal_tr_TPOS.fasta",
				"/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset2/xtal_tr_TNEG.fasta",
				"/home/junh/PaperFolder/FSProteinCrys/dataset/Dataset2/CRYS-TRN.SCM.junh.fasta");
		processDataset("/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset2/xtal_tst_TPOS.fasta",
				"/home/junh/PaperFolder/FSProteinCrys/dataset/original/Dataset2/xtal_tst_TNEG.fasta",
				"/home/junh/PaperFolder/FSProteinCrys/dataset/Dataset2/CRYS-TEST.SCM.junh.fasta");
		
		System.out.println("END");
		
	}

}
