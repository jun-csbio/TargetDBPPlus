package DataProcessors;

import java.io.File;
import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;

public class WhoDoesNotSANNInfo {
	private static String fasta_path = "./3.5A-DNASeqInPDB20151010-CutOff30.fasta";
	private static String sann_folder = "F:/Academic/TargetDNANew/SANNNewDNAData";
	
	public static void main(String[] args) {
		HashMap<String, String> proteins = FileUtil.parseFASTAProteinSeqs(fasta_path);
		Object[] ids = proteins.keySet().toArray();
		for (int i = 0; i < ids.length; i++){
			String name = ids[i]+"";
			String file_path = sann_folder + "/" +name.substring(0, 4)+name.substring(5)+".a3";
			
			if (!new File(file_path).isFile()){
				System.out.println(">"+name+"\n"+proteins.get(ids[i]));
			}
		}
				
	}

}
