package _fea;

import java.util.Vector;

import _util.AminoAcid;
import _util._Math;
import _util._Matrix;
import _util._Vector;

public class SeqFea {
	/**
	 * @param seq : it has to upper case
	 * @return the protein level feature
	 */
	public static double[] AAC(String seq){
		double[] ans = new double[AminoAcid.AA_LIST.length()];
		int len = seq.length();
		
		for (int i = 0; i < len; i++){
			int ind = AminoAcid.AA_LIST.indexOf(seq.charAt(i));
			if (ind == -1) continue;
			ans[ind] += 1.0;
		}
		
		for (int i = 0; i < ans.length; i++)
			ans[i] /= len;
		
		return ans;
	}
	
	/**
	 * @param seq : it has to upper case
	 * @return the protein level feature
	 */
	public static double[] AAC(String seq, double[] info){
		double[] ans = new double[AminoAcid.AA_LIST.length()];
		int len = seq.length();
		
		for (int i = 0; i < len; i++){
			int ind = AminoAcid.AA_LIST.indexOf(seq.charAt(i));
			if (ind == -1) continue;
			ans[ind] += info[i];
		}
		
		for (int i = 0; i < ans.length; i++)
			ans[i] /= len;
		
		return ans;
	}
	
	
	public static double[] histOn0to1stepDot1(double[] arr){
		double[] ans = new double[10];
		
		double each_pie = 1.0 / arr.length;
		for (int i = 0; i < arr.length; i++){
			if (0.0 <= arr[i] && arr[i] < 0.1){
				arr[0] += each_pie;
			}
			if (0.1 <= arr[i] && arr[i] < 0.2){
				arr[1] += each_pie;
			}
			if (0.2 <= arr[i] && arr[i] < 0.3){
				arr[2] += each_pie;
			}
			if (0.3 <= arr[i] && arr[i] < 0.4){
				arr[3] += each_pie;
			}
			if (0.4 <= arr[i] && arr[i] < 0.5){
				arr[4] += each_pie;
			}
			if (0.5 <= arr[i] && arr[i] < 0.6){
				arr[5] += each_pie;
			}
			if (0.6 <= arr[i] && arr[i] < 0.7){
				arr[6] += each_pie;
			}
			if (0.7 <= arr[i] && arr[i] < 0.8){
				arr[7] += each_pie;
			}
			if (0.8 <= arr[i] && arr[i] < 0.9){
				arr[8] += each_pie;
			}
			if (0.9 <= arr[i] && arr[i] <=1.0){
				arr[9] += each_pie;
			}
		}
		
		return ans;
	}
	
	/**
	 * @param seq : it has to upper case
	 * @return the protein level feature
	 */
	public static double[] SAAC(String seq, int start_len, int end_len){
		int full_len = seq.length();
		
		String start_seq = seq.substring(0, start_len);
		String mid_seq = seq.substring(start_len, full_len - end_len);
		String end_seq = seq.substring(full_len - end_len, full_len);
		
		double[] start_aac = AAC(start_seq);
		double[] mid_aac = AAC(mid_seq);
		double[] end_aac = AAC(end_seq);
		
		return _Vector.vectorCat(start_aac, mid_aac, end_aac);
	}
	
	/**
	 * 1. average the pssm vectors of the same amino acid type
	 * 
	 * @param seq
	 * @param pssm
	 * @return AAPSSMC
	 */
	public static double[] AA_PSSM_Component(String seq, double[][] pssm){
		double[][] ans = new double[AminoAcid.AA_LIST.length()][20];
		int len = seq.length();
		
		for (int i = 0; i < len; i++){
			int ind = AminoAcid.AA_LIST.indexOf(seq.charAt(i));
			if (ind == -1) continue;
			
			for (int j = 0; j < 20; j++){
				ans[ind][j] += pssm[i][j];
			}
		}
		
		for (int i = 0; i < ans.length; i++){
			for (int j = 0; j < 20; j++){
				ans[i][j] /= len;
			}
		}
		
		return _Matrix.exchangeD2ArrToArr(ans);
	}
	
	/**
	 * @param seq : it has to upper case
	 * @return the residue level feature
	 */
	public static double[][] winPSSMFea4AA(double[][] pssm, int winsize){
		int row = pssm.length;
		int col = 20;
		
		double[][] ans = new double[row][];
		for (int i = 0; i < row; i++){
			double[][] winpssm = new double[winsize][col];
			for (int j = 0; j < winsize; j++){
				int dis = j-winsize/2;
				if ((i+dis)>=0 && (i+dis)<row){
					for (int k = 0; k < col; k++)
						winpssm[j][k] = pssm[i+dis][k];
				}else{
					for (int k = 0; k < col; k++)
						winpssm[j][k] = 0.0;
				}
			}
			
			ans[i] = _Matrix.exchangeD2ArrToArr(winpssm);
		}
		
		return ans;
	}
	
	public static double[][] winPSSFea4AA(double[][] pss, int winsize){
		int row = pss.length;
		int col = 3;
		
		double[][] ans = new double[row][];
		for (int i = 0; i < row; i++){
			double[][] winpss = new double[winsize][col];
			for (int j = 0; j < winsize; j++){
				int dis = j-winsize/2;
				if ((i+dis)>=0 && (i+dis)<row){
					for (int k = 0; k < col; k++)
						winpss[j][k] = pss[i+dis][k];
				}else{
					for (int k = 0; k < col; k++)
						winpss[j][k] = 0.0;
				}
			}
			
			ans[i] = _Matrix.exchangeD2ArrToArr(winpss);
		}
		
		return ans;
	}
	
	public static double[][] winSANNa3Fea4AA(double[][] sanna3, int winsize){
		int row = sanna3.length;
		int col = 3;
		
		double[][] ans = new double[row][];
		for (int i = 0; i < row; i++){
			double[][] winsanna3 = new double[winsize][col];
			for (int j = 0; j < winsize; j++){
				int dis = j-winsize/2;
				if ((i+dis)>=0 && (i+dis)<row){
					for (int k = 0; k < col; k++)
						winsanna3[j][k] = sanna3[i+dis][k];
				}else{
					for (int k = 0; k < col; k++)
						winsanna3[j][k] = 0.0;
				}
			}
			
			ans[i] = _Matrix.exchangeD2ArrToArr(winsanna3);
		}
		
		return ans;
	}
	
	public static double[][] winSSITE4ATPFea4AA(double[][] ssite4atp, int winsize){
		int row = ssite4atp.length;
		int col = ssite4atp[0].length;
		
		double[][] ans = new double[row][];
		for (int i = 0; i < row; i++){
			double[][] winsanna3 = new double[winsize][col];
			for (int j = 0; j < winsize; j++){
				int dis = j-winsize/2;
				if ((i+dis)>=0 && (i+dis)<row){
					for (int k = 0; k < col; k++)
						winsanna3[j][k] = ssite4atp[i+dis][k];
				}else{
					for (int k = 0; k < col; k++)
						winsanna3[j][k] = 0.0;
				}
			}
			
			ans[i] = _Matrix.exchangeD2ArrToArr(winsanna3);
		}
		
		return ans;
	}
	
	public static double[][] winTMSITE4ATPFea4AA(double[][] tmsite4atp, int winsize){
		int row = tmsite4atp.length;
		int col = tmsite4atp[0].length;
		
		double[][] ans = new double[row][];
		for (int i = 0; i < row; i++){
			double[][] winsanna3 = new double[winsize][col];
			for (int j = 0; j < winsize; j++){
				int dis = j-winsize/2;
				if ((i+dis)>=0 && (i+dis)<row){
					for (int k = 0; k < col; k++)
						winsanna3[j][k] = tmsite4atp[i+dis][k];
				}else{
					for (int k = 0; k < col; k++)
						winsanna3[j][k] = 0.0;
				}
			}
			
			ans[i] = _Matrix.exchangeD2ArrToArr(winsanna3);
		}
		
		return ans;
	}
	
	/**
	 * @param pssm : it should be normalized
	 * @return the protein level feature
	 * (20 + 20*G) -Dimensional PsePSSM feature
	 */
	public static double[] PsePSSM_Feature(double[][] pssm, int G) {
		int L = pssm.length;
		int col = pssm[0].length; // 20
		double[] AAC = _Matrix.mean_value_by_colum(pssm);
		Vector<double[]> AC_Vectors = new Vector<double[]>();
		// PSSM_AAC
		AC_Vectors.addElement(AAC);

		// Modified Pse_PSSM
		for (int g = 1; g <= G; g++) {
			double[] AC_g = new double[col];
			for (int j = 0; j < col; j++) {
				double temp = 0;
				for (int i = 0; i <= L - g - 1; i++) {
					temp += (pssm[i][j] - pssm[i + g][j])
							* (pssm[i][j] - pssm[i + g][j]); // Pse_PSSM
				}
				AC_g[j] = temp / (double) (L - g);
			}
			AC_Vectors.addElement(AC_g);
		}
		
		double[][] matrix = _Matrix.exchangeVDArrToD2Arr(AC_Vectors);
		double[] feature = _Matrix.toVector_by_Row(matrix);
		return feature;
	}
	
	public static double[] PsePSSM_Feature(String seq, double[][] pssm, int G) {
		int L = pssm.length;
		int col = pssm[0].length; // 20
		double[] AAC = _Matrix.mean_value_by_colum(pssm);
		
		Vector<Double> fea_vec = new Vector<Double>();
		for (int j = 0; j < AAC.length; j++) {
			fea_vec.add( AAC[j] );
		}
		
		
		double[][] pssm_T = _Matrix.transpose(pssm);
		for (int i = 0; i < pssm_T.length; i++) {
			double[] AAC_ithColumnu = AAC(seq, pssm_T[i]);
			for (int j = 0; j < AAC_ithColumnu.length; j++) {
				fea_vec.add( AAC_ithColumnu[j] );
			}
		}
		
		// Modified Pse_PSSM
		for (int g = 1; g <= G; g++) {
			for (int j = 0; j < col; j++) {
				double temp = 0;
				for (int i = 0; i <= L - g - 1; i++) {
					temp += (pssm[i][j] - pssm[i + g][j])
							* (pssm[i][j] - pssm[i + g][j]); // Pse_PSSM
				}
				fea_vec.add( temp / (double) (L - g) );
			}
		}
		
		return _Vector.toArray(fea_vec);
	}
	
	/**
	 * **************************************************************
	 * @param seq : with L amino acid
	 * @param profileMtx : with L rows and C columns
	 * @param G : the number of tier 
	 * @return
	 ***************************************************************
	 */
	public static double[] Pseudo_TypeI_Feature(String seq, double[][] profileMtx, int G) {
		int L = profileMtx.length;
		int col = profileMtx[0].length;
		
		double[] AAC = _Matrix.mean_value_by_colum(profileMtx);
		
		Vector<Double> fea_vec = new Vector<Double>();
		for (int j = 0; j < AAC.length; j++) {
			fea_vec.add( AAC[j] );
		}
		
		for (int g = 1; g <= G; g++) {
			for (int j = 0; j < col; j++) {
				double temp = 0;
				for (int i = 0; i <= L - g - 1; i++) {
					temp += (profileMtx[i][j] - profileMtx[i + g][j])
							* (profileMtx[i][j] - profileMtx[i + g][j]);
				}
				fea_vec.add( temp / (double) (L - g) );
			}
		}
		
		return _Vector.toArray(fea_vec);
	}
	
	/**
	 * **************************************************************
	 * @param seq : with L amino acid
	 * @param profileMtx : with L rows and C columns
	 * @param G : the number of tier 
	 * @return
	 ***************************************************************
	 */
	public static double[] Pseudo_TypeII_Feature(String seq, double[][] profileMtx, int G) {
		int L = profileMtx.length;
		int col = profileMtx[0].length;
		
		Vector<Double> fea_vec = new Vector<Double>();
		double[][] profileMtx_T = _Matrix.transpose(profileMtx);
		for (int i = 0; i < profileMtx_T.length; i++) {
			double[] AAC_ithColumnu = AAC(seq, profileMtx_T[i]);
			for (int j = 0; j < AAC_ithColumnu.length; j++) {
				fea_vec.add( AAC_ithColumnu[j] );
			}
		}
		
		for (int g = 1; g <= G; g++) {
			for (int j = 0; j < col; j++) {
				double temp = 0;
				for (int i = 0; i <= L - g - 1; i++) {
					temp += (profileMtx[i][j] - profileMtx[i + g][j])
							* (profileMtx[i][j] - profileMtx[i + g][j]);
				}
				fea_vec.add( temp / (double) (L - g) );
			}
		}
		
		return _Vector.toArray(fea_vec);
	}
	
	/**
	 * @param dbs : the probabilities of predicted DNA-binding sites 
	 * @return the protein level feature
	 * (20 + 20*G) -Dimensional PsePSSM feature
	 */
	public static double[] PseDBS_Feature(String seq, double[] dbs, int G) {
		int L = dbs.length;
		double[] AAC = AAC(seq, dbs);
		
		Vector<Double> ans = new Vector<Double>();
		for (int i = 0; i < AAC.length; i++) ans.add(AAC[i]);

		// Modified Pse_PSSM
		for (int g = 1; g <= G; g++) {
			double AC_g = 0.0;
			for (int i = 0; i <= L - g - 1; i++) {
				AC_g += (dbs[i]-dbs[i + g]) * (dbs[i]-dbs[i + g]);
			}
			AC_g = AC_g / (double) (L - g);
				
			ans.add(AC_g);
		}
		
		return _Vector.toArray(ans);
	}
	
	public static double[] PseDBS_Feature(double[] dbs, int G) {
		int L = dbs.length;
		double ave = _Math.average(dbs);
		
		Vector<Double> ans = new Vector<Double>();
		ans.add(ave);
		
		for (int g = 1; g <= G; g++) {
			double AC_g = 0.0;
			for (int i = 0; i <= L - g - 1; i++) {
				AC_g += (dbs[i]-dbs[i + g]) * (dbs[i]-dbs[i + g]);
			}
			AC_g = AC_g / (double) (L - g);
				
			ans.add(AC_g);
		}
		
		return _Vector.toArray(ans);
	}
	
	// (3 + 3*G) -Dimensional PsePSS feature
	public static double[] PsePSS_Feature(double[][] pss, int G) {
		int L = pss.length;
		int col = pss[0].length; // 3
		double[] AAC = _Matrix.mean_value_by_colum(pss);
		Vector<double[]> AC_Vectors = new Vector<double[]>();
		// pss_AAC
		AC_Vectors.addElement(AAC);
			// Modified Pse_pss
		for (int g = 1; g <= G; g++) {
			double[] AC_g = new double[col];
			for (int j = 0; j < col; j++) {
				double temp = 0;
				for (int i = 0; i <= L - g - 1; i++) {
					temp += (pss[i][j] - pss[i + g][j])
							* (pss[i][j] - pss[i + g][j]); // Pse_pss
				}
				AC_g[j] = temp / (double) (L - g);
			}
			AC_Vectors.addElement(AC_g);
		}
		
		double[][] matrix = _Matrix.exchangeVDArrToD2Arr(AC_Vectors);
		double[] feature = _Matrix.toVector_by_Row(matrix);
		return feature;
	}
	
	// (3 + 3*G) -Dimensional PsePSS feature
	public static double[] PsePSS_Feature(String seq, double[][] pss, int G) {
		int L = pss.length;
		int col = pss[0].length; // 3
		
		double[][] pss_T = _Matrix.transpose(pss);
		double[] AAC_1stColumnu = AAC(seq, pss_T[0]);
		double[] AAC_2ndColumnu = AAC(seq, pss_T[1]);
		double[] AAC_3rdColumnu = AAC(seq, pss_T[2]);
		
		Vector<Double> fea_vec = new Vector<Double>();
		for (int i = 0; i < AAC_1stColumnu.length; i++) {
			fea_vec.add(AAC_1stColumnu[i]);
		}
		for (int i = 0; i < AAC_2ndColumnu.length; i++) {
			fea_vec.add(AAC_2ndColumnu[i]);
		}
		for (int i = 0; i < AAC_3rdColumnu.length; i++) {
			fea_vec.add(AAC_3rdColumnu[i]);
		}
		
		// Modified Pse_pss
		for (int g = 1; g <= G; g++) {
			for (int j = 0; j < col; j++) {
				double temp = 0;
				for (int i = 0; i <= L - g - 1; i++) {
					temp += (pss[i][j] - pss[i + g][j]) * (pss[i][j] - pss[i + g][j]); // Pse_pss
				}
				fea_vec.add( temp / (double) (L - g) );
			}
		}

		return _Vector.toArray(fea_vec);
	}
}
