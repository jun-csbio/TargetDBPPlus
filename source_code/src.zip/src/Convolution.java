

public class Convolution {

	public static double[] convArr(double[] arr, double[] conv) {
		int len = arr.length;
		int X = conv.length;
		
		double[] conv_arr = new double[len-(X-1)];
		
		for (int i = 0; i < conv_arr.length; i++) {
			double val = 0.0;
			for (int x = 0; x < X; x++) {
				val += conv[x] * arr[i+x];
			}
			
			conv_arr[i] = val;
		}
		
		return conv_arr;
		
	}
	
	/**
	 * **************************************************************
	 * @param mtx
	 * @param conv
	 * @return the row number of the return matrix is same as that of the input mtx
	 ***************************************************************
	 */
	public static double[][] convMtxRow(double[][] mtx, double[] conv){
		int row   = mtx.length;
		int col   = mtx[0].length;
		int X     = conv.length;
		
		double[][] conv_mtx = new double[row][col-(X-1)];
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < conv_mtx.length; j++) {
				double val = 0.0;
				for (int x = 0; x < X; x++) {
					val += conv[x] * mtx[i][j+x];
				}
				
				conv_mtx[i][j] = val;
			}
		}
		
		return conv_mtx;
	}
	
	/**
	 * **************************************************************
	 * @param mtx
	 * @param conv
	 * @return the column number of the return matrix is same as that of the input mtx
	 ***************************************************************
	 */
	public static double[][] convMtxColumn(double[][] mtx, double[] conv){
		int row   = mtx.length;
		int col   = mtx[0].length;
		int X     = conv.length;
		
		double[][] conv_mtx = new double[row-(X-1)][col];
		for (int j = 0; j < col; j++) {
			for (int i = 0; i < conv_mtx.length; i++) {
				double val = 0.0;
				for (int x = 0; x < X; x++) {
					val += conv[x] * mtx[i+x][j];
				}
				
				conv_mtx[i][j] = val;
			}
		}
		
		return conv_mtx;
	}
	
	/**
	 * **************************************************************
	 * @param mtx
	 * @param conv
	 * @return the column number of the return matrix is same as that of the input mtx
	 ***************************************************************
	 */
	public static double[][] convMtx(double[][] mtx, double[][] conv){
		int row   = mtx.length;
		int col   = mtx[0].length;
		int Xrow  = conv.length;
		int Xcol  = conv[0].length;
		
		double[][] conv_mtx = new double[row-(Xrow-1)][col-(Xcol-1)];
		for (int i = 0; i < conv_mtx.length; i++) {
			for (int j = 0; j < conv_mtx[0].length; j++) {
				double val = 0.0;
				for (int xrow = 0; xrow < Xrow; xrow++) {
					for (int xcol = 0; xcol < Xcol; xcol++) {
						val += conv[xrow][xcol] * mtx[i+xrow][j+xcol];
					}
				}
				
				conv_mtx[i][j] = val;
			}
		}
		
		return conv_mtx;
	}
}
