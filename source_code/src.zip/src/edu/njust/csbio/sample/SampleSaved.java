package edu.njust.csbio.sample;

import java.io.FileWriter;
import java.text.DecimalFormat;

import edu.njust.csbio.tools.JunHMatrix;
import edu.njust.csbio.tools.JunH_File_Process;

public class SampleSaved {
	// the last dimension is label
	public static void saveUseMatrxFormatBySpace(double[][] partten_label, String filePath){
		try{
			JunH_File_Process.writeToFile(partten_label, filePath);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	// the last dimension is label
	public static void saveFileByRFSampleFormat(double[][] partten_label, String filePath){
		try{
			DecimalFormat df = new DecimalFormat();
			df.applyPattern("#0.0000");
			
			FileWriter fw = new FileWriter(filePath);
			int size = partten_label.length;
			for (int i = 0; i < size; i++){
				double[] tmp = partten_label[i]; //������Ŀ+�����Ŀ
				for (int j = 0; j < tmp.length-1; j++){
					fw.write(df.format(tmp[j]) + "\t");
				}
				fw.write((int)(tmp[tmp.length-1]) + "\n");
			}
			fw.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void saveUseMatrxFormatBySpace(double[][] partten, double[] label, String filePath){
		try{
			DecimalFormat df = new DecimalFormat();
			df.applyPattern("#0.000000");
			
			FileWriter fw = new FileWriter(filePath);
			int size = partten.length;
			for (int i = 0; i < size; i++){
				double[] tmp = partten[i];
				for (int j = 0; j < tmp.length; j++){
					fw.write(df.format(tmp[j]) + " ");
				}
				fw.write((int)label[i] + "\n");
			}
			fw.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	// the last dimension is label
	public static void saveUseWekaFormat(double[][] partten_label, String filePath){
		try{
			DecimalFormat df = new DecimalFormat();
			df.applyPattern("#0.0000");
			
			FileWriter fw = new FileWriter(filePath);
			fw.write("@RELATION " + filePath+"\n\n");
			for (int i = 0; i < partten_label[0].length-1; i++){
				fw.write("@ATTRIBUTE dim"+(i+1)+" REAL\n");
			}
			fw.write("@ATTRIBUTE class	{binding,non-binding}");
			fw.write("\n\n@DATA\n");
			int size = partten_label.length;
			for (int i = 0; i < size; i++){
				double[] tmp = partten_label[i];
				for (int j = 0; j < tmp.length-1; j++){
					fw.write(df.format(tmp[j]) + ",");
				}
				if (1 == partten_label[i][partten_label[i].length - 1]){
					fw.write("binding\n");
				}else{
					fw.write("non-binding\n");
				}
			}
			fw.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void saveUseWekaFormat(double[][] partten, double[] label, String filePath){
		try{
			DecimalFormat df = new DecimalFormat();
			df.applyPattern("#0.0000");
			
			FileWriter fw = new FileWriter(filePath);
			fw.write("@RELATION " + filePath+"\n\n");
			for (int i = 0; i < partten[0].length; i++){
				fw.write("@ATTRIBUTE dim"+(i+1)+" REAL\n");
			}
			fw.write("@ATTRIBUTE class	{binding,non-binding}");
			fw.write("\n\n@DATA\n");
			int size = partten.length;
			for (int i = 0; i < size; i++){
				double[] tmp = partten[i];
				for (int j = 0; j < tmp.length; j++){
					fw.write(df.format(tmp[j]) + ",");
				}
				if (1 == label[i]){
					fw.write("binding\n");
				}else{
					fw.write("non-binding\n");
				}
			}
			fw.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	// the last dimension is label
	public static void saveUseLIBSVMFormatBySpace(double[][] partten_label, String filePath){
		try{
			JunH_File_Process.writeToFileWithLIBSVMFormat(partten_label, filePath);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void saveUseLIBSVMFormatBySpace(double[][] partten, double[] label, String filePath){
		try{
			JunH_File_Process.writeToFileWithLIBSVMFormat(JunHMatrix.exchangeD2ArrToVDArr(partten), label, filePath);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void saveUseWEKAARFFFormat(double[][] partten, double[] label, String filePath)throws Exception{
		int sample_num = partten.length;
		int feature_size = partten[0].length;
		FileWriter fw = new FileWriter(filePath);
		fw.write("@relation pssm\n");
		for (int i = 0; i < feature_size; i++){
			fw.write("@attribute feature"+i+"	real\n");
		}
		fw.write("@attribute class real\n@data\n");
		
		for (int i = 0; i < sample_num; i++){
			for (int j = 0; j < feature_size; j++){
				fw.write(""+ partten[i][j] + ",");
			}
			fw.write(label[i]+"\n");
		}
		
		fw.close();
	}
}
