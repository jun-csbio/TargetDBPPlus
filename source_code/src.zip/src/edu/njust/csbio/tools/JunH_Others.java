package edu.njust.csbio.tools;

import java.util.HashMap;

public class JunH_Others {
	
	/**
	 * value = (value - u) / sd
	 * */
	public static HashMap<String, Double> normalizedHashMapByGaussFunc(HashMap<String, Double> hm){
		Object[] ids = hm.keySet().toArray();
		double u = 0.0;
		for (int i = 0; i < ids.length; i++){
			u += hm.get(ids[i]);
		}
		u /= ids.length;
			
		double sd = 0.0;
		for (int i = 0; i < ids.length; i++){
			sd += (hm.get(ids[i]) - u) 
					*(hm.get(ids[i]) - u);
		}
		sd = Math.sqrt(sd/ids.length);
		
		HashMap<String, Double> ans = new HashMap<String, Double>();
		for (int i = 0; i < ids.length; i++){
			ans.put((String)ids[i], (hm.get(ids[i]) - u) / sd);
		}
		
		return ans;
	}
	
}
