package edu.njust.csbio.tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Set;
import java.util.Vector;


public class FileFunc {

	//��contents�����е����ݴ洢��fileName�ļ���ȥ�� ÿһ��Ԫ��ռһ��
	public static void writeToFile(String[] contents, String fileName){
		File f = new File(fileName);
		if (!f.isFile()){
//			System.out.println("FileFunc_writeToFile:Sorry " + fileName + "is not exist, we recreate it!");
			try {
				f.createNewFile();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		try {
			FileWriter w = new FileWriter(f);
			for (int i=0; i<contents.length; i++){
				w.write(contents[i]+ "\n");
			}
			w.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// ��һ��HashMap�е�����д���ļ���
	public static void writeToFile(HashMap<String, String> contents, String fileName){
		File f = new File(fileName);
		if (!f.isFile()){
			System.out.println("FileFunc_writeToFile:Sorry " + fileName + "is not exist, we recreate it!");
			try {
				f.createNewFile();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		try {
			FileWriter w = new FileWriter(f);
			Set<String> s = contents.keySet();
			Object[] oArr = s.toArray();
			for (int i=0; i<oArr.length; i++){
				w.write(oArr[i]+ "\n");
				w.write(contents.get(oArr[i]) + "\n");
			}
			w.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// ��һ��double[][]������ֱ�����ļ���
	public static void writeToFile(double[][] dArr, char label, String fileName){
		File f = new File(fileName);
		if (!f.isFile()){
			System.out.println(fileName + " is not exist! we create it!");
			try {
				f.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		DecimalFormat df = new DecimalFormat();
		df.applyPattern("#0.000000");
	
		try {
			FileWriter fw = new FileWriter(f, true);
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < dArr.length; i++){
				for (int j = 0; j < dArr[i].length; j++){
					sb.append(df.format(dArr[i][j]) + " ");
				}
			}
			fw.write(sb.toString().trim() + " ");
			fw.write(label);
			fw.write("\n");
			fw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @function : ��arr�����е�������������saveFilePath��ȥ
	 * */
	public static void writeToFile(double[][] arr, String saveFilePath){
		File f = new File(saveFilePath);
		if (!f.isFile()) {
			System.out.println(saveFilePath + " is not exist! we create it!");
			try {
				f.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		DecimalFormat df = new DecimalFormat();
		df.applyPattern("#0.000000");

		try {
			FileWriter fw = new FileWriter(f); 
			for (int i = 0; i < arr.length; i++){
				
				if (arr[i][arr[i].length-1] == 0.0){
					System.out.println(saveFilePath + "EEEEEEEEEEEEEE");
					System.exit(-1);
				}
				
				StringBuffer sb = new StringBuffer();
				for (int j = 0; j < arr[i].length; j++) {
					sb.append(df.format(arr[i][j]) + " ");
				}
				fw.write(sb.toString().trim());
				fw.write("\n");
			}
			fw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @param arr : ���һ������꣬ǰ��������
	 * @function : ��arr�����е�������������LIBSVM����Ҫ�ĸ�ʽsaveFilePath�ļ���ȥ
	 * */
	public static void writeToLIBSVMFile(double[][] arr, String saveFilePath){
		File f = new File(saveFilePath);
		if (!f.isFile()) {
			System.out.println(saveFilePath + " is not exist! we create it!");
			try {
				f.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		DecimalFormat df = new DecimalFormat();
		df.applyPattern("#0.00000");

		try {
			FileWriter fw = new FileWriter(f); 
			for (int i = 0; i < arr.length; i++){
				StringBuffer sb = new StringBuffer();
				if (arr[i][arr[i].length-1] == 2.0)
					sb.append("-1 ");
				else if (arr[i][arr[i].length-1] == 1.0)
					sb.append("+1 ");
				for (int j = 0; j < arr[i].length-1; j++) {
					sb.append(Integer.toString(j+1)+":"+df.format(arr[i][j]) + " ");
				}
				fw.write(sb.toString().trim());
				fw.write("\n");
			}
			fw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// ��һ��double[]��������ļ���
	public static void writeToFile(double[] dArr, char label, String fileName) {
		File f = new File(fileName);
		if (!f.isFile()) {
			System.out.println(fileName + " is not exist! we create it!");
			try {
				f.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		DecimalFormat df = new DecimalFormat();
		df.applyPattern("#0.000000");

		try {
			FileWriter fw = new FileWriter(f, true); // ......
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < dArr.length; i++) {
				sb.append(df.format(dArr[i]) + " ");
			}
			fw.write(sb.toString().trim() + " ");
			fw.write(label);
			fw.write("\n");
			fw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ��һ��double[][]������ֱ�����ļ���
	public static void normalizedWriteToFile(double[][] dArr, char label, String fileName){
		File f = new File(fileName);
		if (!f.isFile()){
			System.out.println(fileName + " is not exist! we create it!");
			try {
				f.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		try {
			double sum = 0.0;
			for (int i = 0; i < dArr.length; i++){
				for (int j = 0; j < dArr[i].length; j++){
					sum += dArr[i][j];
				}
			}
			
			FileWriter fw = new FileWriter(f, true);
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < dArr.length; i++){
				for (int j = 0; j < dArr[i].length; j++){
					sb.append(Double.toString(dArr[i][j] / sum) + " ");
				}
			}
			fw.write(sb.toString().trim() + " ");
			fw.write(label);
			fw.write("\n");
			fw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// ֻ���������pdb_CA�ļ�
	public static Vector<String[]> specialLoadFile(String fPath){
		Vector<String[]> ansV = new Vector<String[]>();
		
		File f = new File(fPath);
		if (!f.isFile()){
			System.out.println("FileFunc specialLoadFile error" + fPath + " is not exist!");
			try {
				f.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.exit(-1);
		}
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			String line = br.readLine();
			while (null != line){
				String[] lineContents = StrFunc.getWordsInStr(line, ' ');
				StringBuffer strBuf = new StringBuffer();
				// ����pdb��pdb_CA��ʽ��
				strBuf.append(lineContents[6] + "#");
				strBuf.append(lineContents[7] + "#");
				strBuf.append(lineContents[8] + "#");
				strBuf.append(lineContents[3] + "#");  //����һ���л�����
				ansV.add(strBuf.toString().trim().split("#"));
				line = br.readLine();
			}
			br.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ansV;
	}
	
	// ֻ���������Protein_pdb�ļ�  ���ص�String[]�У� ÿһ��String����һ������
	public static Vector<String[]> specialLoadAllAtomFile(String fPath) {
		Vector<String[]> ansV = new Vector<String[]>();

		File f = new File(fPath);
		if (!f.isFile()) {
			System.out.println("FileFunc specialLoadFile error" + fPath
					+ " is not exist!");
			System.exit(-1);
		}

		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			String line = br.readLine();
			StringBuffer strBuf = new StringBuffer();
			int nowPos = 1;
			while (null != line) {
				String[] lineContents = StrFunc.getWordsInStr(line, ' ');

				if (8 <= lineContents.length) {
					if (nowPos + 1 == Integer.parseInt(lineContents[5])) {
						ansV.add(strBuf.toString().trim().split("#"));
						// �����µĲл�
						strBuf.delete(0, strBuf.length());
						strBuf.append(lineContents[6] + " ");
						strBuf.append(lineContents[7] + " ");
						strBuf.append(lineContents[8] + " ");
						strBuf.append(lineContents[3] + "#"); // ����һ���л�����
						nowPos++;
					} else if (nowPos == Integer.parseInt(lineContents[5])) {
						// ����pdb��ʽ��
						strBuf.append(lineContents[6] + " ");
						strBuf.append(lineContents[7] + " ");
						strBuf.append(lineContents[8] + " ");
						strBuf.append(lineContents[3] + "#"); // ����һ���л�����
					} else {
						System.out.println("specialLoadAllAtomFile Error!!!s");
						System.exit(-1);
					}
				}

				line = br.readLine();
			}
			ansV.add(strBuf.toString().trim().split("#"));
			br.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ansV;
	}
	
	//����ʵ���˰�fPath�е�ÿһ��ֵ�� ͨ��split�ָ��HashMap�е�һ����¼
	public static HashMap<String, String> myLoadFile(String fPath, char split){
		HashMap<String, String> ansHM = new HashMap<String, String>();
		
		File f = new File(fPath);
		if (!f.isFile()){
			System.out.println("FileFunc specialLoadFile error" + fPath + " is not exist!");
			System.exit(-1);
		}
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			String line = br.readLine();
			while (null != line){
				String[] lineContents = StrFunc.getWordsInStr(line, split);
				if (2 != lineContents.length){
					System.out.println("Have A Problem!");
					System.exit(-1);
				}
				
				Set<String> s = ansHM.keySet();
				Object[] oArr = s.toArray();
				boolean tag = false;
				for (int i = 0; i < oArr.length; i++){
					if (lineContents[0].equalsIgnoreCase((String)oArr[i])){
						tag = true;
						break;
					}
				}
				if (!tag){
					ansHM.put(lineContents[0], lineContents[1]);
				}
				
				line = br.readLine();
			}
			br.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ansHM;
	}
	
	//��Key��û��ȥ�� >
	public static HashMap<String, String> readFASTAFileWithJT(String seqFilePath){
		HashMap<String, String> hm = new HashMap<String, String>();
		
		try {
			BufferedReader bf = new BufferedReader(new FileReader(seqFilePath));
			String lineProteinName = bf.readLine();
			String lineProteinSeq = bf.readLine();
			while (null != lineProteinName && null != lineProteinSeq){
				hm.put(lineProteinName.toUpperCase(), lineProteinSeq);
				
				lineProteinName = bf.readLine();
				lineProteinSeq = bf.readLine();
			}
			
			bf.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return hm;
	}
	
	//��Key��ȥ�� 
	public static HashMap<String, String> readFASTAFile(String seqFilePath){
		HashMap<String, String> hm = new HashMap<String, String>();
		
		try {
			BufferedReader bf = new BufferedReader(new FileReader(seqFilePath));
			String lineProteinName = bf.readLine();
			String lineProteinSeq = bf.readLine();
			while (null != lineProteinName && null != lineProteinSeq){
				hm.put(lineProteinName.toUpperCase().substring(1), lineProteinSeq);
				
				lineProteinName = bf.readLine();
				lineProteinSeq = bf.readLine();
			}
			
			bf.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return hm;
	}
	
	public static String[] readFileByLine(String filePath)throws Exception{
		File f = new File(filePath);
		if (!f.isFile()){
			throw new Exception(filePath + " is not exist!");
		}
		
		Vector<String> tans = new Vector<String>();
		
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line = br.readLine();
		while (null != line){
			tans.add(line);
			line = br.readLine();
		}
		br.close();
		
		int ansLen = tans.size();
		String[] ans = new String[ansLen];
		for (int i = 0; i < ansLen; i++){
			ans[i] = tans.get(i);
		}
		return ans;
	}
	
	//��ȡֻ���е����ʲл�CAԭ�ӵ�PDB�ļ���double[][]������
	public static double[][] readProteinCAXYZByPDBFile(String proteinPDBFile) throws Exception{
			File f = new File(proteinPDBFile);
			if (!f.isFile()){
				System.out.println(proteinPDBFile + " is not exist!");
//				System.exit(-1);
				return null;
			}
				
			Vector<double[]> vdA = new Vector<double[]>();
			BufferedReader br = new BufferedReader(new FileReader(f)); 
			String line = br.readLine();
			while (null != line){
				//String[] lc = StrFunc.getWordsInStr(line, ' ');
				
				double[] tdA = new double[3];
//				tdA[0] = Double.parseDouble(lc[6]);
//				tdA[1] = Double.parseDouble(lc[7]);
//				tdA[2] = Double.parseDouble(lc[8]);
				tdA[0] = Double.parseDouble(line.substring(30, 38));
				tdA[1] = Double.parseDouble(line.substring(38, 46));
				tdA[2] = Double.parseDouble(line.substring(46, 54));
//				System.out.println(tdA[0]+ " " + tdA[1] + " " + tdA[2]);
				vdA.add(tdA);
				line = br.readLine();
			}
			br.close();
			
			int size = vdA.size();
			double[][] ans = new double[size][3];
			for (int i = 0; i < size; i++){
				ans[i] = vdA.get(i);
			}
				
			return ans;
		}
	
	public static void main(String[] args){
//		specialLoadFile("E:/HEME_Bingding/HemBinding_Data_30/30/ReceptorCA/1aoqA.pdb_CA");
//		System.out.println("END");
//		HashMap<String, String> hm = myLoadFile("E:\\HEME_Bingding\\HemBinding_Data_30\\30\\30.fasta", ' ');
//		writeToFile(hm, "E:\\HEME_Bingding\\HemBinding_Data_30\\30\\30_1.fasta");
		System.out.println("END");
	}
}
