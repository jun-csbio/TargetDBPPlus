package edu.njust.csbio.tools;

import java.io.FileWriter;
import java.util.HashMap;
import java.util.Vector;

public class JunHVector {
	
	public static void main(String[] args) {
		double[] a = {1, 2};
		double[] b = {1.5, 3.5};
		double[][] ans = vector_a_mul_bT(a, b);
		for (int i = 0; i < a.length; i++){
			for (int j = 0; j < b.length; j++){
				System.out.print(ans[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	public static double[] bias_vector(double[] a, double[] b){
		int feature_num = a.length;
		double[] ans = new double[feature_num];
		for (int i = 0; i < a.length; i++){
			ans[i] = a[i] - b[i];
		}
		
		return ans;
	}
	
	// a, b 琛ㄧず鍒楀悜閲�
	public static double[][] vector_a_mul_bT(double[] a, double[] b){
		int row = a.length;
		int col = b.length;
		double[][] ans = new double[row][col];
		for (int i = 0; i < row; i++){
			for (int j = 0; j < col; j++){
				ans[i][j] = a[i]*b[j]; 
			}
		}
		
		return ans;
	}
	
	// a, b 琛ㄧず鍒楀悜閲�
	public static double[] vector_a_mul_constB(double[] a, double B){
		int row = a.length;
		double[] ans = new double[row];
		for (int i = 0; i < row; i++){
			ans[i] = a[i] * B; 
		}
		
		return ans;
	}
	
	public static void saveByCols(double[] v, String savePath)throws Exception{
		FileWriter fwFileWriter = new FileWriter(savePath);
		for (int i= 0; i < v.length; i++){
			fwFileWriter.write(v[i] + "\n");
		}
		fwFileWriter.close();
	}
	
	public static Vector<double[]> mean(Vector<double[]> a, Vector<double[]> b){
		Vector<double[]> ansVector = new Vector<double[]>();
		for (int i = 0; i < a.size(); i++){
			double[] tmpA = a.get(i);
			double[] tmpB = b.get(i);
			double[] tmp = new double[tmpA.length];
			for (int j = 0; j < tmpA.length; j++){
				tmp[j] = (tmpA[j] + tmpB[j])/2;
			}
			ansVector.add(tmp);
		}
		return ansVector;
	}
	
	public static Vector<double[]> simple_move(Vector<double[]> vd, double[] move_direct){
		Vector<double[]> ansVector = new Vector<double[]>();
		for (int i = 0; i < vd.size(); i++){
			double[] tmp = vd.get(i);
			for (int j = 0; j < tmp.length; j++){
				tmp[j] -= move_direct[j];
			}
			ansVector.add(tmp);
		}
		return ansVector;
	}
	
	public static boolean isContant(int[] arr, int a){
		for (int i = 0; i < arr.length; i++){
			if (a==arr[i]){
				return true;
			}
		}
		return false;
	}
	
	public static double biggest(double[] arr) {
		double ans = Double.MAX_VALUE;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] > ans) {
				ans = arr[i];
			}
		}
		return ans;
	}

	public static int biggestPos(double[] arr) {
		int ans = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] > arr[ans]) {
				ans = i;
			}
		}
		return ans;
	}

	public static double[] normalizeToOne(double[] a) {
		double max = Double.MIN_VALUE;
		double min = Double.MAX_VALUE;
		for (int i = 0; i < a.length; i++) {
			if (a[i] > max) {
				max = a[i];
			}
			if (a[i] < min) {
				min = a[i];
			}
		}

		if (min == max) {
			for (int i = 0; i < a.length; i++) {
				a[i] = 1.0 / a.length;
			}
		} else {
			for (int i = 0; i < a.length; i++) {
				a[i] = (a[i] - min) / (max - min);
			}
		}
		return a;
	}

	public static HashMap<String, Double> normalizeToOne(HashMap<String, Double> AAIndex_map) {
		double max = Double.MIN_VALUE;
		double min = Double.MAX_VALUE;
		Object[] AAarr = AAIndex_map.keySet().toArray();
		for (int i = 0; i < AAarr.length; i++) {
			double value = AAIndex_map.get(AAarr[i]) ;
			if (value > max) {
				max = value;
			}
			if (value < min) {
				min = value;
			}
		}

		if (min == max) {
			for (int i = 0; i < AAarr.length; i++) {
				AAIndex_map.put((String)AAarr[i], 1.0 / AAarr.length);
			}
		} else {
			for (int i = 0; i < AAarr.length; i++) {
				double value = AAIndex_map.get(AAarr[i]) ;
				AAIndex_map.put((String)AAarr[i], (value - min) / (max - min));
			}
		}
		return AAIndex_map;
	}
	
	public static HashMap<String, Double> gauss_normalize(HashMap<String, Double> AAIndex_map) {
		Object[] AAarr = AAIndex_map.keySet().toArray();
		double[] tmp_var = new double[AAarr.length];
		for (int i = 0; i < AAarr.length; i++) {
			double value = AAIndex_map.get(AAarr[i]) ;
			tmp_var[i] = value;
		}
		double mean = JunHMath.average(tmp_var);
		double sqrt_var = JunHMath.standart_deviation(tmp_var);
		for (int i = 0; i < AAarr.length; i++) {
			AAIndex_map.put((String)AAarr[i], (tmp_var[i] - mean) / sqrt_var);
		}
		return AAIndex_map;
	}
	
	public static double[] gauss_normalize(double[] arr) {
		double mean = JunHMath.average(arr);
		double sqrt_var = JunHMath.standart_deviation(arr);
		
		double[] ans = new double[arr.length];
		for (int i = 0; i < arr.length; i++) {
			ans[i] = (arr[i] - mean) / sqrt_var;
		}
		return ans;
	}
	
	public static double[] normalizeToSumEqualOne(double[] a) {
		double sum = 0.0;
		for (int i = 0; i < a.length; i++) {
			sum += a[i];
		}

		if (0.0 == sum) {
			for (int i = 0; i < a.length; i++) {
				a[i] = 1.0 / a.length;
			}
		} else {
			for (int i = 0; i < a.length; i++) {
				a[i] = a[i] / sum;
			}
		}
		return a;
	}
	
	public static double[] select(double[] original, int[] selectPos,
			boolean isSelectePosStartZero) {
		double[] ans = new double[selectPos.length];
		for (int i = 0; i < selectPos.length; i++) {
			if (isSelectePosStartZero) {
				ans[i] = original[selectPos[i]];
			} else {
				ans[i] = original[selectPos[i] - 1];
			}
		}
		return ans;
	}
	
	public static double[] select(double[] original, Vector<Integer> selectPos,
			boolean isSelectePosStartZero) {
		double[] ans = new double[selectPos.size()];
		for (int i = 0; i < selectPos.size(); i++) {
			if (isSelectePosStartZero) {
				ans[i] = original[selectPos.get(i)];
			} else {
				ans[i] = original[selectPos.get(i) - 1];
			}
		}
		return ans;
	}

	public static double[] vectorCat(double[]... ds) {
		int ansLen = 0;
		int paramLen = ds.length;
		for (int i = 0; i < paramLen; i++) {
			ansLen += ds[i].length;
		}

		double[] ans = new double[ansLen];
		int pos = 0;
		for (int i = 0; i < paramLen; i++) {
			for (int j = 0; j < ds[i].length; j++) {
				ans[pos] = ds[i][j];
				pos++;
			}
		}
		return ans;
	}

	public static double[] vectorCat(double[] a, double[] b) {
		double[] ans = new double[a.length + b.length];
		for (int i = 0; i < a.length; i++) {
			ans[i] = a[i];
		}
		for (int j = 0; j < b.length; j++) {
			ans[a.length + j] = b[j];
		}
		return ans;
	}

	public static double[] vectorCat(double[] a, double b) {
		double[] ans = new double[a.length + 1];
		for (int i = 0; i < a.length; i++) {
			ans[i] = a[i];
		}
		ans[a.length] = b;
		
		return ans;
	}
	
	/** 闂備浇娉曢崰鎰板几婵犳艾绠柣鎴ｅГ閺呮悂鏌￠崒妯猴拷閻庢氨鎳撻埢搴ゎ樉缂佹唻绻濋弻銊╂偄閸涘﹦浼勯梺褰掝棢閸忔﹢寮幘璇叉闁靛牆妫楅锟�*/
	public static double distance(double[] a, double[] b) {
		double sum = 0;
		for (int i = 0; i < a.length; i++)
			sum += (a[i] - b[i]) * (a[i] - b[i]);

		return Math.sqrt(sum);
	}

	public static double junh_bigger_equal_MeanValue(double[] value, double threshold){
		double ans = 0;
		for (int i = 0; i < value.length; i++){
			if (value[i] >= threshold)
				ans += value[i];
		}
		
		return ans / value.length;
	}
	
	public static double junh_bigger_equal_NumPercent(double[] value, double threshold){
		int ans = 0;
		for (int i = 0; i < value.length; i++){
			if (value[i] >= threshold)
				ans ++;
		}
		
		return 1.0 * ans / value.length;
	}
	
	public static double junh_smaller_MeanValue(double[] value, double threshold){
		double ans = 0;
		for (int i = 0; i < value.length; i++){
			if (value[i] < threshold)
				ans += value[i];
		}
		
		return ans / value.length;
	}
	
	public static double[] toArray(Vector<Double> vd){
		int size = vd.size();
		double[] ans = new double[size];
		for (int i = 0; i < size; i++){
			ans[i] = vd.get(i);
		}
		
		return ans;
	}

}
