package edu.njust.csbio.tools;

import java.util.HashMap;
import java.util.Vector;

public class JunHMath {
	
	public static double average(double[] vd){
		double EX = 0.0;
		
		int size = vd.length;
		for (int i = 0; i < size; i++){
			EX += vd[i];
		}
		EX /= size;
		return EX;
	}
	
	public static double average(double[] vd, int start, int endPlusOne){
		double EX = 0.0;
		
		for (int i = start; i < endPlusOne; i++){
			EX += vd[i];
		}
		EX /= endPlusOne-start;
		return EX;
	}
	
	public static double variance_calculate_Type_I(Vector<Double> vd){
		double DX = 0.0;   //D(X) = E((X - EX)^2)
		double EX = 0.0;
		
		int size = vd.size();
		for (int i = 0; i < size; i++){
			EX += vd.get(i);
		}
		EX /= size;
		
		for (int i = 0; i < size; i++){
			DX = (vd.get(i) - EX)*(vd.get(i) - EX);
		}
		DX /= size;
		
		return DX;
	}
		
	public static double variance_calculate_Type_II(Vector<Double> vd){
		double DX = 0.0;   //D(X) = E(X^2) - (EX)^2
		double EX = 0.0;
		double EX_2 = 0.0;
		
		int size = vd.size();
		for (int i = 0; i < size; i++){
			EX += vd.get(i);
			EX_2 += ((vd.get(i))*(vd.get(i)));
		}
		EX /= size;
		EX_2 /= size;
		DX = EX_2 - EX*EX;
		
		return DX;
	}
	
	public static double variance_calculate_Type_II(double[] vd){
		double DX = 0.0;   //D(X) = E(X^2) - (EX)^2
		double EX = 0.0;
		double EX_2 = 0.0;
		
		int size = vd.length;
		for (int i = 0; i < size; i++){
			EX += vd[i];
			EX_2 += vd[i]*vd[i];
		}
		EX /= size;
		EX_2 /= size;
		DX = EX_2 - EX*EX;
		
		return DX;
	}
	
	public static double standart_deviation(Vector<Double> vd){
		return Math.sqrt(variance_calculate_Type_II(vd));
	}
	
	//閿熷姭绛夐潻鎷烽敓缁炵鎷烽敓鏂ゆ嫹閿熸枻鎷锋嫝閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷峰噯閿熸枻鎷�
	public static double standart_deviation(double[] vd){
		return Math.sqrt(variance_calculate_Type_II(vd));
	}
	
	public static void main(String[] args) throws Exception{	
		HashMap<String, HashMap<String, Double>> ansHashMap = parseAAIndex1File.getValues("D:/Protein閿熺粨鏅�AAIndex_Dataset/AAindex1.txt");
		Object[] list = ansHashMap.keySet().toArray();
		int ok = 0;
		for (int i = 0; i < list.length; i++){
			Vector<Double> vdDoubles = new Vector<Double>();
			
//			if ("HARY940101".equals(list[i])){
//				System.out.println("END");
//			}
			
			HashMap<String, Double> tmpHashMap = ansHashMap.get(list[i]);
			Object[] tmpList = tmpHashMap.keySet().toArray();
			for (int j = 0; j < tmpList.length; j++){
				vdDoubles.add(tmpHashMap.get(tmpList[j]));
			}
			double var = variance_calculate_Type_I(vdDoubles);
			if (var > 1){
				ok++;
			}
			System.out.println(list[i] + "'s variance is " + var);
		}
		System.out.println(ok);
	}

}
