package edu.njust.csbio.tools;

public class AcidAbrevWord {
		//	������Ҫ�ǱȽ�abrev��word���ǲ��Ǳ�ʾͬһ��������
		public static boolean compare(String abrev, char word){
			switch(word){
			case 'G':
			case 'g':
				if (abrev.endsWith("GLY")){
					return true;
				}
				break;
			case 'A':
			case 'a':
				if (abrev.endsWith("ALA")){
					return true;
				}
				break;
			case 'V':
			case 'v':
				if (abrev.endsWith("VAL")){
					return true;
				}
				break;
			case 'L':
			case 'l':
				if (abrev.endsWith("LEU")){
					return true;
				}
				break;
			case 'I':
			case 'i':
				if (abrev.endsWith("ILE")){
					return true;
				}
				break;
			case 'P':
			case 'p':
				if (abrev.endsWith("PRO")){
					return true;
				}
				break;
			case 'F':
			case 'f':
				if (abrev.endsWith("PHE")){
					return true;
				}
				break;
			case 'Y':
			case 'y':
				if (abrev.endsWith("TYR")){
					return true;
				}
				break;
			case 'W':
			case 'w':
				if (abrev.endsWith("TRP")){
					return true;
				}
				break;
			case 'S':
			case 's':
				if (abrev.endsWith("SER")){
					return true;
				}
				break;
			case 'T':
			case 't':
				if (abrev.endsWith("THR")){
					return true;
				}
				break;
			case 'C':
			case 'c':
				if (abrev.endsWith("CYS")){
					return true;
				}
				break;
			case 'M':
			case 'm':
				if (abrev.endsWith("MET")){
					return true;
				}
				break;
			case 'N':
			case 'n':
				if (abrev.endsWith("ASN")){
					return true;
				}
				break;
			case 'Q':
			case 'q':
				if (abrev.endsWith("GLN")){
					return true;
				}
				break;
			case 'D':
			case 'd':
				if (abrev.endsWith("ASP")){
					return true;
				}
				break;
			case 'E':
			case 'e':
				if (abrev.endsWith("GLU")){
					return true;
				}
				break;
			case 'K':
			case 'k':
				if (abrev.endsWith("LYS")){
					return true;
				}
				break;
			case 'R':
			case 'r':
				if (abrev.endsWith("ARG")){
					return true;
				}
				break;
			case 'H':
			case 'h':
				if (abrev.endsWith("HIS")){
					return true;
				}
				break;
			}
			return false;
		}
		
		//	���ݰ��������д�õ��Լ��ŵ����к���
		public static int getAcidPX(String acid){
			if (acid.length() > 3){
				acid = acid.substring(1);
			}
//			System.out.println(acid);
			
			if (acid.equals("G") || acid.equals("g") || acid.equals("GLY"))
				return 1;
			if (acid.equals("A") || acid.equals("a") || acid.equals("ALA"))
				return 2;
			if (acid.equals("V") || acid.equals("v") || acid.equals("VAL"))
				return 3;
			if (acid.equals("L") || acid.equals("l") || acid.equals("LEU"))
				return 4;
			if (acid.equals("I") || acid.equals("i") || acid.equals("ILE"))
				return 5;
			if (acid.equals("P") || acid.equals("p") || acid.equals("PRO"))
				return 6;
			if (acid.equals("F") || acid.equals("f") || acid.equals("PHE"))
				return 7;
			if (acid.equals("Y") || acid.equals("y") || acid.equals("TYR"))
				return 8;
			if (acid.equals("W") || acid.equals("w") || acid.equals("TRP"))
				return 9;
			if (acid.equals("S") || acid.equals("s") || acid.equals("SER"))
				return 10;
			if (acid.equals("T") || acid.equals("t") || acid.equals("THR"))
				return 11;
			if (acid.equals("C") || acid.equals("c") || acid.equals("CYS"))
				return 12;
			if (acid.equals("M") || acid.equals("m") || acid.equals("MET"))
				return 13;
			if (acid.equals("N") || acid.equals("n") || acid.equals("ASN"))
				return 14;
			if (acid.equals("Q") || acid.equals("q") || acid.equals("GLN"))
				return 15;
			if (acid.equals("D") || acid.equals("d") || acid.equals("ASP"))
				return 16;
			if (acid.equals("E") || acid.equals("e") || acid.equals("GLU"))
				return 17;
			if (acid.equals("K") || acid.equals("k") || acid.equals("LYS"))
				return 18;
			if (acid.equals("R") || acid.equals("r") || acid.equals("ARG"))
				return 19;
			if (acid.equals("H") || acid.equals("h") || acid.equals("HIS"))
				return 0;
			
			System.out.println("getAcidPX Error!");
			return -1;
		}

		//	�����Լ��ŵ����к���õ����������д
		public static char acrossPXgetAcidAbrev(int px){
			switch(px){
			case 1:
				return 'G';
			case 2:
				return 'A';
			case 3:
				return 'V';
			case 4:
				return 'L';
			case 5:
				return 'I';
			case 6:
				return 'P';
			case 7:
				return 'F';
			case 8:
				return 'Y';
			case 9:
				return 'W';
			case 10:
				return 'S';
			case 11:
				return 'T';
			case 12:
				return 'C';
			case 13:
				return 'M';
			case 14:
				return 'N';
			case 15:
				return 'Q';
			case 16:
				return 'D';
			case 17:
				return 'E';
			case 18:
				return 'K';
			case 19:
				return 'R';
			case 0:
				return 'H';
			}
			
			return '?';
		}
		
		public static char acrossThreeWordToGetOneWord(String acid){
			if (acid.length() > 3){
				acid = acid.substring(1);
			}
//			System.out.println(acid);
			
			if (acid.equals("GLY"))
				return 'G';
			if (acid.equals("ALA"))
				return 'A';
			if (acid.equals("VAL"))
				return 'V';
			if (acid.equals("LEU"))
				return 'L';
			if (acid.equals("ILE"))
				return 'I';
			if (acid.equals("PRO"))
				return 'P';
			if (acid.equals("PHE"))
				return 'F';
			if (acid.equals("TYR"))
				return 'Y';
			if (acid.equals("TRP"))
				return 'W';
			if (acid.equals("SER"))
				return 'S';
			if (acid.equals("THR"))
				return 'T';
			if (acid.equals("CYS"))
				return 'C';
			if (acid.equals("MET"))
				return 'M';
			if (acid.equals("ASN"))
				return 'N';
			if (acid.equals("GLN"))
				return 'Q';
			if (acid.equals("ASP"))
				return 'D';
			if (acid.equals("GLU"))
				return 'E';
			if (acid.equals("LYS"))
				return 'K';
			if (acid.equals("ARG"))
				return 'R';
			if (acid.equals("HIS"))
				return 'H';
//			System.out.println("getAcidPX Error!");
			return 'X';
		}
		
}
