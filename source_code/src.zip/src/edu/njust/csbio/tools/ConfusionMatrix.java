package edu.njust.csbio.tools;

public class ConfusionMatrix {
	private int tp;
	private int fn;
	private int fp;
	private int tn;

	public ConfusionMatrix(int tp, int fn, int fp, int tn) {
		this.tp = tp;
		this.fn = fn;
		this.fp = fp;
		this.tn = tn;
	}

	public ConfusionMatrix add(ConfusionMatrix a, ConfusionMatrix b) {
		ConfusionMatrix ans = new ConfusionMatrix(0, 0, 0, 0);
		ans.tp = a.tp + b.tp;
		ans.fn = a.fn + b.fn;
		ans.fp = a.fp + b.fp;
		ans.tn = a.tn + b.tn;
		return ans;
	}

	public void tp_plus(int a) {
		tp += a;
	}

	public void fn_plus(int a) {
		fn += a;
	}

	public void fp_plus(int a) {
		fp += a;
	}

	public void tn_plus(int a) {
		tn += a;
	}

	public int getTp() {
		return tp;
	}

	public int getFn() {
		return fn;
	}

	public int getFp() {
		return fp;
	}

	public int getTn() {
		return tn;
	}

	public double getMCC(){
		return (tp*tn - fp*fn)/Math.sqrt(1.0*(tp+fp)*(tp+fn)*(tn+fp)*(tn+fn));
	}
	
	public double getTPR(){
		return (1.0*tp/(tp+fn));
	}
	
	public double getFPR(){
		return (1.0*fp/(fp+tn));
	}
	
	public String toString() {
		return "["
				+ tp + " " + fn
				+ "; "
				+ fp + " " + tn
				+ "]\nsen="
				+ (1.0*tp / (tp + fn) + "\nspe=" + (1.0*tn / (fp + tn)) + "\nacc="
						+ (1.0*(tp + tn) / (tp + tn + fp + fn)) + ""
						+ "\npre="+(tp*1.0/(tp+fp))
						+ "\nmcc="
						+ ((tp*tn - fp*fn)/Math.sqrt(1.0*(tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))));
	}
	
	public static void main(String[] args){
		ConfusionMatrix cm = new ConfusionMatrix(875, 0, 201, 21200);
		System.out.println(cm.getMCC());
	}
}
