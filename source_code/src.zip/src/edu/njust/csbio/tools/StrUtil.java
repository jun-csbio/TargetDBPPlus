package edu.njust.csbio.tools;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Set;
public class StrUtil {
	static DecimalFormat df = new DecimalFormat();
	static{
		df.applyPattern("#0.000");
	}
	public static void print(String [] a){
		for(int i=0;i<a.length;i++){
			System.out.print(" " +a[i]);
		}
		System.out.println();
	}
	
	public static void print(double [] a){
		for(int i=0;i<a.length;i++){
			System.out.print(" " +df.format(a[i]));
		}
		System.out.println();
	}
	public static void print(double [][] a){
		for(int i=0;i<a.length;i++){
			System.out.print("["+i+"]");
			for(int j=0;j<a[i].length;j++){
				System.out.print(" " +df.format(a[i][j]));
			}
			System.out.println();
		}
	}
	
	public static String array2Str(double [][]a){
		StringBuffer buf = new StringBuffer();
		for(int i=0;i<a.length;i++){
			buf.append("["+(i+1)+"]");
			for(int j=0;j<a[i].length;j++){
				buf.append(StrUtil.formatStrToFixLen(df.format(a[i][j]),
						10));
			}
			buf.append("\n");;
		}
		return buf.toString();
	}
	public static String array2Str(double []a){
		StringBuffer buf = new StringBuffer();
		for(int i=0;i<a.length;i++){
			//buf.append("["+(i+1)+"]");
			buf.append(StrUtil.formatStrToFixLen(df.format(a[i]),
						10));
			//buf.append("\n");;
		}
		return buf.toString();
	}
	public static String array2StrSeperateByComma(double []a){
		StringBuffer buf = new StringBuffer();
		for(int i=0;i<a.length;i++){
			//buf.append("["+(i+1)+"]");
			if(Math.abs(a[i] - 0) < 0.0000001)
				buf.append("0");
			else if(Math.abs(a[i] - 1) < 0.0000001)
				buf.append("1");
			else
				buf.append(StrUtil.formatStrToFixLen(df.format(a[i]),
						10));
			if(i != a.length -1)
				buf.append(",");
			
			//buf.append("\n");;
		}
		return buf.toString();
	}
	
	public static void print(int [] a){
		for(int i=0;i<a.length;i++)
			System.out.print(" " +a[i]);
	}
	
	public static void print(HashMap <String, Object> hashMap){
		System.out.println( hashmap2Str(hashMap));
	}
	public static String  hashmap2Str(HashMap <String, Object>hashMap){
		StringBuffer buf = new StringBuffer();
		Set <String> keys = hashMap.keySet();
		Object [] keysArray = keys.toArray();
		for ( int i = 0; i < keysArray.length; i ++){
			buf.append(keysArray[i]+"\n");
			buf.append(hashMap.get(keysArray[i])+"\n");
		}
		return buf.toString();
	}
	public static String formatStrToFixLen(String s, int len){
		StringBuffer buf = null;
		if(s==null){
			buf = new StringBuffer();
			for(int i=0;i<len;i++)
				buf.append(" ");
		}else{
			buf = new StringBuffer(s);
			while(buf.length()<len){
				buf.insert(0," ");
			}
			
		}
		return buf.toString();
	}
	
	public static String junHFormatStrToFixLen(String s, int len){
		StringBuffer buf = null;
		if(s==null){
			buf = new StringBuffer();
			for(int i=0;i<len;i++)
				buf.append("1");
		}else{
			buf = new StringBuffer(s);
			while(buf.length()<len){
				buf.insert(0,"1");
			}
		}
		return buf.toString();
	}
	
	public static String[] getWordsInStr(String str, char split){
		str = str.trim();
		
		boolean preIsSplit = false;
		int strLength = str.length();
		StringBuffer ans = new StringBuffer();
		for (int i = 0; i < strLength; i++){
			if (split == str.charAt(i)){
				if (!preIsSplit){
					ans.append("#");
				}
				preIsSplit = true;
			}else{
				ans.append(str.charAt(i));
				preIsSplit = false;
			}
		}
		
		return ans.toString().split("#");
	}
	
	public static String[] getWordsInStrEnhance(String str, char split){
		int l = str.length();
		//�õ�ǰ���һ������split���ַ�λ��
		int startPos = 0;
		for (int i = 0; i < l; i++){
			if (split != str.charAt(i)){
				startPos = i;
				break;
			}
		}
		//�õ�������һ������split���ַ�λ��
		int endPos = l;
		for (int i = 0; i < l; i++){
			if (split != str.charAt(l-1-i)){
				endPos = l-1-i;
				break;
			}
		}
		str = str.substring(startPos, endPos + 1);
		for (int i = 0; i < l; i++){
			if (split != str.charAt(i)){
				startPos = i;
				break;
			}
		}
		
		boolean preIsSplit = false;
		int strLength = str.length();
		StringBuffer ans = new StringBuffer();
		for (int i = 0; i < strLength; i++){
			if (split == str.charAt(i)){
				if (!preIsSplit){
					ans.append("#");
				}
				preIsSplit = true;
			}else{
				ans.append(str.charAt(i));
				preIsSplit = false;
			}
		}
		
		return ans.toString().split("#");
	}
	
	public static String parseHtmlLineUsefulInfo(String htmlLine, String usefulSet){
		StringBuffer tmpAns = new StringBuffer();
		int lineLen = htmlLine.length();
		boolean canRemoveOrNot = false;
		for (int i = 0; i < lineLen; i++){
			String tmp = htmlLine.substring(i, i+1);
			if ("<".equals(tmp)){
				canRemoveOrNot = true;
			}else if (">".equals(tmp)){
				canRemoveOrNot = false;
			}else{
				if (!canRemoveOrNot){
					if (usefulSet.contains(tmp)){
						tmpAns.append(tmp);
					}
				}
			}
		}
		return tmpAns.toString();
	}
	
	public static String removeOneCharTypeInStr(String str, char type){
		int len = str.length();
		StringBuffer ans = new StringBuffer();
		for (int i = 0; i < len; i++){
			if (type != str.charAt(i)){
				ans.append(str.charAt(i));
			}
		}
		return ans.toString();
	}
}
