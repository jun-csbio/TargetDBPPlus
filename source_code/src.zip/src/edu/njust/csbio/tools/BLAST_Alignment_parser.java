package edu.njust.csbio.tools;

import java.io.BufferedReader;
import java.io.FileReader;

public class BLAST_Alignment_parser {

	/**
	 * �����Ǹ���Blast�������ȡ��������һ��ƥ������,
	 * return eg: ��һ����Query���бȶԵĲ��֣��ڶ����Ǳȶ����бȶԲ���
	 * [[1FR8B]
	 * [Query: 103 SNYMGNPWTEYMAKYDIEEVHGSGIRVDLGEDAEVAGTQYRLPSGKCPVFGKGIIIENSN 162##Query: 163 TTFLTPVATGNQYLKDGGFAFPPTEPLMSPMTLDEMRHFYKDNKYVKNLDELTLCSRHAG 222],
	 * [Sbjct: 1   GNYMGNPWTEYMAKYDIEEVHGSGIRVDLGEDAEVAGTQYRLPSGKCPVFGKGIIIENSN 60##Sbjct: 61  TTFLTPVATGNQYLKDGGFAFPPTEPLMSPMTLDEMRHFYKDNKYVKNLDELTLCSRHAG 120] 
	 * */
	public static String[] read1stProtein(String alnFilePath) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(alnFilePath));
		String line = br.readLine();
		String pdb_id = "JUNH";
		StringBuffer queryBuffer = new StringBuffer();
		StringBuffer alnBuffer = new StringBuffer();
		boolean first = true;
		while (null != line){
			if (line.startsWith("Query: ")){
				queryBuffer.append(line+"##");
			}else if (line.startsWith("Sbjct: ")){
				alnBuffer.append(line+"##");
			}else if (line.startsWith(">")){
				if (!first){
					break;
				}
				pdb_id = line.substring(1,6);
				first = false;
			}
			line = br.readLine();
		}
		br.close();
		
		String[] ans = new String[3];
		ans[0] = pdb_id;
		ans[1] = queryBuffer.toString();
		ans[2] = alnBuffer.toString();
		return ans;
	}
	
	/**
	 * �����Ǹ���Blast���������Query���к������������н����±��ת����������Query�е��±��Ӧ��aln�е��±��Ƕ���
	 * @param alnInfo: ��ʽ����
	 * [[1FR8B]
	 * [[Query: 103 SNYMGNPWTEYMAKYDIEEVHGSGIRVDLGEDAEVAGTQYRLPSGKCPVFGKGIIIENSN 162##Query: 163 TTFLTPVATGNQYLKDGGFAFPPTEPLMSPMTLDEMRHFYKDNKYVKNLDELTLCSRHAG 222],
	 * [Sbjct: 1   GNYMGNPWTEYMAKYDIEEVHGSGIRVDLGEDAEVAGTQYRLPSGKCPVFGKGIIIENSN 60##Sbjct: 61  TTFLTPVATGNQYLKDGGFAFPPTEPLMSPMTLDEMRHFYKDNKYVKNLDELTLCSRHAG 120] 
	 * @param indexOfQuery: ע���1��ʼ������
	 * */
	public static int indexMatch(int indexOfQuery, String[] alnInfo)throws Exception{
		String[] queryParts = alnInfo[1].split("##");
		String[] alnParts = alnInfo[2].split("##");
		if (queryParts.length != alnParts.length){
			throw new Exception("����������Alignment��");
		}
		int ans = -1;
		for (int i = 0; i < queryParts.length; i++){
			String[] query_items = queryParts[i].split(" +");
			String[] aln_items = alnParts[i].split(" +");
			int queryStartIndex = Integer.parseInt(query_items[1]);
			int queryEndIndex = Integer.parseInt(query_items[3]);
			int alnStartIndex = Integer.parseInt(aln_items[1]);
//			int alnEndIndex = Integer.parseInt(aln_items[3]);
			ans = alnStartIndex;
			if (indexOfQuery >= queryStartIndex && indexOfQuery <= queryEndIndex){
				String querySeq = query_items[2];
				String alnSeq = aln_items[2];
				int AABias = indexOfQuery - queryStartIndex;
				for (int j = 0, pos = 0; j < AABias; pos++){
					if ('-' != querySeq.charAt(pos)){
						j++;
					}
					
					if ('-' != alnSeq.charAt(pos)){
						ans++;
					}
				}
				
				if ('C' != alnSeq.charAt(ans - alnStartIndex)){
					throw new Exception("Is not Cys AA.");
				}
				break;
			}
		}
		
		
		return ans;
	}
	
	/*public static void main(String[] args) throws Exception{
		String[] info = read1stProtein("D:/Academic[From20131208]/Disulfide/program/BLAST_programme/data/AMA1_PLAFF.aln");
		int ans = indexMatch(149, info);
		System.out.println(ans);
		
		Vector<Vector<double[]>> pdb_3D = PDBFileParser.readPDB3DCoordinateOfOneChain("J:/PDB-3D/2Q8A.pdb", 'A'); 
	}*/

}
