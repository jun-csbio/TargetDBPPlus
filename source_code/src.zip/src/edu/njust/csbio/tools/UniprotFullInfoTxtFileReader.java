package edu.njust.csbio.tools;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;

/**������Ҫ��Ϊ�˽�����һ��UniprotKB���ݿ����ļ�����ϸ��Ϣ
 * ע��һ���ļ��к��в�ֹһ�������ʵ���Ϣ����ͬ�ĵ�������Ϣ����'//'������
 * ID�������ʵı�ţ�Ψһ��
 * AC�������ʵ�Uniprot ID����Ψһ��
 * FT�������ʵľ���ṹ������������
 * SQ�����������У���һ�е�//��֮���ǵ��������У�*/
public class UniprotFullInfoTxtFileReader {
	
	/**
	 * �������к��ж������DISULFID���ĵ���������<ID, Sequence>
	 * eg: <11SB_CUCMA, MARSSLFTFL......SPGRSQGRRE>
	 * */
	public static HashMap<String, String> readDISULFIDSeq(String txt_path)throws Exception{
		HashMap<String, String> ans = new HashMap<String, String>();
		BufferedReader br = new BufferedReader(new FileReader(txt_path));
		String line = br.readLine();
		StringBuffer id = new StringBuffer();
		StringBuffer seq = new StringBuffer();
		boolean isDisulfid = false;
		while (null != line){
			if (line.startsWith("ID")){
				String[] strs = line.split(" +");
				id.append(strs[1]);		//first uniprot id
			}else if (line.startsWith("FT   DISULFID")) {
//				line = line.substring(14, 27);
//				String[] cysIndexs = line.trim().split(" +");
//				id.append("_"+cysIndexs[0] + "_" + cysIndexs[1]);
				
				isDisulfid = true;
			}else if (line.startsWith("SQ")){
			}else if (line.startsWith("  ")){
				seq.append(line.replace(" ", ""));
			}else if (line.startsWith("//")){
				if (isDisulfid){
					ans.put(id.toString(), seq.toString());
					
					System.out.println(id.toString() + " is processed!!!");
				}
				
				id.delete(0, id.length());
				seq.delete(0, seq.length());
				isDisulfid = false;
			}
			
			line = br.readLine();
		}
		br.close();
		
		return ans;
	}
	
	/**
	 * �������к��ж������DISULFID���ĵ��������γɶ������CYSλ��<ID, indexes>
	 * eg: <11SB_CUCMA, DISULFID(s)_48_81_124_303>
	 * ((48-81), (124-303))*/
	public static HashMap<String, String> readDISULFIDIndex(String txt_path)throws Exception{
		HashMap<String, String> ans = new HashMap<String, String>();
		BufferedReader br = new BufferedReader(new FileReader(txt_path));
		String line = br.readLine();
		StringBuffer id = new StringBuffer();
		StringBuffer index = new StringBuffer();
		boolean isDisulfid = false;
		while (null != line){
			if (line.startsWith("ID")){
				String[] strs = line.split(" +");
				id.append(strs[1]);		//first uniprot id
			}else if (line.startsWith("FT   DISULFID")) {
				line = line.substring(14, 27);
				String[] cysIndexs = line.trim().split(" +");
				index.append("_"+cysIndexs[0] + "_" + cysIndexs[1]);
				
				isDisulfid = true;
			}else if (line.startsWith("SQ")){
			}else if (line.startsWith("  ")){
			}else if (line.startsWith("//")){
				if (isDisulfid){
					ans.put(id.toString(), "DISULFID(s)"+index.toString());
					
					System.out.println(id.toString() + " is processed!!!");
				}
				
				id.delete(0, id.length());
				index.delete(0, index.length());
				isDisulfid = false;
			}
			
			line = br.readLine();
		}
		br.close();
		
		return ans;
	}
	
	/**
	 * �������к��ж������DISULFID���ĵ����ʶ�Ӧ��PDB_ID<ID, PDB_ID>
	 * eg: <11SB_CUCMA, . 2E9Q; X-ray; 2.20 A; A=22-480. 2EVX; X-ray; 2.60 A; A=22-480.>
	 * ((48-81), (124-303))*/
	public static HashMap<String, String> readDISULFIDProteinPDBInfo(String txt_path)throws Exception{
		HashMap<String, String> ans = new HashMap<String, String>();
		BufferedReader br = new BufferedReader(new FileReader(txt_path));
		String line = br.readLine();
		StringBuffer id = new StringBuffer();
		StringBuffer pdbInfo = new StringBuffer();
		pdbInfo.append("PDB.");
		boolean isDisulfid = false;
		while (null != line){
			if (line.startsWith("ID")){
				String[] strs = line.split(" +");
				id.append(strs[1]);		//first uniprot id
			}else if (line.startsWith("DR   PDB;")) {
				pdbInfo.append(line.substring(9));
			}else if (line.startsWith("FT   DISULFID")) {
				isDisulfid = true;
			}else if (line.startsWith("SQ")){
			}else if (line.startsWith("  ")){
			}else if (line.startsWith("//")){
				if (isDisulfid){
					ans.put(id.toString(), "PDB." + pdbInfo.toString());
					
					System.out.println(id.toString() + " is processed!!!");
				}
				
				id.delete(0, id.length());
				pdbInfo.delete(0, pdbInfo.length());
				isDisulfid = false;
			}
			
			line = br.readLine();
		}
		br.close();
		
		return ans;
	}
	
	public static void main(String[] args) throws Exception{
		HashMap<String, String> ansSeq = readDISULFIDSeq("D:/Academic[From20131208]/Disulfide/database/uniprot-(database_(type_pdb))+AND+reviewed_yes.txt/uniprot-(database_(type_pdb))+AND+reviewed_yes.txt");
		HashMap<String, String> ansIndex = readDISULFIDIndex("D:/Academic[From20131208]/Disulfide/database/uniprot-(database_(type_pdb))+AND+reviewed_yes.txt/uniprot-(database_(type_pdb))+AND+reviewed_yes.txt");
		HashMap<String, String> ansPDBInfo = readDISULFIDProteinPDBInfo("D:/Academic[From20131208]/Disulfide/database/uniprot-(database_(type_pdb))+AND+reviewed_yes.txt/uniprot-(database_(type_pdb))+AND+reviewed_yes.txt");
		FileUtil.writeToFASTAFile(ansSeq, "J:/del.fasta");
		FileUtil.writeToFASTAFile(ansIndex, "J:/del111.fasta");
		FileUtil.writeToFASTAFile(ansPDBInfo, "J:/del222.fasta");
		
		System.out.println("END");
//		String lineString = " A 12   35  ";
//		System.out.println(lineString.replace(" ", ""));
	}

}
