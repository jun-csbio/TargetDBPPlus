package edu.njust.csbio.tools;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;


public class parseAAIndex1File {

	/**
	 * @return : (key = ANDN920101, value = (key = A, value = 4.2; key = L, value = 4.3))
	 * */
	public static HashMap<String, HashMap<String, Double>> getValues(String AAIndex1FilePath) throws Exception{
		HashMap<String, HashMap<String, Double>> ans = new HashMap<String, HashMap<String, Double>>();
		BufferedReader brBufferedReader = new BufferedReader(new FileReader(AAIndex1FilePath));
		String line = brBufferedReader.readLine();
		int num = 0;
		
		String featureName = "";
		HashMap<String, Double> tmpHM = null;
		
		while (null != line){
			if (line.startsWith("H ")){
				featureName = line.substring(2);
				num++;
			}else if (line.startsWith("I ")){
				String valueOne = brBufferedReader.readLine();
				String[] valueOneLC = valueOne.trim().split(" +");
				String valueTwo = brBufferedReader.readLine();
				String[] valueTwoLC = valueTwo.trim().split(" +");
				String[] lc = line.substring(2).trim().split(" +");
				tmpHM = new HashMap<String, Double>();
				for (int i = 0; i < lc.length; i++){
					String[] lcc = lc[i].split("/");
					if (lcc.length != 2){
						brBufferedReader.close();
						throw new Exception("data format is not AAIndex1 Format!");
					}
					if (!"NA".equals(valueOneLC[i])) tmpHM.put(lcc[0], Double.parseDouble(valueOneLC[i]));
					if (!"NA".equals(valueTwoLC[i])) tmpHM.put(lcc[1], Double.parseDouble(valueTwoLC[i]));
					
				}
			}else if (line.startsWith("//")){
				ans.put(featureName, tmpHM);
				tmpHM = null;
			}
			line = brBufferedReader.readLine();
		}
		brBufferedReader.close();
		System.out.println(num);
		return ans;
	} 
	
	public static HashMap<String, String> getDescrible(String AAIndex1FilePath) throws Exception{
		HashMap<String, String> ans = new HashMap<String, String>();
		BufferedReader brBufferedReader = new BufferedReader(new FileReader(AAIndex1FilePath));
		String line = brBufferedReader.readLine();
		String featureName = "";
		String describle = "";
		while (null != line){
			if (line.startsWith("H ")){
				featureName = line.substring(2);
			}else if (line.startsWith("D ")){
				describle = line.substring(2);
			}else if (line.startsWith("//")){
				ans.put(featureName, describle);
			}
			line = brBufferedReader.readLine();
		}
		brBufferedReader.close();
		return ans;
	} 
	
	public static void main(String[] args) throws Exception{
		HashMap<String, HashMap<String, Double>> ansHashMap = parseAAIndex1File.getValues("D:/Protein�ᾧ/AAIndex/AAindex1.txt");
		System.out.println("ARGP820101");
		HashMap<String, Double> tmp = ansHashMap.get("ARGP820101");
		Object[] tOs = tmp.keySet().toArray();
		for (int i = 0; i < tOs.length; i++){
			System.out.print(tOs[i] + ":" + tmp.get(tOs[i]) + "\t");
			if (0 == (i+1)%5){
				System.out.println();
			}
		}
		
		HashMap<String, String> tttans = getDescrible("D:/Protein�ᾧ/AAIndex_Dataset/AAindex1.txt");
		System.out.println(tttans.get("ARGP820101"));
		System.out.println("END");
	}

}
