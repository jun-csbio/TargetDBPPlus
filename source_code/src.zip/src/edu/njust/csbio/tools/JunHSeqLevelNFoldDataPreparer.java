package edu.njust.csbio.tools;

import java.util.HashMap;
import java.util.Vector;

public class JunHSeqLevelNFoldDataPreparer {
	
	// ���е�fasta�ļ��еĵ����ʸ�ʽ����
	// 		>protein_id protein_label
	// 		protein sequence
	public static void prepare(String original_fasta_path, int n_fold, 
			String save_train_fasta_name, String save_test_fasta_name){
		HashMap<String, String> originalHM = FileUtil.parseFASTAProteinSeqs(original_fasta_path);
		Object[] originalIDs = originalHM.keySet().toArray();
		Vector<Object> posiIDs = new Vector<Object>();
		Vector<Object> negaIDs = new Vector<Object>();
		for (int i = 0; i < originalIDs.length; i++){
			String id = ""+originalIDs[i];
			if (id.endsWith("1")){
				posiIDs.add(originalIDs[i]);
			}else{
				negaIDs.add(originalIDs[i]);
			}
		}
		
		int posi_num = posiIDs.size();
		int nega_num = negaIDs.size();
		int posi_step = posi_num / n_fold;
		int nega_step = nega_num / n_fold;
		for (int i = 0; i < n_fold; i++){
			int posi_tst_start = i*posi_step;
			int posi_tst_end = (i+1)==n_fold ? posi_num : (i+1)*posi_step;
			int nega_tst_start = i*nega_step;
			int nega_tst_end = (i+1)==n_fold ? nega_num : (i+1)*nega_step;
			HashMap<String, String> train = new HashMap<String, String>();
			HashMap<String, String> test = new HashMap<String, String>();
			for (int j = 0; j < posi_num; j++){
				if (j >= posi_tst_start && j < posi_tst_end){
					test.put((String)posiIDs.get(j), originalHM.get(posiIDs.get(j)));
				}else{
					train.put((String)posiIDs.get(j), originalHM.get(posiIDs.get(j)));
				}
			}
			
			for (int j = 0; j < nega_num; j++){
				if (j >= nega_tst_start && j < nega_tst_end){
					test.put((String)negaIDs.get(j), originalHM.get(negaIDs.get(j)));
				}else{
					train.put((String)negaIDs.get(j), originalHM.get(negaIDs.get(j)));
				}
			}
			
			FileUtil.writeToFASTAFile(train, save_train_fasta_name+"_fold_"+(i+1)+".fasta");
			FileUtil.writeToFASTAFile(test, save_test_fasta_name+"_fold_"+(i+1)+".fasta");
		}
	}
	
	
	public static void main(String[] args) {
//		prepare("D:/SWAP/TRAINING1500.fasta", 5, "D:/SWAP/TRAINING1500_train", "D:/SWAP/TRAINING1500_test");
		prepare("D:/SWAP/CRYS-TRN.SCM.junh.fasta", 5, "D:/SWAP/CRYS-TRN_train", "D:/SWAP/CRYS-TRN_test");
		System.out.println("END");
	}

}
