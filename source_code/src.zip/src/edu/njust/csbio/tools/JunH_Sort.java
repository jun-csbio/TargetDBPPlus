package edu.njust.csbio.tools;

public class JunH_Sort {

	/**������������Ԫ�ص��±�*/
	public static int maxValueIndex(double[] arr){
		int max_index = 0;
		for (int i = 1; i < arr.length; i++){
			if (arr[i] > arr[max_index]){
				max_index = i;
			}
		}
		
		return max_index;
	}
	
	/**notice : algorithm do not change array content*/
	public static double[] inertSortFromSmallerToBigger(double[] array){
		double[] arr = new double[array.length]; // protect original array
		for (int i = 0; i < arr.length; i++){
			arr[i] = array[i];
		}
		
		for (int i = 0; i < arr.length; i++){
			double value = arr[i]; 
			for (int j = 0; j < i; j++){
				if (value < arr[j]){
					double tmp = arr[j];
					arr[j] = value;
					value = tmp;
				}
			}
			arr[i] = value;
		}
		
		return arr;
	}
	
	/**notice : algorithm do not change array content*/
	public static double[] inertSortFromSmallerToBigger(Object[] array){
		double[] arr = new double[array.length]; // protect original array
		for (int i = 0; i < arr.length; i++){
			arr[i] = (Double)(array[i]);
		}
		
		for (int i = 0; i < arr.length; i++){
			double value = arr[i]; 
			for (int j = 0; j < i; j++){
				if (value < arr[j]){
					double tmp = arr[j];
					arr[j] = value;
					value = tmp;
				}
			}
			arr[i] = value;
		}
		
		return arr;
	}
	
	/**notice : algorithm do not change array content*/
	public static double[] inertSortFromBiggerToSmaller(Object[] array){
		double[] arr = new double[array.length]; // protect original array
		for (int i = 0; i < arr.length; i++){
			arr[i] = (Double)(array[i]);
		}
		
		for (int i = 0; i < arr.length; i++){
			double value = arr[i]; 
			for (int j = 0; j < i; j++){
				if (value > arr[j]){
					double tmp = arr[j];
					arr[j] = value;
					value = tmp;
				}
			}
			arr[i] = value;
		}
		
		return arr;
	}
	
	/**
	 * @notice : algorithm do not change array content
	 * @return sort array index*/
	public static int[] inertSortFromSmallerToBigger_Index(double[] array){
		int[] index = new int[array.length];
		double[] arr = new double[array.length]; // protect original array
		for (int i = 0; i < arr.length; i++){
			index[i] = i;
			arr[i] = array[i];
		}
		
		for (int i = 0; i < arr.length; i++){
			double value = arr[i]; 
			int v = index[i];
			for (int j = 0; j < i; j++){
				if (value < arr[j]){
					double tmp = arr[j];
					arr[j] = value;
					value = tmp;
					
					int t = index[j];
					index[j] = v;
					v = t;
				}
			}
			arr[i] = value;
			index[i] = v;
		}
		
		return index;
	}
	
	public static void main(String[] args) {
		double[] arr = {0.1, 0.3,0.2};
		double[] ans = inertSortFromSmallerToBigger(arr);
		int[] ans_i = inertSortFromSmallerToBigger_Index(arr);
		
		for (int i = 0; i < arr.length; i++){
			System.out.print(arr[i] + " ");
		}
		System.out.println();
		for (int i = 0; i < ans.length; i++){
			System.out.print(ans[i] + " ");
		}
		System.out.println();
		for (int i = 0; i < ans_i.length; i++){
			System.out.print(ans_i[i] + " ");
		}
	}

}
