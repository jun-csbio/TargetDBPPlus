package edu.njust.csbio.tools;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.HashMap;

import edu.njust.csbio.tools.FileUtil;
import edu.njust.csbio.tools.parseAAIndex1File;


public class FeatureCreatorByAAIndex {
	private static String proteinSeqFASTAFilePath = "D:/Protein�ᾧ/2012 Data/TNEG72.fasta";
	private static String proteinAAIndexDatasetFilePath = "D:/Protein�ᾧ/AAIndex_Dataset/AAindex1.txt";
	private static String saveAllProteinFeatureFilePath = "D:/Protein�ᾧ/Feature/TNEG72.JunH.AAIndex.CRYSpred.Sub";
	
//	private static final String AAINDEX_FEATURETYPE = "KIDA850101 WOLR790101 ROSM880104 SNEP660102 WOLS870101 QIAN880115 QIAN880111 QIAN880112 QIAN880103 QIAN880104 QIAN880105 SUYM030101 RADA880108 COWR900101 QIAN880132 NISK860101 NADH010104 QIAN880128 ROBB760101 HOPT810101 BIOV880101 BAEK050101 GUYH850101 GUYH850102 CORJ870108 NAKH900110 NAKH900108 NAKH900104 NAKH900106 CIDH920101 CIDH920103 CIDH920105 PUNT030101 PUNT030102"; 
	private static final String AAINDEX_FEATURETYPE = "NAKH900113 KUMS000103 KUMS000104 GRAR740101 WERD780101 BAEK050101 COWR900101 CHAM830108 FAUJ880112";

	public static String createOneProteinAAFeature(String proteinSeq)throws Exception{
		HashMap<String, HashMap<String, Double>> AAIndexHashMap = parseAAIndex1File.getValues(proteinAAIndexDatasetFilePath);
		StringBuffer sbBuffer = new StringBuffer();
		int seqLen = proteinSeq.length();
		
		String[] featureTypeArr = AAINDEX_FEATURETYPE.split(" ");
		for (int i = 0; i < featureTypeArr.length; i++){
			double tmp = 0.0;
			HashMap<String, Double> tableHashMap = AAIndexHashMap.get(featureTypeArr[i]);
			for (int j = 0; j < seqLen; j++){
				Double tttDouble = tableHashMap.get(proteinSeq.substring(j, j + 1));
				if (null != tttDouble)	tmp += tttDouble;
			}
			tmp /= seqLen;
			
			DecimalFormat df = new DecimalFormat();
			df.applyPattern("#0.0000");
			
//			sbBuffer.append(df.format(tmp) + "\t");
			sbBuffer.append(df.format(0.01 * tmp) + " ");
		}
		
		return sbBuffer.toString().trim();
	} 
	
	public static void process() throws Exception{
		FileWriter fwFileWriter = new FileWriter(saveAllProteinFeatureFilePath);
		HashMap<String, String> proteinSeqHashMap = FileUtil.parseFASTAProteinSeqs(proteinSeqFASTAFilePath);
		Object[] proteinID = proteinSeqHashMap.keySet().toArray();
		for (int i = 0; i < proteinID.length; i++){
			String seqString = proteinSeqHashMap.get(proteinID[i]);
			 String featureString = createOneProteinAAFeature(seqString);
			 fwFileWriter.write(featureString + "\n");
		}
		fwFileWriter.close();
	}
	
	public static void main(String[] args)  throws Exception{
		process();
		System.out.println("OK");
	}

}
