package edu.njust.csbio.tools;

import java.util.HashMap;

public class TurnProteinSeq {

	// �����������з�ת�����
	public static String turnSeq(String seq){
		int len = seq.length();
		StringBuffer sb = new StringBuffer();
		for (int i = len-1; i >= 0; i--){
			sb.append(seq.charAt(i));
		}
		
		return sb.toString();
	}
	
	public static void turnFastaFile(String proteinSeqFastaFilePath, String saveTurnProteinSeqFastaFilePath){
		HashMap<String, String> turnSeqHm = new HashMap<String, String>();
		
		HashMap<String, String> seqHm = FileUtil.parseFASTAProteinSeqs(proteinSeqFastaFilePath);
		Object[] proteinIDs = seqHm.keySet().toArray();
		for (int i = 0; i < proteinIDs.length; i++){
			String turnseq = turnSeq(seqHm.get(proteinIDs[i]));
			turnSeqHm.put((String)proteinIDs[i], turnseq);
		}
		
		FileUtil.writeToFile(turnSeqHm, saveTurnProteinSeqFastaFilePath);
	}
	
	public static void main(String[] args) {
		turnFastaFile("D:/FlankATP/HMM/ATPseq_Validation.txt", "D:/FlankATP/HMM/ATPseq_Validation.txt.turn");
		turnFastaFile("D:/FlankATP/HMM/ATPseq.txt", "D:/FlankATP/HMM/ATPseq.txt.turn");
	}

}
