package edu.njust.csbio.tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Vector;

public class PDBFileParser {

	/**
	 * ����һ��������һ������������Ϣ
	 * */
	public static String readPDBSeqOfOneChain(
			String proteinPDBFile, char chain) throws Exception {
		File f = new File(proteinPDBFile);
		if (!f.isFile()) {
			System.out.println(proteinPDBFile + " is not exist!");
			return null;
		}

		StringBuffer seq_ans = new StringBuffer();

		BufferedReader br = new BufferedReader(new FileReader(f));
		String preIndex = "-1";
		String line = br.readLine();
		char AA = '?';
		while (null != line) {
			if (StrFunc.getXthWordInStr(line, ' ', 1).equals("ATOM") 
					&& StrFunc.getXthWordInStr(line, ' ', 3).equals("CA")
					&& chain == line.charAt(21)) {
				AA = AcidAbrevWord.acrossThreeWordToGetOneWord(line.substring(17, 20));
				String index = line.substring(22, 22+4).trim();
				if (!index.equals(preIndex)) {
					if (!preIndex.equals("-1")) {
						seq_ans.append(AA);
					} 

					preIndex = line.substring(22, 22+4).trim();
				}
			}
			
			line = br.readLine();
		}
		br.close();

		seq_ans.append(AA);
		return seq_ans.toString();
	}
	
	/**
	 * ����һ��������һ��������ά��� 
	 * ��������е�ÿ��Ԫ�ر�ʾһ���л�����ԭ�ӵ�3D��꣬ �ڲ������е�ÿ��Ԫ�ر�ʾÿ��ԭ��3D��� */
	public static Vector<Vector<double[]>> readPDB3DCoordinateOfOneChain(
			String proteinPDBFile, char chain) throws Exception {
		File f = new File(proteinPDBFile);
		if (!f.isFile()) {
			System.out.println(proteinPDBFile + " is not exist!");
			return null;
		}

		Vector<Vector<double[]>> ans = new Vector<Vector<double[]>>();
		Vector<double[]> vdA = new Vector<double[]>();

		BufferedReader br = new BufferedReader(new FileReader(f));
		String preIndex = "-1";
		String line = br.readLine();
		while (null != line) {
			if (StrFunc.getXthWordInStr(line, ' ', 1).equals("ATOM") && chain == line.charAt(21)) {
				double[] tdA = new double[3];
				tdA[0] = Double.parseDouble(line.substring(30, 38));
				tdA[1] = Double.parseDouble(line.substring(38, 46));
				tdA[2] = Double.parseDouble(line.substring(46, 54));

//				String index = StrFunc.getXthWordInStr(line, ' ', 6);
				String index = line.substring(22, 22+4).trim();
				if (!index.equals(preIndex)) {
					if (!preIndex.equals("-1")) {
						ans.add(vdA);
						vdA = new Vector<double[]>();
						vdA.add(tdA);
					} else {
						vdA.add(tdA);
					}

//					preIndex = StrFunc.getXthWordInStr(line, ' ', 6);
					preIndex = line.substring(22, 22+4).trim();
				} else {
					vdA.add(tdA);
				}

			}
			
			line = br.readLine();
		}
		br.close();

		ans.add(vdA);
		return ans;
	}
	
	/** ��������е�ÿ��Ԫ�ر�ʾһ���л�����ԭ�ӵ�3D��꣬ �ڲ������е�ÿ��Ԫ�ر�ʾÿ��ԭ��3D��� */
	public static Vector<Vector<double[]>> readPDB3DCoordinate(
			String proteinPDBFile) throws Exception {
		File f = new File(proteinPDBFile);
		if (!f.isFile()) {
			System.out.println(proteinPDBFile + " is not exist!");
			return null;
		}

		Vector<Vector<double[]>> ans = new Vector<Vector<double[]>>();
		Vector<double[]> vdA = new Vector<double[]>();

		BufferedReader br = new BufferedReader(new FileReader(f));
		String preIndex = "-1";
		String line = br.readLine();
		while (null != line) {
			if (StrFunc.getXthWordInStr(line, ' ', 1).equals("ATOM")) {
				double[] tdA = new double[3];
				tdA[0] = Double.parseDouble(line.substring(30, 38));
				tdA[1] = Double.parseDouble(line.substring(38, 46));
				tdA[2] = Double.parseDouble(line.substring(46, 54));

//				String index = StrFunc.getXthWordInStr(line, ' ', 6);
				String index = line.substring(22, 22+4).trim();
				if (!index.equals(preIndex)) {
					if (!preIndex.equals("-1")) {
						ans.add(vdA);
						vdA = new Vector<double[]>();
						vdA.add(tdA);
					} else {
						vdA.add(tdA);
					}

//					preIndex = StrFunc.getXthWordInStr(line, ' ', 6);
					preIndex = line.substring(22, 22+4).trim();
				} else {
					vdA.add(tdA);
				}

			}
			
			line = br.readLine();
		}
		br.close();

		ans.add(vdA);
		return ans;
	}

	/** �����е�ÿ��Ԫ�ض���ʾһ��Caԭ�ӵ�3D��� */
	public static Vector<double[]> readPDBCaAtom3DCoordinate(
			String proteinPDBFile) throws Exception {
		File f = new File(proteinPDBFile);
		if (!f.isFile()) {
			System.out.println(proteinPDBFile + " is not exist!");
			return null;
		}

		Vector<double[]> vdA = new Vector<double[]>();
		BufferedReader br = new BufferedReader(new FileReader(f));
		String line = br.readLine();
		while (null != line) {
			if (StrFunc.getXthWordInStr(line, ' ', 1).equals("ATOM")
					&& StrFunc.getXthWordInStr(line, ' ', 3).equals("CA")) {
				double[] tdA = new double[3];
				tdA[0] = Double.parseDouble(line.substring(30, 38));
				tdA[1] = Double.parseDouble(line.substring(38, 46));
				tdA[2] = Double.parseDouble(line.substring(46, 54));
				vdA.add(tdA);
			}
			line = br.readLine();
		}
		br.close();
		return vdA;
	}
	
	public static double[] getCenter3DXYZ(Vector<double[]> vd) throws Exception{
		double[] ans = new double[3];
		ans[0] = 0;ans[1] = 0;ans[2] = 0;
		
		int size = vd.size();
		for (int i = 0; i < size; i++){
			double[] tmp = vd.get(i);
			ans = VectorCalculator.AaddB(ans, tmp);
		}
		
		ans = VectorCalculator.Adiv_b(ans, size);
		
		return ans;
	}

	public static void main(String[] args) throws Exception {
		File folder = new File("J:/PDB-3D");
		File[] files = folder.listFiles();
		HashMap<String, String> pdb_3d_seq = new HashMap<String, String>();
		char[] chain_set = {'A', 'B', 'C', 'D', 'E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
		for (int i = 0; i < files.length; i++){
			String name = files[i].getName().substring(0, 4);
			System.out.println(name);
			for (int j = 0; j < chain_set.length; j++){
				String seq = readPDBSeqOfOneChain(files[i].getAbsolutePath(), chain_set[j]);
				if (seq.startsWith("?")){
					continue;
				}
				
				pdb_3d_seq.put(name+chain_set[j], seq);
			}
		}
		
		FileUtil.writeToFASTAFile(pdb_3d_seq, "J:/PDB-3D/seq_from_pdb3D.fasta");
		
//		Vector<Vector<double[]>> ansVector = readPDB3DCoordinate("D:/Academic[From20131208]/PCAsite/dataset/BioLip/receptor/2BU3A.pdb");
//		int max = 0;
//		for (int i = 0; i < ansVector.size(); i++){
//			if (ansVector.get(i).size() > max){
//				max = ansVector.get(i).size();
//			}
//		}
//		System.out.println(ansVector.size());
////		Vector<double[]> ansVector2 = readPDBCaAtom3DCoordinate("D:/BLAST_SVM_RF_Paper/Dataset/receptor/1AOQA.pdb");
//		System.out.println("---------------------------- : " + max);
	}

}
