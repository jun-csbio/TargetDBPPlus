package edu.njust.csbio.tools;

public class PostProcessorOfResiduesScores {

	// winsize could be 3,5,7 will better
	public static double[] postProcess(double[] scores, int winsize,
			double lowTh, double highTh, double lowest, double highest) {
		int len = scores.length;
		double[] ans = new double[len];
		int pos = 0;
		for (; pos < winsize / 2; pos++) {
			ans[pos] = scores[pos];
		}
		for (int i = 0; i < len - winsize + 1; i++) {
			double[] wincontent = new double[winsize];
			for (int j = 0; j < winsize; j++) {
				wincontent[j] = scores[i + j];
			}
			double new_center_score = rules(wincontent, lowTh, highTh, lowest, highest);
			ans[pos] = new_center_score;
			pos++;
		}

		for (; pos < len; pos++) {
			ans[pos] = scores[pos];
		}

		return ans;
	}

	private static double rules(double[] wincontent, double lowTh, double highTh, double lowest, double highest) {
		double ans = Double.MAX_VALUE;
		double center = wincontent[wincontent.length/2];
		if (center < lowest){
			ans = 0;
		}else if (center >= highest){
			ans = 1;
		}else{
			double tmp;
			if (Double.MIN_VALUE != (tmp = ruleOne(wincontent, lowTh))) {	//����1
				ans = tmp;
			} else if (Double.MIN_VALUE != (tmp = ruleTwo(wincontent, highTh))) { //����2
				ans = tmp;
			}else{	//����3(����Ԫ����lowTh��highTh֮��)
				double m_all = JunHMath.average(wincontent);
				double sd_all = JunHMath.standart_deviation(wincontent);
				double[] left = new double[wincontent.length/2];
				double[] right = new double[wincontent.length/2];
				for (int i = 0; i < wincontent.length/2; i++){
					left[i] = wincontent[i];
					right[i] = wincontent[wincontent.length-1-i];
				}
				double m_left = JunHMath.average(left);
				double sd_left = JunHMath.standart_deviation(left);
				double m_right = JunHMath.average(left);
				double sd_right = JunHMath.standart_deviation(left);
				
				if (sd_all > sd_left && sd_all > sd_right){
					if (m_left > m_right){
						if (center > m_all){
							ans = m_left;
						}else{
							ans = m_right;
						}
					}else{
						if (center <= m_all){
							ans = m_left;
						}else{
							ans = m_right;
						}
					}
				}else if (sd_left > sd_all && sd_right > sd_all){
					ans = m_all;
				}else{
					ans = center;
				}
			}
		}
		return ans;
	}

	// ������������һ(�����������ݶ�<lowTh), return Doubl
	// ����������һ�� �ⷵ�����Ĵ�����ֵ
	private static double ruleOne(double[] wincontent, double lowTh) {
		int winsize = wincontent.length;
		boolean satisfy = true;
		for (int i = 0; i < winsize; i++) {
			if (wincontent[i] >= lowTh) {
				satisfy = false;
				break;
			}
		}

		double ans = Double.MIN_VALUE;
		if (satisfy) {
			ans = 0;
		}

		return ans;
	}

	// ������������2(�����������ݶ�>=highTh), return Doubl
	// ����������2�� �ⷵ�����Ĵ�����ֵ
	private static double ruleTwo(double[] wincontent, double highTh) {
		int winsize = wincontent.length;
		boolean satisfy = true;
		for (int i = 0; i < winsize; i++) {
			if (wincontent[i] < highTh) {
				satisfy = false;
				break;
			}
		}

		double ans = Double.MIN_VALUE;
		if (satisfy) {
			ans = 1;
		}

		return ans;
	}

	public static void main(String[] args) {
		try{
			double[][] scores = JunHMatrix.loadMatrix("D:/FlankATP/227/Validation/ATPlabel_Validation.txt.PSIBLAT_PSSM.N4W17top0libsvm_junh_format_test_res");
			double[] score =new double[scores.length];
			for (int i = 0; i < scores.length; i++){
				score[i] = scores[i][1];
			}
			
			double[] ans = postProcess(score, 5, 0.466, 0.7, 0.1, 0.95);
			for (int i = 0; i < scores.length; i++){
				scores[i][1] = ans[i];
				scores[i][2] = 1- ans[i];
			}
			JunH_File_Process.writeToFile(scores, "D:/FlankATP/227/Validation/ATPlabel_Validation.txt.PSIBLAT_PSSM.N4W17top0libsvm_junh_format_test_res.postprocess");
			System.out.println("END");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}

