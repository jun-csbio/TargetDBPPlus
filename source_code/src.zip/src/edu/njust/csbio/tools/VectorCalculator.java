package edu.njust.csbio.tools;

import java.util.Vector;

public class VectorCalculator {

	public static double[] AaddB(double[] a, double[] b) throws Exception{
		if (a.length != b.length){
			throw new Exception("Vector size is not match!");
		}
		
		for (int i = 0; i < a.length; i++){
			a[i] += b[i];
		}
		
		return a;
	}
	
	public static double[] ASubB(double[] a, double[] b) throws Exception{
		if (a.length != b.length){
			throw new Exception("Vector size is not match!");
		}
		
		for (int i = 0; i < a.length; i++){
			a[i] -= b[i];
		}
		
		return a;
	}
	
	public static double[] Adiv_b(double[] a, double b){
		for (int i = 0; i < a.length; i++){
			a[i] /= b;
		}
		
		return a;
	}
	
	public static double[] meanV(Vector<double[]> vd) throws Exception{
		double[] ans = new double[3];
		ans[0] = 0;ans[1] = 0;ans[2] = 0;
		
		int size = vd.size();
		for (int i = 0; i < size; i++){
			double[] tmp = vd.get(i);
			ans = VectorCalculator.AaddB(ans, tmp);
		}
		
		ans = VectorCalculator.Adiv_b(ans, size);
		
		return ans;
	}
	
	public static double[] meanVV(Vector<Vector<double[]>> vvd) throws Exception{
		double[] ans = new double[3];
		ans[0] = 0;ans[1] = 0;ans[2] = 0;
		
		int num = 0;
		for (int i = 0; i < vvd.size(); i++){
			Vector<double[]> tmp = vvd.get(i);
			num += tmp.size();
			for (int j = 0; j < tmp.size(); j++){
				ans = VectorCalculator.AaddB(ans, tmp.get(j));
			}
		}
		
		ans = VectorCalculator.Adiv_b(ans, num);
		
		return ans;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
