package edu.njust.csbio.tools;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Vector;

public class JunH_File_Process {

	public static String[] readStrArrByEnter(String file_path)throws Exception{
		StringBuffer sb = new StringBuffer();
		BufferedReader br = new BufferedReader(new FileReader(file_path));
		String line = br.readLine();
		while (null != line){
			sb.append(line+"###");
			
			line = br.readLine();
		}
		br.close();
		String[] ans = sb.toString().split("###");
		return ans;
	}
	
	public static double[][] readMatrixByTAB(String matrixFilePath)throws Exception{
		Vector<double[]> tans = new Vector<double[]>();
		
		BufferedReader br = new BufferedReader(new FileReader(matrixFilePath));
		String line = br.readLine();
		while (null != line){
			String[] lineArr = line.trim().split("\t");
			double[] t = new double[lineArr.length];
			for (int i = 0; i < t.length; i++){
				t[i] = Double.parseDouble(lineArr[i]);
			}
			tans.add(t);
			line = br.readLine();
		}
		br.close();
		int ansLen = tans.size();
		double[][] ans = new double[ansLen][tans.get(0).length];
		for (int i = 0; i < ansLen; i++){
			for (int j = 0; j < tans.get(0).length; j++){
				ans[i][j] = tans.get(i)[j];
			}
		}
		return ans;
	}
	
	public static void writeToFile(Vector<double[]> content, String filePath)throws Exception{
		DecimalFormat df = new DecimalFormat();
		df.applyPattern("#0.0000000000");
		
		FileWriter fw = new FileWriter(filePath);
		int size = content.size();
		for (int i = 0; i < size; i++){
			double[] tmp = content.get(i);
			for (int j = 0; j < tmp.length; j++){
				fw.write(df.format(tmp[j]) + "\t");
			}
			fw.write("\n");
		}
		fw.close();
	}
	
	public static void writeToFile(double[][] content, String filePath)throws Exception{
		DecimalFormat df = new DecimalFormat();
		df.applyPattern("#0.00000000");
		
		FileWriter fw = new FileWriter(filePath);
		int size = content.length;
		for (int i = 0; i < size; i++){
			double[] tmp = content[i];
			for (int j = 0; j < tmp.length; j++){
				fw.write(df.format(tmp[j]) + "\t");
			}
			fw.write("\n");
		}
		fw.close();
	}
	
	public static void writeToFile(double[] content, String filePath)throws Exception{
		DecimalFormat df = new DecimalFormat();
		df.applyPattern("#0.00000000");
		
		FileWriter fw = new FileWriter(filePath);
		for (int i = 0; i < content.length; i++){
				fw.write(content[i] + "\t");
		}
		
		fw.write("\n");
		fw.close();
	}

	public static void writeToFileWithLIBSVMFormat(Vector<double[]> feature, int[] label, String filePath) throws Exception{
		DecimalFormat df = new DecimalFormat();
		df.applyPattern("#0.00000000");
		
		if (feature.size() != label.length){
			throw new Exception("param is not match!");
		}
		
		FileWriter fw = new FileWriter(filePath);
		int size = feature.size();
		for (int i = 0; i < size; i++){
			fw.write(label[i]+"\t");
			double[] tmp = feature.get(i);
			for (int j = 0; j < tmp.length; j++){
				fw.write((j+1)+":"+df.format(tmp[j]) + "\t");
			}
			fw.write("\n");
		}
		fw.close();
	}
	
	public static void writeToFileWithLIBSVMFormat(Vector<double[]> feature, double[] label, String filePath) throws Exception{
		DecimalFormat df = new DecimalFormat();
		df.applyPattern("#0.00000000");
		
		if (feature.size() != label.length){
			throw new Exception("param is not match!");
		}
		
		FileWriter fw = new FileWriter(filePath);
		int size = feature.size();
		for (int i = 0; i < size; i++){
			fw.write((int)label[i]+"\t");
			double[] tmp = feature.get(i);
			for (int j = 0; j < tmp.length; j++){
				fw.write((j+1)+":"+df.format(tmp[j]) + "\t");
			}
			fw.write("\n");
		}
		fw.close();
	}
	
	// the last dimension is label
	public static void writeToFileWithLIBSVMFormat(double[][] partten_label, String filePath) throws Exception{
		DecimalFormat df = new DecimalFormat();
		df.applyPattern("#0.00000000");
		
		FileWriter fw = new FileWriter(filePath);
		int num = partten_label.length;
		int partten_dim = partten_label[0].length - 1;
		for (int i = 0; i < num; i++){
			if (partten_label[i][partten_dim] == 1.0){
				fw.write("1\t");
			}else{
				fw.write("2\t");
			}
			double[] tmp = partten_label[i];
			for (int j = 0; j < tmp.length - 1; j++){
				fw.write((j+1)+":"+df.format(tmp[j]) + "\t");
			}
			fw.write("\n");
		}
		fw.close();
	}

	public static boolean isTheSameOfFileAandFileB(String A_path, String B_path)throws Exception{
		return false;
	}
	
	public static boolean isTheSameContentOfFastaAandFastaB(String FastaA_path, String FastaB_path)throws Exception{
		boolean isSame = true;
		HashMap<String, String> aHm = FileUtil.parseFASTAProteinSeqs(FastaA_path);
		HashMap<String, String> bHm = FileUtil.parseFASTAProteinSeqs(FastaB_path);
		if (aHm.size() == bHm.size()){
			Object[] a_ids = aHm.keySet().toArray();
			for (int i = 0; i < a_ids.length; i++){
				String b_content = bHm.get(a_ids[i]);
				if (null != b_content){
					String a_content = aHm.get(a_ids[i]);
					if (!a_content.replaceAll("\n", "").toUpperCase()
							.equals(b_content.replaceAll("\n", "").toUpperCase())){
						isSame = false;
						break;
					}
				}else{
					isSame = false;
					break;
				}
			}
		}else{
			isSame = false;
		}
		
		return isSame;
	}
	
	public static boolean isTheSameContentOfSameIDOnFastaFile(String small_fasta_path,
			String big_fasta_path) throws Exception {
		boolean isSame = true;
		HashMap<String, String> aHm = FileUtil.parseFASTAProteinSeqs(small_fasta_path);
		HashMap<String, String> bHm = FileUtil.parseFASTAProteinSeqs(big_fasta_path);
		Object[] a_ids = aHm.keySet().toArray();
		for (int i = 0; i < a_ids.length; i++) {
			String b_content = bHm.get(a_ids[i]);
			if (null != b_content) {
				String a_content = aHm.get(a_ids[i]);
				if (!a_content.replaceAll("\n", "").toUpperCase().trim().replaceAll(" ", "")
						.equals(b_content.replaceAll("\n", "").toUpperCase().trim().replaceAll(" ", ""))) {
					System.out.println(a_ids[i] + " is not match!");
					isSame = false;
					break;
				}
			}
		}

		return isSame;
	}
	
	public static void repairSeqFastaFile(String original_seq_fasta_path, String save_repair_seq_fasta_path)throws Exception{
		String AA_ARRAY = "ACDEFGHIKLMNPQRSTVWYUX";
		HashMap<String, String> seqHm = FileUtil.parseFASTAProteinSeqs(original_seq_fasta_path);
		Object[] ids = seqHm.keySet().toArray();
		for (int i = 0; i < ids.length; i++){
			String seq = seqHm.get(ids[i]).toUpperCase();
			StringBuffer replaceChs = new StringBuffer();
			for (int j = 0; j < seq.length(); j++){
				if (!AA_ARRAY.contains(""+seq.charAt(j))){
					replaceChs.append(seq.charAt(j));
				}
			}
			
			// 鏁堢巼涓嶉珮
			System.out.println(replaceChs.length());
			String err_chs = replaceChs.toString(); 
			for (int j = 0; j < err_chs.length(); j++){
				seq = seq.replaceAll(""+err_chs.charAt(j), "");
			}
			
			seqHm.remove(ids[i]);
			seqHm.put((String)ids[i], seq);
		}
		
		FileUtil.writeToFASTAFile(seqHm, save_repair_seq_fasta_path);
	}
	
}
