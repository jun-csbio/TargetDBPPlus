package edu.njust.csbio.tools;

public class Temp {
	public int[] posArr = null;
	public double[] disArr = null;

	public Temp(int[] posArr, double[] disArr) {
		this.posArr = posArr;
		this.disArr = disArr;
	}
}
