package edu.njust.csbio.tools;

import java.util.Random;
import java.util.Vector;

public class C_Mean {
	public double[][] residueCoordinator = null;
	
	public C_Mean(double[][] residueCoordinator){
		this.residueCoordinator = residueCoordinator;
	}
	
	public Vector<String[]> simpleAlgorithm(String[] residuePosInProtein, int classNum)throws Exception{
//		int[] center = randCreateNotSameNumInRange(classNum, 0, residuePosInProtein.length);
		int[] center = aritificialCreateNotSameNumInRange(classNum, 0, residuePosInProtein.length);
		double[][] centerInfoOld = getCenterFeaturInfoByPos(residuePosInProtein, center);
		StringBuffer[] sbA = new StringBuffer[classNum];
		for (int i = 0; i < classNum; i++){
			sbA[i] = new StringBuffer();
		}
		
		while (true){
			for (int i = 0; i < residuePosInProtein.length; i++){
				double[] ifeature = residueCoordinator[Integer.parseInt(residuePosInProtein[i].substring(1))-1]; //
				double iDisCenterMin = Double.MAX_VALUE;
				int beClassNo = -1; 	
				for (int j = 0; j < classNum; j++){
					double temp = getTwoPosOdis(ifeature, centerInfoOld[j]);
					if (temp < iDisCenterMin){
						iDisCenterMin = temp;
						beClassNo = j;
					}
				}
				
				sbA[beClassNo].append(residuePosInProtein[i] + "#");
			}
			
			double[][] centerInfoNew = new double[classNum][residueCoordinator[0].length];
			for (int i = 0; i < classNum; i++){
				centerInfoNew[i] = updateCenteFeatureByPos(sbA[i].toString().trim().split("#"));
			}
			
			double disSum = 0.0;
			for (int i = 0; i < classNum; i++){
				disSum += getTwoPosOdis(centerInfoOld[i], centerInfoNew[i]);
			}
			
			if (disSum < 0.01){
				break;
			}
			
			for (int i = 0; i < classNum; i++){
				sbA[i].delete(0, sbA[i].length());
				centerInfoOld[i] = centerInfoNew[i];
			}
		}
		
		Vector<String[]> vsA = new Vector<String[]>();
		for (int i = 0; i < classNum; i++){
			vsA.add(sbA[i].toString().trim().split("#"));
		}
		return vsA;
	} 

	public double[] updateCenteFeatureByPos(String[] residuePosInProteinOfClassX){
		int sampleNum = residuePosInProteinOfClassX.length;
		double[] ans = new double[residueCoordinator[0].length];
		for (int i = 0; i < sampleNum; i++){
			for (int j = 0; j < ans.length; j++){
				ans[j] += residueCoordinator[Integer.parseInt(residuePosInProteinOfClassX[i].substring(1))-1][j];
			}
		}
		
		for (int j = 0; j < ans.length; j++){
			ans[j] /= sampleNum;
		}
		
		return ans;
	}
	
	private double[][] getCenterFeaturInfoByPos(String[] residuePosInProtein, int[] center){
		double[][] ans = new double[center.length][residueCoordinator[0].length];
		for (int i = 0; i < center.length; i++){
			ans[i] = residueCoordinator[Integer.parseInt(residuePosInProtein[center[i]].substring(1))-1];
		}
		return ans;
	}
	
	public double getTwoPosOdis(double[] posa, double[] posb)throws Exception{
		int aws = posa.length;
		int bws = posb.length;
		if (aws != bws){
			System.out.println("SpaceCluster getTwoPosOdis: the two pos has not the same dimension.");
			throw new Exception("SpaceCluster getTwoPosOdis: the two pos has not the same dimension.");
		}
		
		double ans = 0.0;
		for (int i = 0; i < aws; i++){
			ans += (posa[i] - posb[i]) * (posa[i] - posb[i]); 
		}
		return Math.sqrt(ans);
	}
	
	public int[] aritificialCreateNotSameNumInRange(int classNum, int start, int end)throws Exception{
		if (end-start<classNum){
			throw new Exception("Array Exceed");
		}
		
		int[] center = new int[classNum];
		int step = (end-start)/classNum;
		for (int i = 0; i < classNum; i++){
			if (0 != step)
				center[i] = i*step;
			else
				center[i] = i;
		}
		return center;
	}
	
	public int[] randCreateNotSameNumInRange(int classNum, int start, int end){
		Random rand = new Random();
		int[] center = new int[classNum];
		for (int i = 0; i < classNum; i++){
			center[i] = -1;
		}
		for (int i = 0; i < classNum; i++){
			int temp = Math.abs(rand.nextInt()) % (end - start) + start;
			while (true){
				boolean tag = true;
				for (int j = i-1; j >=0; j--){
					if (temp == center[j]){
						temp = Math.abs(rand.nextInt()) % (end - start)  + start;
						tag = false;
						break;
					}
				}
				
				if (tag){
					break;
				}
			}
			center[i] = temp;
		}
		
		return center;
	}
	
	public static void main(String[] args) throws Exception{
		double[][] data = new double[3][2];
		data[0][0] = 0.12;
		data[0][1] = 0.13;
		data[1][0] = 3;
		data[1][1] = 4;
		data[2][0] = 0.12;
		data[2][1] = 0.31;
		String[] rP = new String[3];
		rP[0] = "S0";
		rP[1] = "P1";
		rP[2] = "U2";
		C_Mean cm = new C_Mean(data);
		Vector<String[]> vsA = cm.simpleAlgorithm(rP, 2);
		for (int i = 0; i < vsA.size(); i++){
			for (int j = 0; j < vsA.get(i).length; j++){
				System.out.println(vsA.get(i)[j]);
			}
			System.out.println();
		}
	}

}
