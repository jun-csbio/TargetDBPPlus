package edu.njust.csbio.tools;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Set;
import java.util.Vector;

public class FileUtil {
	public byte[] contents = null;
	public FileUtil() {
	}
	public FileUtil(byte[] contents) {
		this.contents = contents;
	}    
	public FileUtil(String absoluteFileName){
		try {
			File file = new File(absoluteFileName);			
			FileInputStream in = new FileInputStream(file);
			int size = in.available();
			contents = new byte[size];
			in.read(contents);
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
			contents = null;
		}
	}
	public void setContents(byte[] contents) {
		this.contents = contents;
	}
	public byte [] getContents(){
		return this.contents;
	}
	public void writeToFile(String path, String fileName) {
		try {
			File pathFile = new File(path);
			if(!pathFile.exists())
				pathFile.mkdirs();			
			File file = new File(path + System.getProperties().getProperty("file.separator") + fileName);
			FileOutputStream out = new FileOutputStream(file);
			out.write(contents);
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void writeToFile(String fileName) {
		try {			
			File file = new File(fileName);
			FileOutputStream out = new FileOutputStream(file);
			out.write(contents);
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	
	public static void writeToFile(HashMap<String, String> contents, String fileName){
		File f = new File(fileName);
		if (!f.isFile()){
			System.out.println("FileFunc_writeToFile:Sorry " + fileName + "is not exist, we recreate it!");
			try {
				f.createNewFile();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		try {
			FileWriter w = new FileWriter(f);
			Set<String> s = contents.keySet();
			Object[] oArr = s.toArray();
			for (int i=0; i<oArr.length; i++){
				w.write(">" + oArr[i]+ "\n");
				w.write(contents.get(oArr[i]) + "\n");
			}
			w.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void writeToFASTAFile(HashMap<String, String> contents, String fileName){
		File f = new File(fileName);
		if (!f.isFile()){
			System.out.println("writeToFASTAFile:Sorry " + fileName + "is not exist, we recreate it!");
			try {
				f.createNewFile();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		try {
			FileWriter w = new FileWriter(f);
			Set<String> s = contents.keySet();
			Object[] oArr = s.toArray();
			for (int i=0; i<oArr.length; i++){
				w.write(">" + oArr[i]+ "\n");
				w.write(contents.get(oArr[i]) + "\n");
			}
			w.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static boolean copy(String fileFrom, String fileTo) {
		try {
			InputStream in = new FileInputStream(fileFrom);
			OutputStream out = new FileOutputStream(fileTo);
			byte[] bt = new byte[1024];
			int count;
			while ((count = in.read(bt)) > 0) {
				out.write(bt, 0, count);
			}
			in.close();
			out.close();
			return true;
		} catch (IOException ex) {
			System.out.println("Copy Error!");
			ex.printStackTrace();
			return false;
		}
	}
	public static void close(DataInputStream in) {
		try {
			if (in != null)
				in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void close(InputStream in) {
		try {
			if (in != null)
				in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void close(DataOutputStream out) {
		try {
			if (out != null)
				out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void close(DatagramSocket out) {
		try {
			if (out != null)
				out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void close(FileOutputStream out) {
		try {
			if (out != null)
				out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void close(OutputStreamWriter out) {
		try {
			if (out != null)
				out.close();
		} catch (Exception e) {
			//e.printStackTrace();
		}
	}

	public static void close(Socket s) {
		try {
			if (s != null)
				s.close();
		} catch (Exception e) {
			//e.printStackTrace();
		}
	}//
	public static void close(BufferedReader s) {
		try {
			if (s != null)
				s.close();
		} catch (Exception e) {
			//e.printStackTrace();
		}
	}
	public static void close(ServerSocket s) {
		try {
			if (s != null)
				s.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static double[][] readFileToArr(String filePath){
		File f = new File(filePath);
		if (!f.isFile()){
			System.out.println("readFileToArr Wrong " + filePath);
//			System.exit(-1);
		}
		
		Vector<double[]> res_v = new Vector<double[]>();
		
		try {
			BufferedReader bf = new BufferedReader(new FileReader(f));
			String line = bf.readLine();
			while (null != line){
				String[] lineContents = StrUtil.getWordsInStr(line, ' ');
				double[] tD = new double[lineContents.length];
				for (int i = 0; i < lineContents.length; i++){
					try{
						tD[i] = Double.parseDouble(lineContents[i]);
					}catch(Exception e){
						System.out.println(line);
						System.out.println(i + lineContents[i]);
						System.out.println(filePath);
//						System.exit(-1);
					}
				}
				res_v.add(tD);
				line = bf.readLine();
			}
			bf.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		double[][] res = new double[res_v.size()][res_v.get(0).length];
		for (int i = 0; i < res_v.size(); i++){
			res[i] = res_v.get(i);
		}
		
		return res;
	} 
	
	public static HashMap<String, String> parseFASTAProteinSeqs(String fileName) {
		HashMap<String, String> proteinSeqs = new HashMap<String, String>();
		try {
			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String proteinCode = "";
			StringBuffer proteinSeq = new StringBuffer();
			String line = in.readLine();
			while (line != null) {
				if (!line.startsWith("#")) { 
					if (line.startsWith(">")) {
						if (!proteinCode.equals("")) {
							String str = proteinSeq.toString();
							if (str.endsWith("\n"))
								str = str.substring(0, str.length() - 1);
							proteinSeqs.put(proteinCode.trim().toUpperCase(), str);
						}
						proteinCode = line.substring(1, line.length());
						proteinSeq.delete(0, proteinSeq.length());
					} else {
						if (!line.equals("")) {
							proteinSeq.append(line + "\n");
						}
					}
				}
				line = in.readLine();
			}
			if (!proteinCode.equals("")) {
				String str = proteinSeq.toString();
				if (str.endsWith("\n"))
					str = str.substring(0, str.length() - 1);
				proteinSeqs.put(proteinCode.trim().toUpperCase(), str);
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return proteinSeqs;
	}
	
	public static void writeToFileLineByLine(String line, String aimFilePath)throws Exception{
		File f = new File(aimFilePath);
		if (!f.isFile()){
			f.createNewFile();
		}
		
		FileWriter fw = new FileWriter(f, true);
		fw.write(line+"\n");
		fw.close();
	}
	
	public static void writeToFile(StringBuffer sb, String aimFilePath)throws Exception{
		File f = new File(aimFilePath);
		if (!f.isFile()){
			f.createNewFile();
		}
		
		FileWriter fw = new FileWriter(f);
		fw.write(sb.toString());
		fw.close();
	}
	
	public static void writeToFileLineByLine(String line, FileWriter fw)throws Exception{
		fw.write(line+"\n");
	}
	
    public static void copyFile(File sourceFile, File targetFile) throws IOException {
        BufferedInputStream inBuff = null;
        BufferedOutputStream outBuff = null;
        try {
        	String targetFilePath = targetFile.getParent();
        	File targetParentFile = new File(targetFilePath);
        	if(!targetParentFile.exists()){
        		targetParentFile.mkdirs();
        	}
            inBuff = new BufferedInputStream(new FileInputStream(sourceFile));

            outBuff = new BufferedOutputStream(new FileOutputStream(targetFile));

            byte[] b = new byte[1024 * 5];
            int len;
            while ((len = inBuff.read(b)) != -1) {
                outBuff.write(b, 0, len);
            }
            outBuff.flush();
        } finally {
            if (inBuff != null)
                inBuff.close();
            if (outBuff != null)
                outBuff.close();
        }
    }
    
    public static HashMap<String, String> junhSpeCopyPDBFile(File sourceFile, File targetFile, String ChainType) throws Exception {
    	String targetFilePath = targetFile.getParent();
    	File targetParentFile = new File(targetFilePath);
    	if(!targetParentFile.exists()){
    		targetParentFile.mkdirs();
    	}
    	    	  	    	
    	FileWriter fw = new FileWriter(targetFile);
    	String preIndexStr = "YanDanDan2012-12-26";
    	int preIndexInt = 0;
    	HashMap<String, String> ans = new HashMap<String, String>();
    	
    	BufferedReader srcBr = new BufferedReader(new FileReader(sourceFile));
    	String line = srcBr.readLine();
    	while (null != line){
    		if (line.startsWith("ATOM")) {
    			String acidType = line.substring(17, 20);
    			if (3 == acidType.trim().length()){
    				String chainType = line.substring(21, 22);
    				if (chainType.equalsIgnoreCase(ChainType)) {
    					String preLine = line.substring(0, 22);
    					String IndexStr = line.substring(22, 26);
    					String afterLine = line.substring(26);
    					if (IndexStr.equals(preIndexStr)){
    						fw.write(preLine + StrUtil.formatStrToFixLen(Integer.toString(preIndexInt), 26-22) + afterLine + "\n");
    					}else{    						
    						fw.write(preLine + StrUtil.formatStrToFixLen(Integer.toString(++preIndexInt), 26-22) + afterLine + "\n");
    						preIndexStr = IndexStr;
    						
    						ans.put(IndexStr.trim(), Integer.toString(preIndexInt));
    					}
    				}
    			}
			}
    		line = srcBr.readLine();
    	}
    	srcBr.close();
    	fw.close();
    	
    	return ans;
    }
    
    public static HashMap<String, String> chooseXPercentInFASTAFile(String FASTAFilePath, double percent)throws Exception{
    	if (percent > 1.0 || percent < 0.0){
    		throw new Exception("percent must range from 0 to 1.");
    	}
    	
    	HashMap<String, String> ans = new HashMap<String, String>();
    	HashMap<String, String> all = FileUtil.parseFASTAProteinSeqs(FASTAFilePath);
    	Object[] fastaContent = all.keySet().toArray();
    	int ansNum = (int)Math.floor(1.0 * fastaContent.length * percent);
    	int step = (int)Math.floor(1.0 * fastaContent.length / ansNum); //must more than 1
    	for (int i = 0; i < ansNum; i++){
    		ans.put((String)fastaContent[i*step], all.get(fastaContent[i*step]));
    	}
    	return ans;
    }
    
//    public static void main(String[] args){
//    	System.out.println((int)Math.floor(1.0 * 5 / 3));
//    }
}
