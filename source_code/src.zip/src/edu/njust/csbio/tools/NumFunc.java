package edu.njust.csbio.tools;

public class NumFunc {

	public static boolean isAMoreBigThanB(double A, double B){
		if (A / B >= 3){
			return true;
		}
		return false;
	}
	
	/**
	 * @param type : false sub, true div*/
	public static boolean isAMoreBigThanB(double A, double B, double compare, boolean type){
		if (1.0 * A / B >= compare && type){
			return true;
		}else if (A - B >= compare && !type){
			return true;
		}
		return false;
	}
	
	public static boolean isAMoreBigThanB(int A, int B){
		if (A / B >= 3){
			return true;
		}
		return false;
	}
	
	public static boolean isAMoreBigThanB(int A, int B, double mul){
		if (1.0 * A / B >= mul){
			return true;
		}
		return false;
	}
	
	public static boolean isAMoreBigThanB(int A, int B, int more){
		if (A - B >= more){
			return true;
		}
		return false;
	}
	
	public static double mean(double...ds){
		double ans = 0.0;
		int paramLen = ds.length;
		for (int i = 0; i < paramLen; i++){
			ans += ds[i];
		}
		
		return ans/ds.length;
	}
	
	public static void main(String[] args) {
		System.out.println(mean(4, 5.3, 6));
	}

}
