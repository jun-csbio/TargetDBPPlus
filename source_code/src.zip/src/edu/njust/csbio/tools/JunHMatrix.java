package edu.njust.csbio.tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Vector;

public class JunHMatrix {
	
	public static double standart_deviationXColValue(double[][] data, int x) {
		double[] data_x = new double[data.length];
		for (int i = 0; i < data.length; i++){
			data_x[i] = data[i][x];
		}
		
		return JunHMath.standart_deviation(data_x);
	}
	
	public static double averageXColValue(double[][] data, int x) {
		double sum = 0.0;
		for (int i = 0; i < data.length; i++){
			sum += data[i][x];
		}
		return sum / data.length;
	}
	
	public static double[][] matrixCat(double[][]... ds) {
		int ansLen = 0;
		int paramLen = ds.length;
		for (int i = 0; i < paramLen; i++) {
			ansLen += ds[i].length;
		}

		double[][] ans = new double[ansLen][];
		int pos = 0;
		for (int i = 0; i < paramLen; i++) {
			for (int j = 0; j < ds[i].length; j++) {
				ans[pos] = ds[i][j];
				pos++;
			}
		}
		return ans;
	}
	
	public static double[][] matrixCatPerRow(double[][]... ds) {
		int ansLen = 0;
		int paramLen = ds.length;
		for (int i = 0; i < paramLen; i++) {
			ansLen += ds[i][0].length;
		}

		double[][] ans = new double[ds[0].length][ansLen];
		for (int i = 0; i < ans.length; i++){
			int pos = 0;
			for (int j = 0; j < paramLen; j++){
				for (int k = 0; k < ds[j][i].length; k++){
					ans[i][pos++] = ds[j][i][k];
				}
			}
		}
		return ans;
	}
	
	public static Vector<double[]> matrixCat(Vector<double[]> aim, double[][] add) {
		for (int i = 0; i < add.length; i++) {
			aim.add(add[i]);
		}
		return aim;
	}
	
	public static double[][] select(double[][] original, int[] selectPos,
			boolean isSelectePosStartZero) {
		double[][] ans = new double[original.length][selectPos.length];
		for (int i = 0; i < original.length; i++){
			ans[i] = JunHVector.select(original[i],	 selectPos, isSelectePosStartZero);
		}
		return ans;
	}
	
	public static double[][] select(double[][] original, Vector<Integer> selectPos,
			boolean isSelectePosStartZero) {
		double[][] ans = new double[original.length][selectPos.size()];
		for (int i = 0; i < original.length; i++){
			ans[i] = JunHVector.select(original[i], selectPos, isSelectePosStartZero);
		}
		return ans;
	}
	
	public static double[][] transpose(double[][] arr){
		double[][] ans = new double[arr[0].length][arr.length];
		for (int i = 0; i < arr.length; i++){
			for (int j = 0; j < arr[i].length; j++){
				ans[j][i] = arr[i][j];
			}
		}
		return ans;
	}
	
	public static double[][] exchangeVDArrToD2Arr(Vector<double[]> VDArr){
		int VDArr_size = VDArr.size();
		double[][] ans = new double[VDArr_size][VDArr.get(0).length];
		for (int i = 0; i < VDArr_size; i++){
			ans[i] = VDArr.get(i);
		}
		return ans;
	}
	
	public static Vector<double[]> exchangeD2ArrToVDArr(double[][] VDArr){
		int VDArr_len = VDArr.length;
		Vector<double[]> ans = new Vector<double[]>();
		for (int i = 0; i < VDArr_len; i++){
			ans.add(VDArr[i]);
		}
		return ans;
	}
	
	public static double[] exchangeVDArrToArr(Vector<double[]> VDArr){
		int VDArr_size = VDArr.size();
		int Arr_column = VDArr.get(0).length;
		double[] ans = new double[VDArr_size*Arr_column];
		for (int i = 0; i < VDArr_size; i++){
			for (int j = 0; j < Arr_column; j++)
			ans[i*Arr_column+j] = VDArr.get(i)[j];
		}
		return ans;
	}
	
	public static double[] exchangeD2ArrToArr(double[][] D2Arr){
		int D2Arr_size = D2Arr.length;
		int Arr_column = D2Arr[0].length;
		double[] ans = new double[D2Arr_size*Arr_column];
		for (int i = 0; i < D2Arr_size; i++){
			for (int j = 0; j < Arr_column; j++)
			ans[i*Arr_column+j] = D2Arr[i][j];
		}
		return ans;
	}
	
	public static double[][] loadMatrix(String matrixFilePath)throws Exception{
		Vector<double[]> tans = new Vector<double[]>();
		
		BufferedReader br = new BufferedReader(new FileReader(matrixFilePath));
		String line = br.readLine();
		while (null != line){
			String[] lineArr = line.trim().split(" +|	");
			double[] t = new double[lineArr.length];
			for (int i = 0; i < t.length; i++){
				t[i] = Double.parseDouble(lineArr[i]);
			}
			tans.add(t);
			line = br.readLine();
		}
		br.close();
		int ansLen = tans.size();
		double[][] ans = new double[ansLen][tans.get(0).length];
		for (int i = 0; i < ansLen; i++){
			for (int j = 0; j < tans.get(0).length; j++){
				ans[i][j] = tans.get(i)[j];
			}
		}
		return ans;
	}
	
	public static double[][] pssmMulSCD(double[][] pssm, double[][] SCD){
		double[][] ans = new double[pssm.length][SCD[0].length];
		
		for (int i = 0; i < pssm.length; i++){
			for (int j = 0; j < SCD[0].length; j++){
				ans[i][j] = 0;
				for (int k = 0; k < SCD.length; k++){
					ans[i][j] += pssm[i][k] * SCD[k][j];
				}
			}
		}
		
		return ans;
	}
	
	public static double[][] aT_mul_b(double[][] a, double[][] b)throws Exception{
		int rows_a = a.length;
		int rows_b = b.length;
		if (rows_a != rows_b){
			throw new Exception("sorry! the row num of matrix a is not the same as matrix b.");
		}
		
		double[][] aT = transpose(a);
		return a_mul_b(aT, b);
	} 
	
	public static double[][] a_mul_b(double[][] a, double[][] b)throws Exception{
		if (a[0].length != b.length){
			throw new Exception("sorry! the column num of matrix a is not the same as the row num of matrix b.");
		}
		
		double[][] ans = new double[a.length][b[0].length];
		
		for (int i = 0; i < a.length; i++){
			for (int j = 0; j < b[0].length; j++){
				ans[i][j] = 0;
				for (int k = 0; k < b.length; k++){
					ans[i][j] += a[i][k] * b[k][j];
				}
			}
		}
		
		return ans;
	}
	
	public static double[] mean_value_by_colum(double[][] matrix){
		double[] ans = new double[matrix[0].length];
		for (int i = 0; i < ans.length; i++) ans[i] = 0;
		for (int i = 0; i < matrix.length; i++){
			for (int j = 0; j < matrix[i].length; j++){
				ans[j] += matrix[i][j];
			}
		}
		for (int i = 0; i < ans.length; i++) ans[i] /= matrix.length;
		return ans;
	}
	
	public static double[] diagonalElement(double[][] squarematrix) throws Exception{
		if (squarematrix.length != squarematrix[0].length){
			throw new Exception("sorry! the param is not square matrix.");
		}
		double[] ans = new double[squarematrix.length];
		for (int i = 0; i < squarematrix.length; i++){
			ans[i] = squarematrix[i][i];
		}
		
		return ans;
	}
	
	public static void saveMatrix(double[][] arr, String saveFilePath){
		File f = new File(saveFilePath);
		if (!f.isFile()) {
			System.out.println(saveFilePath + " is not exist! we create it!");
			try {
				f.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
			}
		}
		
		DecimalFormat df = new DecimalFormat();
		df.applyPattern("#0.000000");

		try {
			FileWriter fw = new FileWriter(f); 
			for (int i = 0; i < arr.length; i++){
				StringBuffer sb = new StringBuffer();
				for (int j = 0; j < arr[i].length; j++) {
					sb.append(df.format(arr[i][j]) + " ");
				}
					fw.write(sb.toString().trim());
				fw.write("\n");
			}
			fw.close();
			} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static double[][] normalizedColumn_Type_I(double[][] matrix){
		int row = matrix.length;
		int col = matrix[0].length;
		double[][] ans = new double[row][col];
		
		for (int c = 0; c < col; c++){
			// calculate the average 
			double c_ave = 0.0;
			for (int r = 0; r < row; r++){
				c_ave += matrix[r][c];
			}
			c_ave /= 1.0*row;
			// calculate the standard deviation 
			double s_dev = 0.0;
			for (int r = 0; r < row; r++){
				s_dev += (matrix[r][c]-c_ave)*(matrix[r][c]-c_ave);
			}
			s_dev = Math.sqrt(s_dev/1.0*row);
			
			if (0.0 == s_dev){
				s_dev += 0.000001;
			}
			//calculate the normalized elements
			for (int r = 0; r < row; r++){
				ans[r][c] = (matrix[r][c] - c_ave) / s_dev;
			}
		}
		
		return ans;
	}
	
	public static double[][] normalizedColumn_Type_II(double[][] matrix) {
		int row = matrix.length;
		int col = matrix[0].length;
		double[][] ans = new double[row][col];

		for (int c = 0; c < col; c++) {
			double max = Double.MIN_VALUE;
			double min = Double.MAX_VALUE;
			for (int r = 0; r < row; r++) {
				if (matrix[r][c] > max) {
					max = matrix[r][c];
				}
				if (matrix[r][c] < min) {
					min = matrix[r][c];
				}
			}

			if (max == min) {
				max = min + 0.000001;
			}

			// calculate the normalized elements
			for (int r = 0; r < row; r++) {
				ans[r][c] = (matrix[r][c] - min) / (max - min);
			}
		}

		return ans;
	}
	
	/**
	 * x = (x-u)/sd for each row
	 * */
	public static double[][] normalizedRowByGaussEq(double[][] matrix){
		int row = matrix.length;
		int col = matrix[0].length;
		double[][] ans = new double[row][col];
		
		for (int i = 0; i < row; i++){
			double u = JunHMath.average(matrix[i]);
			double sd = JunHMath.standart_deviation(matrix[i]);
			
			for (int j = 0; j < col; j++){
				ans[i][j] = (matrix[i][j] - u) / (sd + 0.000001);
			}
		}
		
		return ans;
	}
	
	/**
	 * x = (x-min)/(max-min) for all
	 * */
	public static double[][] normalizedAllByMaxMin(double[][] matrix){
		int row = matrix.length;
		int col = matrix[0].length;
		double[][] ans = new double[row][col];
		
		double max = Double.MIN_VALUE;
		double min = Double.MAX_VALUE;
		for (int i = 0; i < row; i++){
			for (int j = 0; j < col; j++) {
				if (max < matrix[i][j]){
					max = matrix[i][j];
				}
				if (min > matrix[i][j]){
					min = matrix[i][j];
				}
			}
		}
		
		for (int i = 0; i < row; i++){
			for (int j = 0; j < col; j++){
				ans[i][j] = (matrix[i][j] - min) / (max - min);
			}
		}
		
		return ans;
	}
	
	public static double[] averageRow(double[][] matrix){
		int row = matrix.length;
		int col = matrix[0].length;
		double[] ans = new double[col];
		for (int i = 0; i < row; i++){
			for (int j = 0; j < col; j++){
				ans[j] += matrix[i][j];
			}
		}
		
		for (int j = 0; j < col; j++){
			ans[j] /= row;
		}
		
		return ans;
	}
	
	public static double[][] normalized_Type_II(double[][] matrix){
		int row = matrix.length;
		int col = matrix[0].length;
		double[][] ans = new double[row][col];

		double max = Double.MIN_VALUE;
		double min = Double.MAX_VALUE;
		for (int r = 0; r < row; r++){
			for (int c = 0; c < col; c++){
				if (max < matrix[r][c]){
					max = matrix[r][c];
				}
				
				if (min > matrix[r][c]){
					min = matrix[r][c];
				}
			}
		}
		
		for (int r = 0; r < row; r++){
			for (int c = 0; c < col; c++){
				ans[r][c] = (matrix[r][c]-min)/(max-min);
			}
		}
		
		return ans;
	}
	
	public static double[][] onesMatrix(int row, int col){
		double[][] ans = new double[row][col];
		for (int r = 0; r < row; r++){
			for (int c = 0; c < col; c++){
				ans[r][c] = 1.0;
			}
		}
		return ans;
	}
		
	public static boolean isSameMatrixes(double[][] a, double[][] b)throws Exception{ //a, b閻ㄥ墕ize韫囧懘銆忛弰顖欑閺嶉娈�
		int a_row = a.length;
		int a_col = a[0].length;
		int b_row = b.length;
		int b_col = b[0].length;
		
		if (a_row != b_row || a_col != b_col){
			throw new Exception("the size of a and b is not same.");
		}
		
		boolean ans = true;
		
		for (int i = 0; i  < a_row; i++){
			for (int j = 0; j < a_col; j++){
				if (a[i][j] != b[i][j]){
					ans = false;
					break;
				}
			}
			
			if (false == ans){
				break;
			}
		}
		
		return ans;
	}
	
	public static void copyContent(double[][] from, double[][] to)throws Exception{
		if (from == null || to == null){
			throw new Exception("the from or to matrix is null!");
		}
		
		int f_row = from.length;
		int f_col = from[0].length;
		int t_row = to.length;
		int t_col = to[0].length;
		
		if (f_row != t_row || f_col != t_col){
			throw new Exception("the size of a and b is not same.");
		}
		
		for (int i  =0; i < f_row; i++){
			for (int j = 0; j < f_col; j++){
				to[i][j] = from[i][j];
			}
		}
	}
	
	public static double[][] copyContent(double[][] from)throws Exception{
		if (from == null ){
			throw new Exception("the from matrix is null!");
		}
		
		int f_row = from.length;
		int f_col = from[0].length;
		double[][] to = new double[f_row][f_col];
		
		for (int i  =0; i < f_row; i++){
			for (int j = 0; j < f_col; j++){
				to[i][j] = from[i][j];
			}
		}
		
		return to;
	}
	
	public static HashMap<Double, Integer> searchElementTypesAndNum(double[][] matrix){
		int row = matrix.length;
		int col = matrix[0].length;
		HashMap<Double, Integer> ans = new HashMap<Double, Integer>();
		for (int i = 0; i < row; i++){
			for (int j = 0; j < col; j++){
				Integer tmp = ans.get(matrix[i][j]);
				if (null == tmp){
					tmp = new Integer(1);
					ans.put(matrix[i][j], tmp);
				}else{
					ans.put(matrix[i][j], tmp+1);
				}
			}
		}
		
		return ans;
	}
	
	public static double[][] a_add_b(double[][] a, double[][] b)throws Exception{
		int a_row = a.length;
		int a_col = a[0].length;
		int b_row = b.length;
		int b_col = b[0].length;
		
		if (a_row != b_row || a_col != b_col){
			throw new Exception("the size of a and b is not same.");
		}
		
		double[][] ans = new double[a_row][a_col];
		for (int i = 0; i  < a_row; i++){
			for (int j = 0; j < a_col; j++){
				ans[i][j] = a[i][j] + b[i][j];
			}
		}
		
		return ans;
	}
	
	public static double[][] a_sub_b(double[][] a, double[][] b)throws Exception{
		int a_row = a.length;
		int a_col = a[0].length;
		int b_row = b.length;
		int b_col = b[0].length;
		
		if (a_row != b_row || a_col != b_col){
			throw new Exception("the size of a and b is not same.");
		}
		
		double[][] ans = new double[a_row][a_col];
		for (int i = 0; i  < a_row; i++){
			for (int j = 0; j < a_col; j++){
				ans[i][j] = a[i][j] - b[i][j];
			}
		}
		
		return ans;
	}
	
	public static double[][] matrixDivideReal(double[][] a, double r)throws Exception{
		int a_row = a.length;
		int a_col = a[0].length;
		
		double[][] ans = new double[a_row][a_col];
		for (int i = 0; i  < a_row; i++){
			for (int j = 0; j < a_col; j++){
				ans[i][j] = a[i][j] / r;
			}
		}
		
		return ans;
	}
	
	public static void main(String[] args){
		double[][] a = {{1, 3}, {3, 9}};
		double[][] ans = matrixCatPerRow(a, a);
		System.out.println(ans[0][0] + " " + ans[0][1]+ " " + ans[0][2]+ " " + ans[0][3]);
	}
}
