package edu.njust.csbio.tools;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.DecimalFormat;
import java.util.Vector;

public class ArrayUtil {
 static DecimalFormat df3 = new DecimalFormat();
 static DecimalFormat df6 = new DecimalFormat();
 static {
  df3.applyPattern("#0.000");
  df6.applyPattern("#0.000000");
 }

 public static String doubleArray2Str_df6(double[] a) {
  StringBuffer buf = new StringBuffer();
  for (int i = 0; i < a.length; i++) {
   buf.append(StrUtil.formatStrToFixLen(df6.format(a[i]), 10));
  }
  return buf.toString();
 }

 public static String doubleArray2Str_df6_seperated_by_comma(double[] a) {
  StringBuffer buf = new StringBuffer();
  for (int i = 0; i < a.length; i++) {
   buf.append(StrUtil.formatStrToFixLen(df6.format(a[i]), 10));
   buf.append(",");
  }
  return buf.toString();
 }

 public static String[] mergeStringArray(String[] a, String[] b) {
  String[] result = new String[a.length + b.length];
  for (int i = 0; i < result.length; i++) {
   if (i < a.length)
    result[i] = a[i];
   else
    result[i] = b[i - a.length];
  }
  return result;
 }

 public static Class<?>[] mergeClassArray(Class<?>[] a, Class<?>[] b) {
  Class<?>[] result = new Class<?>[a.length + b.length];
  for (int i = 0; i < result.length; i++) {
   if (i < a.length)
    result[i] = a[i];
   else
    result[i] = b[i - a.length];
  }
  return result;
 }

 public static double findMax(double[][] array) {
  double max = array[0][0];
  for (int i = 0; i < array.length; i++) {
   for (int j = 0; j < array[i].length; j++) {
    if (array[i][j] > max) {
     max = array[i][j];
    }
   }
  }
  return max;
 }

 public static double findMax(double[] array) {
  double max = array[0];
  for (int i = 0; i < array.length; i++) {
   if (array[i] > max) {
    max = array[i];
   }
  }
  return max;
 }

 public static double findMin(double[] array) {
  double min = array[0];
  for (int i = 0; i < array.length; i++) {
   if (array[i] < min) {
    min = array[i];
   }
  }
  return min;
 }

 public static double findMin(double[][] array) {
  double min = array[0][0];
  for (int i = 0; i < array.length; i++) {
   for (int j = 0; j < array[i].length; j++) {
    if (array[i][j] < min) {
     min = array[i][j];
    }
   }
  }
  return min;
 }

 public static double[] sumByColumn_Average(double m[][]) {
  int row = m.length;
  int col = m[0].length;
  double[] result = new double[col];
  for (int j = 0; j < col; j++) {
   double temp = 0.0;
   for (int i = 0; i < row; i++) {
    temp = temp + m[i][j];
   }
   result[j] = temp / (double) row;
  }
  return result;
 }

 public static double[] matrix2vector(double m[][]) {
  int row = m.length;
  int col = m[0].length;
  double[] result = new double[row * col];
  for (int i = 0; i < row; i++) {
   for (int j = 0; j < col; j++) {
    result[i * col + j] = m[i][j];
   }
  }
  return result;
 }

 public static double[] averageMatrixByColumn(double[][] matrix) {
  double[] average = new double[matrix[0].length];
  for (int col = 0; col < matrix[0].length; col++) {
   double temp = 0;
   for (int row = 0; row < matrix.length; row++) {
    temp += matrix[row][col];
   }
   average[col] = temp / (double) (matrix.length);
  }

  return average;
 }
 
 public static double[] filterMatrixByColumn(double[][] matrix) {
  for (int col = 0; col < matrix[0].length; col++) {
   for (int row = 0; row < matrix.length; row++) {
    if (0.33 > matrix[row][col]){  //threshold = 0.33
     matrix[row][col] = 0;
    }
   }
  }
  return averageMatrixByColumn(matrix);
 }

 public static double[][] doubleArrays2Matrix(Vector<double[]> data) {
  int row = data.size();
  if (row == 0)
   return null;
  int column = data.elementAt(0).length;
  double[][] result = new double[row][column];
  for (int i = 0; i < row; i++) {
   double[] line = data.elementAt(i);
   for (int j = 0; j < column; j++) {
    result[i][j] = line[j];
   }
  }
  return result;
 }

 public static double[] matrix2vector_by_Row(double m[][]) {
  int row = m.length;
  int col = m[0].length;
  double[] result = new double[row * col];
  for (int i = 0; i < row; i++) {
   for (int j = 0; j < col; j++) {
    result[i * col + j] = m[i][j];
   }
  }
  return result;
 }

 public static double[] matrix2vector_by_Column(double m[][]) {
  int row = m.length;
  int col = m[0].length;
  double[] result = new double[row * col];
  for (int i = 0; i < col; i++) {
   for (int j = 0; j < row; j++) {
    result[i * row + j] = m[j][i];
   }
  }
  return result;
 }

 public static double distanceWithSquare(double[] m1, double[] m2) {
  double dist = 0.0;
  for (int i = 0; i < m1.length; i++) {
   dist += (m1[i] - m2[i]) * (m1[i] - m2[i]);
  }
  return dist;
 }

 public static double distance(double[] m1, double[] m2) {
  double dist = 0.0;
  for (int i = 0; i < m1.length; i++) {
   dist += (m1[i] - m2[i]) * (m1[i] - m2[i]);
  }
  return Math.sqrt(dist);
 }

 public static String doubleArray2ColumnStr(double[] a) {
  StringBuffer buf = new StringBuffer();
  for (int i = 0; i < a.length; i++) {
   buf.append(df3.format(a[i]));
   buf.append("\n");
  }
  return buf.toString().trim();
 }

 // Normalize
 public static double[] normalize_occurrence_frequency(double[] array) {
  double sum = 0.0;
  for (int i = 0; i < array.length; i++) {
   sum += array[i];
  }

  for (int i = 0; i < array.length; i++) {
   array[i] = array[i] / sum;
  }

  for (int i = 0; i < array.length; i++)
   array[i] = array[i];
  return array;
 }

 // ----------------------Normalize Yang jian Pattern
 // Recognition--------------------------

 public static double[][] normalize_array_2_unit_vector(double[][] array) {
  int row = array.length;
  int col = array[0].length;
  double[][] normalized = new double[row][col];
  for (int i = 0; i < row; i++) {
   double fenmu = 0.0;
   for (int j = 0; j < col; j++) {
    fenmu = fenmu + array[i][j] * array[i][j];
   }

   for (int j = 0; j < col; j++) {
    normalized[i][j] = array[i][j] / Math.sqrt(fenmu);
   }
  }

  return normalized;
 }

 public static double[] normalize_array_2_unit_vector(double[]array) {
 int col = array.length;
  double[] normalized = new double[col];
  
   double fenmu = 0.0;
   for (int j = 0; j < col; j++) {
    fenmu = fenmu + array[j] * array[j];
   }

   for (int j = 0; j < col; j++) {
    normalized[j] = array[j] / Math.sqrt(fenmu);
   }
  

  return normalized;
 }
 public static double[][] normalize_array_normal_distribution_by_coulumn(double[][] array) {
  int row = array.length;
  int col = array[0].length;
  double[][] normalized = new double[row][col];
  for (int j = 0; j < col; j++) {
   double meanValue = 0;
   for (int i = 0; i < row; i++) {
    meanValue += array[i][j];
   }
   meanValue = meanValue / (double) row;
   double fenmu = 0;
   for (int i = 0; i < row; i++) {
    fenmu = fenmu + (array[i][j] - meanValue) * (array[i][j] - meanValue);
   }
   fenmu = Math.sqrt(fenmu / (double) row);

   for (int i = 0; i < row; i++) {
    double fenzi = array[i][j] - meanValue;
    if (fenmu == 0) {
     normalized[i][j] = 0;
    } else {
     normalized[i][j] = fenzi / fenmu;
    }
   }
  }
  return normalized;
 }

 public static void saveMatrix_Seperated_by_Blank(String path, String fileName, double[][] matrix) {
  DecimalFormat df = new DecimalFormat();
  df.applyPattern("#0.000000");
  StringBuffer buf = new StringBuffer();
  for (int i = 0; i < matrix.length; i++) {
   for (int j = 0; j < matrix[i].length; j++) {
    buf.append(StrUtil.formatStrToFixLen(df.format(matrix[i][j]), 10));
   }
   buf.append("\n");
  }
  FileUtil fu = new FileUtil();
  String str = buf.toString();
  str = str.substring(0, str.length() - 1);
  fu.setContents(str.getBytes());
  fu.writeToFile(path, fileName);
 }
 public static void saveMatrix_Seperated_by_Comma(String path, String fileName, double[][] matrix) {
  DecimalFormat df = new DecimalFormat();
  df.applyPattern("#0.000000");
  StringBuffer buf = new StringBuffer();
  for (int i = 0; i < matrix.length; i++) {
   for (int j = 0; j < matrix[i].length; j++) {
    buf.append(StrUtil.formatStrToFixLen(df.format(matrix[i][j]), 10));
    if(j!=matrix[i].length-1)
     buf.append(",");
   }
   buf.append("\n");
  }
  FileUtil fu = new FileUtil();
  String str = buf.toString();
  str = str.substring(0, str.length() - 1);
  fu.setContents(str.getBytes());
  fu.writeToFile(path, fileName);
 }
 public static void saveMatrix_Seperated_by_Comma(String fileName, double[][] matrix) {
  DecimalFormat df = new DecimalFormat();
  df.applyPattern("#0.000000");
  StringBuffer buf = new StringBuffer();
  for (int i = 0; i < matrix.length; i++) {
   for (int j = 0; j < matrix[i].length; j++) {
    buf.append(StrUtil.formatStrToFixLen(df.format(matrix[i][j]), 10));
    if(j!=matrix[i].length-1)
     buf.append(",");
   }
   buf.append("\n");
  }
  FileUtil fu = new FileUtil();
  String str = buf.toString();
  str = str.substring(0, str.length() - 1);
  fu.setContents(str.getBytes());
  fu.writeToFile( fileName);
 }


 public static void saveMatrix_Seperated_by_Blank(String path, String fileName, int[][] matrix) {
  DecimalFormat df = new DecimalFormat();
  df.applyPattern("#0.000000");
  StringBuffer buf = new StringBuffer();
  for (int i = 0; i < matrix.length; i++) {
   for (int j = 0; j < matrix[i].length; j++) {
    buf.append(StrUtil.formatStrToFixLen(df.format(matrix[i][j]), 10));
   }
   buf.append("\n");
  }
  FileUtil fo = new FileUtil();
  String str = buf.toString();
  str = str.substring(0, str.length() - 1);
  fo.setContents(str.getBytes());
  fo.writeToFile(path, fileName);
 }                           
 public static void saveMatrix_Seperated_by_Comma(String path, String fileName, int[][] matrix) {
  DecimalFormat df = new DecimalFormat();
  df.applyPattern("#0.000000");
  StringBuffer buf = new StringBuffer();
  for (int i = 0; i < matrix.length; i++) {
   for (int j = 0; j < matrix[i].length; j++) {
    buf.append(StrUtil.formatStrToFixLen(df.format(matrix[i][j]), 10));
   }
   buf.append("\n");
  }
  FileUtil fo = new FileUtil();
  String str = buf.toString();
  str = str.substring(0, str.length() - 1);
  fo.setContents(str.getBytes());
  fo.writeToFile(path, fileName);
 } 

 public static double[][] readMatrix_Seperated_by_Blank(String fileName) {
  Vector<double[]> matrixVec = new Vector<double[]>();

  BufferedReader in = null;
  try {
   in = new BufferedReader(new FileReader(fileName));
   String line = in.readLine();
   while (line != null) {
    // Regular  Expression
    String[] elements = line.trim().split(" +"); 
    double[] row = new double[elements.length];
    for (int i = 0; i < elements.length; i++) {
     row[i] = Double.parseDouble(elements[i].trim());
    }
    matrixVec.addElement(row);
    line = in.readLine();
   }
  } catch (Exception e) {
   e.printStackTrace();
  } finally {
   FileUtil.close(in);
  }
  double[][] matrix = new double[matrixVec.size()][];
  for (int i = 0; i < matrixVec.size(); i++) {
   matrix[i] = (double[]) matrixVec.elementAt(i);
  }
  return matrix;
 }
 public static double[][] readMatrix_Seperated_by_Comma(String fileName) {
  Vector<double[]> matrixVec = new Vector<double[]>();

  BufferedReader in = null;
  try {
   in = new BufferedReader(new FileReader(fileName));
   String line = in.readLine();
   while (line != null) {
    // Regular  Expression
    String[] elements = line.trim().split(","); 
    double[] row = new double[elements.length];
    for (int i = 0; i < elements.length; i++) {
     row[i] = Double.parseDouble(elements[i].trim());
    }
    matrixVec.addElement(row);
    line = in.readLine();
   }
  } catch (Exception e) {
   e.printStackTrace();
  } finally {
   FileUtil.close(in);
  }
  double[][] matrix = new double[matrixVec.size()][];
  for (int i = 0; i < matrixVec.size(); i++) {
   matrix[i] = (double[]) matrixVec.elementAt(i);
  }
  return matrix;
 }
 public static void main(String[] args) {
  double[][] m = readMatrix_Seperated_by_Blank("./1.txt");
  System.out.println(m.length);
  StrUtil.print(m);
 }
}
