package edu.njust.csbio.tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class PDBFileToSeqTranslator {
	private String workFolderPath = null;
	private String pdbFileName = null; // 1X12C.pdb Or 1X12C
	private String saveCAPDBFileName = null; // 1X12C.pdb.CA Or 1X12C.CA

	public PDBFileToSeqTranslator(String workFolderPath, String pdbFileName,
			String saveCAPDBFileName) {
		this.workFolderPath = workFolderPath;
		this.pdbFileName = pdbFileName;
		this.saveCAPDBFileName = saveCAPDBFileName;
	}

	// ��ȡPDB�ļ��е���ص�"CA"��
	private void readFixRowOfFile() throws Exception {
		File f = new File(workFolderPath + "/" + pdbFileName);
		if (!f.isFile()) {
			throw new Exception(pdbFileName + "is not exist!");
		}

		try {
			BufferedReader bufReader = new BufferedReader(new FileReader(f));
			StringBuffer strBuf = new StringBuffer();
			String line = bufReader.readLine();
			String preIndex = "0";
			while (null != line) {
				line = line.trim();
				if (StrFunc.getXthWordInStr(line, ' ', 1).equalsIgnoreCase("ATOM")
						&& line.substring(21, 22).equalsIgnoreCase(pdbFileName.substring(4, 5))
						&& StrFunc.getXthWordInStr(line, ' ', 3).equalsIgnoreCase("CA")
						&& !StrFunc.getXthWordInStr(line, ' ', 6).equalsIgnoreCase(preIndex)) {
					strBuf.append(line + "#");
					// remove the same index CA ATOM TAG
					preIndex = StrFunc.getXthWordInStr(line, ' ', 6); 
				}
				line = bufReader.readLine();
			}
			bufReader.close();

			String[] strArr = strBuf.toString().split("#");
			FileFunc.writeToFile(strArr, workFolderPath + "/"
					+ saveCAPDBFileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * @return : eg: >1XB2A ATSRDHFKG....SDF
	 * */
	public String[] translate() throws Exception {
		readFixRowOfFile();

		BufferedReader bf = new BufferedReader(new FileReader(workFolderPath
				+ "/" + saveCAPDBFileName));

		StringBuffer sb = new StringBuffer();
		String line = bf.readLine();
		while (null != line) {
			String acid = StrFunc.getXthWordInStr(line, ' ', 4);
			char a = AcidAbrevWord.acrossThreeWordToGetOneWord(acid);
			sb.append(a);

			line = bf.readLine();
		}
		bf.close();

		StringBuffer strbuff = new StringBuffer();
		strbuff.append(pdbFileName.substring(0, 5) + "#");
		strbuff.append(sb.toString() + "#");
		return strbuff.toString().split("#");
	}

	public static void main(String[] args) throws Exception {
		PDBFileToSeqTranslator pdbSeqSwitcher = new PDBFileToSeqTranslator(
				args[0], args[1], args[2]);
		String[] nameSeq = pdbSeqSwitcher.translate();
		System.out.println(">" + nameSeq[0] + "\n" + nameSeq[1]);
	}
}
