package _util;

public class _Str {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String part_seq = "ELEELQQNIKLELEGKEQELALELLNYLNEKGFLSKSVEEISDVLRCSVEELEKVRQKVLRLEPLGVCSKDVWEFLELQIEEIYPEEEEILKKALRDLKRGKKLKPEIKGKLSRLRLFPLSAEKVYTFAKVDAIIEEENGEFFIYLYEDFIDIDLNEEYWELYKKSRNLQKELKEAFERYESIRKVLDIRRRNLRKVLEKIVERQKDFLTGKGSLKPLTLREVSSEIGIHESTLSRIVNSKYVKTPVGTYSLRTFFVRESAEGLTQGELMKLIKEIVENEDKRKPYSDQEIANILKEKGFKVARRTVAKYREMLGIPSSRERR";
		String full_seq = "GPHMETVPYQIPYTPSELEELQQNIKLELEGKEQELALELLNYLNEKGFLSKSVEEISDVLRCSVEELEKVRQKVLRLEPLGVCSKKDVWEFLELQIEEIYPEEEEILKKALRDLKRGKKLKPEIKGKLSRLRLFPLSSSAEKVYTFAKVDAIIEEENGEFFIYLYEDFIDIDLNEEYWELYKKSRNLQKELKEAFERYESIRKVLDIRRRNLRKVLEKIVERQKDFLTGKGSLKPLTLREVSSEIGIHESTLSRIVNSKYVKTPVGTYSLRTFFVRESAEGLTQGELMKLIKEIVENEDKRKPYSDQEIANILKEKGFKVARRTVAKYREMLGIPSSRERRI";
		
		String[] ans = _Str.AlignTwoProteinSeqIgnoreLittleMistakeInMW(part_seq, full_seq);
		
		System.out.println(ans[0]+"\n"+ans[1]);
	}

	public static String replenishHeadWithSpace(String str, int total_len){
		int oLen = str.length();
		if (oLen > total_len)
			return str;
		
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < total_len-oLen; i++)
			sb.append(' ');
		sb.append(str);
		
		return sb.toString();
	}
	
	public static String replenishHeadWithChar(String str, int total_len, char ch){
		int oLen = str.length();
		if (oLen > total_len)
			return str;
		
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < total_len-oLen; i++)
			sb.append(ch);
		sb.append(str);
		
		return sb.toString();
	}
	
	public static String replenishEndWithSpace(String str, int total_len){
		int oLen = str.length();
		if (oLen > total_len)
			return str;
		
		StringBuffer sb = new StringBuffer();
		sb.append(str);
		for (int i = 0; i < total_len-oLen; i++)
			sb.append(' ');
		
		return sb.toString();
	}
	
	public static String replenishEndWithChar(String str, int total_len, char ch){
		int oLen = str.length();
		if (oLen > total_len)
			return str;
		
		StringBuffer sb = new StringBuffer();
		sb.append(str);
		for (int i = 0; i < total_len-oLen; i++)
			sb.append(ch);
		
		return sb.toString();
	}
	
	public static double tanimotoCoefficient(String FPTa, String FPTb){
		int len = FPTa.length() > FPTb.length() ? FPTb.length() : FPTa.length();
		
		int aasum = 0;
        int bbsum = 0;
        int absum = 0;
        
        for(int i = 0; i < len; i++){
        	double a = 0;
        	if ('1' == FPTa.charAt(i))
        		a = 1;
        	
        	double b = 0;
        	if ('1' == FPTb.charAt(i))
        		b = 1;
        	
        	aasum += a*a;
        	bbsum += b*b;
        	absum += a*b;
        } 
               
        return 1.0*absum / (aasum+bbsum-absum);   
	}
	
	/** 
	 * @param strArr����ĵ�һά�ǲ������У��ڶ�ά��ȫ������ 
	 * @return ����ʱ�����󲿷ֶ����Ĳ��ֺ�ȫ������, ������nullʱ���ʾ�� �������ʧ�� 
	 * @function ������Ҫ��ʵ�־���������ĵ����ʲ���������ȫ�����еĶ��룬  
	 *          ����ÿ��������ǰ��MW(��С����)�м��һЩС�Ĳ�һ���İ�����, ���������п��Լӿո� ȫ�������в��ܼӿո� 
	 * @notice ��ĳ������³�����ܻ�ʧЧ 
	 */  
	public static String[] AlignTwoProteinSeqIgnoreLittleMistakeInMW(String partSeq, String fullSeq){  
	    final int MW = 10;  // ��ʾǰ�󴰿ڵĴ�С  
	    final int lW = 3;   // ��ʾ��ǰ�󴰿�����������̼�������  
	    final int MFPreSpaceNum = 3;    //��ʾȫ������ǰ�����Ӷ��ٿո�   
	  
	    StringBuffer partAns = new StringBuffer(partSeq.toUpperCase());  
	    StringBuffer fullAns = new StringBuffer(fullSeq.toUpperCase());  
	      
	    int fullPreSpaceNum = 0;  
	    boolean isFirstMatch = false; //��ǵ�һ���Ƿ��ܶ���  
	    for (int i = 0; ; i++){ //Seq���ڱ䶯��  
	        partSeq = partAns.toString();  
	        fullSeq = fullAns.toString();  
	          
	        String prePI = mySubString(partSeq, i-MW, i);  
	        String afterPI = mySubString(partSeq, i+1, i+1+MW);  
	        String preFI = mySubString(fullSeq, i-MW, i);  
	        String afterFI =  mySubString(fullSeq, i+1, i+1+MW);  
	        int preNSAcidNum = statisticNotSameAcidNum(prePI, preFI);  
	        int afterNSAcidNum = statisticNotSameAcidNum(afterPI, afterFI);  
	          
	        if (fullSeq.charAt(i) == partSeq.charAt(i)){ //��ǰ��������һ����  
	            //�������Ĵ��ڲ�����ƥ�䣬 ������Ҫ����ǰ��Ĵ����ж���ǰ��ӿո�  
	            if (lW < afterNSAcidNum){   
	                if (lW < preNSAcidNum){  
	                   System.out.println("This wrong is not correct!");  
	                   System.out.println(partSeq + "\n" + fullSeq);
	                   return null;
	                }else{  
	                    if (prePI.charAt(MW - 1) == ' '){ //��ǰ��ӿո�  
	                        partAns.delete(0, partAns.length());  
	                        partAns.append(partSeq.substring(0, i));  
	                        partAns.append(" ");  
	                        partAns.append(partSeq.substring(i, partSeq.length()));  
	                    }  
	                }  
	            }else{  
	                // �ж��ǲ��ǵ�һ��ƥ��  
	                int afterFISpaceNum = 0;  
	                for (int kkk = 0; kkk < afterFI.length(); kkk++){  
	                    if (' ' == afterFI.charAt(kkk)){  
	                        afterFISpaceNum++;  
	                    }  
	                }  
	                if (lW >= afterFISpaceNum)  
	                    isFirstMatch = true;  
	            }  
	        }  
	        else{   //��ǰ�������ǲ�һ����  
	            if (lW < afterNSAcidNum){ //�������Ĳ�����ƥ��  
	                partAns.delete(0, partAns.length());  
	                partAns.append(partSeq.substring(0, i));  
	                partAns.append(" ");  
	                partAns.append(partSeq.substring(i, partSeq.length()));  
	            }else{  //�������Ŀ���ƥ���ƥ��  
	                // �ж��ǲ��ǵ�һ��ƥ��  
	                int afterFISpaceNum = 0;  
	                for (int kkk = 0; kkk < afterFI.length(); kkk++){  
	                    if (' ' == afterFI.charAt(kkk)){  
	                        afterFISpaceNum++;  
	                    }  
	                }  
	                if (lW >= afterFISpaceNum)  
	                    isFirstMatch = true;  
	            }  
	        }  
	          
	        // �ж��Ƿ�ƥ��ɹ�  
	        String temp = mySubString("", 0-MW, 0);  
	        if (afterPI.equals(temp) || afterFI.equalsIgnoreCase(temp)){   
	            if (!isFirstMatch){  
	                fullPreSpaceNum++;  
	                if (MFPreSpaceNum + 1 <= fullPreSpaceNum){  
	                    return null;  
	                }  
	                fullAns.delete(0, fullAns.length());  
	                fullAns.append(" ");  
	                fullAns.append(fullSeq);  
	                i = fullPreSpaceNum - 1;  
	                  
	                partAns.delete(0, partAns.length()); //��ȥ�м���������ÿո�  
	                for (int lll = 0; lll < partSeq.length(); lll++){  
	                    if (' ' != partSeq.charAt(lll))  
	                    {  
	                        partAns.append(partSeq.charAt(lll));  
	                    }  
	                }  
	            }else{  
	                break;  
	            }  
	        }  
	    }  
	    return partAns.append("#" + fullAns.toString()).toString().split("#");  
	}  
	  
	private static String mySubString(String srcStr, int begin, int end){    //û�еĲ��������ÿո��ʾ  ��֤���ص��ַ�������Ϊend-begin  
	    int len = srcStr.length();  
	    byte[] srcArr = srcStr.getBytes();  
	    byte[] ans = new byte[end - begin];  
	    for (int i = 0; i < end - begin; i++) ans[i] = ' ';  
	      
	    if (begin < 0 && end <= len){  
	        begin = 0;  
	          
	        for (int i = end - 1, j = ans.length - 1; i >= begin; i--, j--){  
	            ans[j] = srcArr[i];  
	        }  
	    }else if (end > len && begin >= 0){  
	        end = len;  
	          
	        for (int i = begin, j = 0; i < end; i++, j++){  
	            ans[j] = srcArr[i];  
	        }  
	    }else if (begin >=0 && end <= len){  
	        for (int i = begin, j = 0; i < end; i++, j++){  
	            ans[j] = srcArr[i];  
	        }  
	    }else if(begin < 0 && end > len){  
	        for (int i = 0, j = 0 - begin; i < len; i++, j++){  
	            ans[j] = srcArr[i];  
	        }   
	    }  
	    return new String(ans);  
	}  
	  
	private static int statisticNotSameAcidNum(String lineone, String linetwo){  
	    byte[] oneArr = lineone.toUpperCase().getBytes();  //���԰�����Ĵ�Сд  
	    byte[] twoArr = linetwo.toUpperCase().getBytes();  
	    if (oneArr.length != twoArr.length){  
	        System.out.println("two line not the same lenght!");  
	        return -1;  
	    }  
	    int ans = 0;  
	    for (int i = 0; i < oneArr.length; i++){  
	        if (oneArr[i] != twoArr[i] && ' ' != oneArr[i] && ' ' != twoArr[i]){  
	            ans++;  
	        }  
	    }  
	    return ans;  
	}  
}
