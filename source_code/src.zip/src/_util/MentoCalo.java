package _util;

import java.util.*;

public class MentoCalo {
	private static Random rand;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int accept_num = 0;
		for (int i = 0; i < 1000; i++){
			if (isAccept8Metropolis(0.5, 1)){
				accept_num++;
			}
		}
		
		System.out.println(accept_num);
	}
	
	/**
	 * Metropolis Mento Calo : Using Boltzamann Distribution Probability
	 * @param dE : 	the state energy changement
	 * @param kT :  	thermodynamic temperature
	 * @return the accept state.
	 */
	public static boolean isAccept8Metropolis(double dE, double kT){
		if (null == rand){
			rand = new Random(new Date().getTime()); 
		}
		
		boolean ans = true;
		double rv = rand.nextDouble();
		if (rv > Math.exp(-dE/kT)){
			ans = false; 
		}
		
		return ans;
	}
}
